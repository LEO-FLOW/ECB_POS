import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table } from "@shared/schema";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

interface TableCardProps {
  table: Table & {
    currentUsage?: {
      id: number;
      startTime: string | Date;
      userId?: number;
      userName?: string;
    };
    reservation?: {
      id: number;
      customerName?: string;
      startTime: string | Date;
      endTime: string | Date;
    };
  };
  onTableAction?: (tableId: number, status: string, tableUsageId?: number) => void;
  isLoading?: boolean;
}

export function TableCard({ table, onTableAction, isLoading = false }: TableCardProps) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  
  const formatTimeAgo = (startTime: string | Date) => {
    const start = new Date(startTime);
    const now = new Date();
    const diffInMs = now.getTime() - start.getTime();
    const diffInMins = Math.floor(diffInMs / (1000 * 60));
    
    if (diffInMins < 60) {
      return `${diffInMins} mins ago`;
    } else {
      const hours = Math.floor(diffInMins / 60);
      const mins = diffInMins % 60;
      return `${hours}h ${mins}m ago`;
    }
  };
  
  const calculateEstimatedCharge = (startTime: string | Date) => {
    const start = new Date(startTime);
    const now = new Date();
    const diffInMs = now.getTime() - start.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);
    
    return (diffInHours * Number(table.hourlyRate)).toFixed(2);
  };
  
  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800";
      case "in-use":
        return "bg-red-100 text-red-800";
      case "reserved":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  const formatStatus = (status: string) => {
    switch (status) {
      case "available":
        return "Available";
      case "in-use":
        return "In Use";
      case "reserved":
        return "Reserved";
      default:
        return status;
    }
  };
  
  const getActionButtonText = (status: string) => {
    switch (status) {
      case "available":
        return "Check In";
      case "in-use":
        return "Check Out";
      case "reserved":
        return "Check In";
      default:
        return "Action";
    }
  };
  
  const getActionButtonColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-secondary hover:bg-secondary-light";
      case "in-use":
        return "bg-red-500 hover:bg-red-600";
      case "reserved":
        return "bg-yellow-500 hover:bg-yellow-600";
      default:
        return "bg-primary";
    }
  };
  
  const handleAction = () => {
    if (onTableAction) {
      if (table.status === "available") {
        onTableAction(table.id, "start-session");
      } else if (table.status === "in-use" && table.currentUsage) {
        onTableAction(table.id, "end-session", table.currentUsage.id);
      } else if (table.status === "reserved" && table.reservation) {
        onTableAction(table.id, "start-session");
      }
    }
  };
  
  return (
    <>
      <Card className="table-card hover:shadow-lg overflow-hidden transition-all duration-300">
        <CardContent className="px-4 py-5">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-heading font-medium text-gray-900">{table.name}</h3>
              <Badge className={getStatusBadgeColor(table.status)}>
                {formatStatus(table.status)}
              </Badge>
            </div>
            <div className="text-sm text-gray-500">{table.type}</div>
          </div>
          
          {table.status === "in-use" && table.currentUsage && (
            <div className="mt-2">
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-white text-xs font-semibold">
                    {table.currentUsage.userName?.split(" ").map(n => n[0]).join("") || "G"}
                  </span>
                </div>
                <div className="ml-2">
                  <div className="text-sm font-medium text-gray-900">
                    {table.currentUsage.userName || "Guest"}
                  </div>
                  <div className="text-xs text-gray-500">
                    Started: {format(new Date(table.currentUsage.startTime), "h:mm a")} ({formatTimeAgo(table.currentUsage.startTime)})
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {table.status === "reserved" && table.reservation && (
            <div className="mt-2">
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center">
                  <span className="text-white text-xs font-semibold">
                    {table.reservation.customerName?.split(" ").map(n => n[0]).join("") || "?"}
                  </span>
                </div>
                <div className="ml-2">
                  <div className="text-sm font-medium text-gray-900">
                    {table.reservation.customerName}
                  </div>
                  <div className="text-xs text-gray-500">
                    Reserved: {format(new Date(table.reservation.startTime), "h:mm a")} - {format(new Date(table.reservation.endTime), "h:mm a")}
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div className="mt-4 flex justify-between items-center">
            <div className="text-sm text-gray-500">
              {table.status === "in-use" && table.currentUsage
                ? `Estimated: $${calculateEstimatedCharge(table.currentUsage.startTime)}`
                : `Rate: $${Number(table.hourlyRate).toFixed(2)}/hr`}
            </div>
            <Button 
              size="sm" 
              onClick={handleAction}
              className={getActionButtonColor(table.status)}
              disabled={isLoading}
            >
              {getActionButtonText(table.status)}
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{table.name} Details</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-500">Table Type</h4>
              <p>{table.type}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-500">Hourly Rate</h4>
              <p>${Number(table.hourlyRate).toFixed(2)}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-500">Status</h4>
              <Badge className={getStatusBadgeColor(table.status)}>
                {formatStatus(table.status)}
              </Badge>
            </div>
            
            {table.status === "in-use" && table.currentUsage && (
              <div>
                <h4 className="text-sm font-medium text-gray-500">Current Session</h4>
                <p>Started at: {format(new Date(table.currentUsage.startTime), "h:mm a")}</p>
                <p>Duration: {formatTimeAgo(table.currentUsage.startTime)}</p>
                <p>Current charge: ${calculateEstimatedCharge(table.currentUsage.startTime)}</p>
              </div>
            )}
            
            {table.status === "reserved" && table.reservation && (
              <div>
                <h4 className="text-sm font-medium text-gray-500">Reservation</h4>
                <p>Customer: {table.reservation.customerName}</p>
                <p>Time: {format(new Date(table.reservation.startTime), "h:mm a")} - {format(new Date(table.reservation.endTime), "h:mm a")}</p>
              </div>
            )}
            
            <Button 
              onClick={handleAction}
              className={getActionButtonColor(table.status)}
              disabled={isLoading}
            >
              {getActionButtonText(table.status)}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
