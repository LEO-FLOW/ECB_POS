import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { 
  Table, 
  TableUsage, 
  User, 
  TableSessionCustomer,
  InsertTableSessionCustomer
} from '@shared/schema';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format, formatDistanceToNow } from 'date-fns';
import { CustomerSelector } from '../customers/customer-selector';
import { InventorySelector, CartItem } from '../pos/inventory-selector';
import { InventoryDialog } from '../pos/inventory-dialog';
import { CustomerTab, OrderItem } from './customer-tab';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Loader2,
  Users,
  Clock,
  GlassWater,
  Info,
  X,
  Plus,
  UserPlus,
  Trash2,
  CreditCard,
  UserCircle,
  Mail,
  Phone
} from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from '@/components/ui/dialog';

interface TableType extends Table {
  currentUsage?: TableUsage & { 
    userName?: string;
    userId?: number;
  } | null;
  reservation?: any;
}

interface TableSidePanelProps {
  table: TableType | null;
  onClose: () => void;
  onTableAction: (tableId: number, action: string, usageId?: number) => void;
}

export function TableSidePanel({
  table,
  onClose,
  onTableAction
}: TableSidePanelProps) {
  const [selectedTab, setSelectedTab] = useState('details');
  const [customerId, setCustomerId] = useState<number | null>(null);
  const [customerName, setCustomerName] = useState<string | undefined>(undefined);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [isProcessingOrder, setIsProcessingOrder] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<TableSessionCustomer | null>(null);
  const { toast } = useToast();

  // Reset form when table changes
  useEffect(() => {
    if (table) {
      setCustomerId(null);
      setCustomerName(undefined);
      
      if (!table.currentUsage) {
        setCartItems([]);
      }
    }
  }, [table]);

  // Get table usage customers (if table is in use)
  const { data: tableSessionCustomers = [], isLoading: isLoadingCustomers, refetch: refetchSessionCustomers } = useQuery({
    queryKey: ['/api/table-session-customers', table?.currentUsage?.id],
    queryFn: async () => {
      if (!table?.currentUsage?.id) return [];
      const response = await fetch(`/api/table-session-customers?tableUsageId=${table.currentUsage.id}`);
      if (!response.ok) throw new Error('Failed to fetch table customers');
      return response.json();
    },
    enabled: !!table?.currentUsage?.id,
    refetchOnMount: true, // Always refetch when the component mounts
    refetchOnWindowFocus: true, // Refetch when window gains focus
    refetchInterval: 5000, // Poll every 5 seconds for updates
  });
  
  // Get the full table usage details (including sessionId) for the current table
  const { data: fullTableUsage, isLoading: isLoadingFullUsage } = useQuery({
    queryKey: ['/api/table-usage', table?.currentUsage?.id],
    queryFn: async () => {
      if (!table?.currentUsage?.id) return null;
      const response = await fetch(`/api/table-usage/${table.currentUsage.id}`);
      if (!response.ok) {
        if (response.status === 404) return null;
        throw new Error('Failed to fetch table usage details');
      }
      return response.json();
    },
    enabled: !!table?.currentUsage?.id,
  });

  // Load existing orders if table is in use
  const { data: tableOrders = [], isLoading: isLoadingOrders, refetch: refetchOrders } = useQuery({
    queryKey: ['/api/pos/orders/table', table?.currentUsage?.id],
    queryFn: async ({ queryKey }) => {
      if (!table?.currentUsage?.id) {
        console.log("[DEBUG] No current usage ID, skipping order fetch");
        return [];
      }
      try {
        console.log(`[DEBUG] Fetching orders for table usage ID: ${table.currentUsage.id}`);
        // Use the same endpoint format as the checkout pages for consistency
        const response = await fetch(`/api/pos/orders/table/${table.currentUsage.id}`);
        
        console.log(`[DEBUG] Order response status:`, response.status);
        
        // If we get a 404, return empty array instead of throwing
        if (response.status === 404) {
          console.log("[DEBUG] No orders found for this table, returning empty array");
          return [];
        }
        
        if (!response.ok) {
          throw new Error(`Failed to fetch table orders: ${response.status}`);
        }
        
        const orders = await response.json();
        console.log(`[DEBUG] Fetched ${orders.length} orders:`, orders);
        return orders;
      } catch (error) {
        console.error("[DEBUG] Error fetching orders:", error);
        return []; // Return empty array to prevent UI from breaking
      }
    },
    enabled: !!table?.currentUsage?.id,
  });

  // Mutation to add a customer to a table session
  const addCustomerMutation = useMutation({
    mutationFn: async (data: InsertTableSessionCustomer) => {
      const response = await apiRequest('POST', '/api/table-session-customers', data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Customer added to table session successfully',
      });
      // Invalidate multiple queries to ensure UI updates properly
      queryClient.invalidateQueries({ queryKey: ['/api/table-session-customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tables'] });
      
      // Reset form state
      setCustomerId(null);
      setCustomerName(undefined);
      
      // Force refetch all related data
      refetchSessionCustomers();
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: `Failed to add customer: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Mutation to remove a customer from a table session
  const removeCustomerMutation = useMutation({
    mutationFn: async (customerId: number) => {
      const response = await apiRequest('DELETE', `/api/table-session-customers/${customerId}`);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Customer removed from table session',
      });
      // Invalidate all related queries to ensure UI updates properly
      queryClient.invalidateQueries({ queryKey: ['/api/table-session-customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tables'] });
      
      // Explicitly refetch the session customers list
      refetchSessionCustomers();
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: `Failed to remove customer: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Mutation to start a table session
  const startSessionMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/table-usage', data);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Success',
        description: 'Table session started successfully',
      });
      // Invalidate all related queries to ensure UI updates properly
      queryClient.invalidateQueries({ queryKey: ['/api/tables'] });
      queryClient.invalidateQueries({ queryKey: ['/api/table-session-customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
      
      // Add the customer to the session if not the primary user
      if (customerName && !customerId && data.id) {
        addCustomerMutation.mutate({
          tableUsageId: data.id,
          customerName,
          isWalkIn: true
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: `Failed to start session: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Handle adding a customer to table session
  const handleAddCustomer = () => {
    if (!table?.currentUsage?.id) return;
    
    if (customerId) {
      // Adding a member
      addCustomerMutation.mutate({
        tableUsageId: table.currentUsage.id,
        userId: customerId,
        isWalkIn: false
      });
    } else if (customerName) {
      // Adding a walk-in customer
      addCustomerMutation.mutate({
        tableUsageId: table.currentUsage.id,
        customerName,
        isWalkIn: true
      });
    }
  };

  // Query to get all members (we need this to show proper names)
  const { data: membersData = [] } = useQuery<User[]>({
    queryKey: ["/api/members"],
  });
  
  // State for multiple customers
  const [customersToAdd, setCustomersToAdd] = useState<{
    id: string;
    customerId: number | null;
    customerName: string | null;
    isWalkIn: boolean;
  }[]>([]);

  // Handle adding a customer to the list
  const handleAddCustomerToList = () => {
    if (customerId || customerName) {
      // Create a unique ID for this customer entry
      const newCustomerId = `customer-${Date.now()}`;
      
      // Look up member name if this is a member (has customerId)
      let displayName = customerName;
      
      if (customerId && membersData) {
        // Find the member in our members data
        const member = membersData.find(m => m.id === customerId);
        if (member) {
          displayName = member.fullName || member.username;
          console.log(`Found member name: ${displayName} for ID: ${customerId}`);
        }
      }
      
      // Add to the list of customers
      setCustomersToAdd([
        ...customersToAdd,
        {
          id: newCustomerId,
          customerId: customerId,
          customerName: displayName || 'Walk-in Customer',
          isWalkIn: !customerId
        }
      ]);
      
      // Reset the selector
      setCustomerId(null);
      setCustomerName(undefined);
    }
  };

  // Handle adding a blank customer
  const handleAddBlankCustomer = () => {
    const newCustomerId = `blank-${Date.now()}`;
    
    setCustomersToAdd([
      ...customersToAdd,
      {
        id: newCustomerId,
        customerId: null,
        customerName: "Walk-in Customer",
        isWalkIn: true
      }
    ]);
    
    console.log("Added blank customer to list");
  };

  // Handle removing a customer from the list
  const handleRemoveCustomerFromList = (id: string) => {
    setCustomersToAdd(customersToAdd.filter(c => c.id !== id));
  };

  // Handle starting a new session
  const handleStartSession = () => {
    if (!table) return;
    
    // Check if we have selected customers or are using the single selector
    if (customersToAdd.length > 0 || customerId || customerName) {
      startSessionMutation.mutate({
        tableId: table.id,
        primaryUserId: customerId, // This will be the primary if using single selector
        customerName: customerName
      }, {
        onSuccess: (data) => {
          // If we have multiple customers to add
          if (customersToAdd.length > 0) {
            // Add each selected customer
            customersToAdd.forEach(customer => {
              if (customer.customerId) {
                // Add member
                addCustomerMutation.mutate({
                  tableUsageId: data.id,
                  userId: customer.customerId,
                  isWalkIn: false
                });
              } else {
                // Add walk-in
                addCustomerMutation.mutate({
                  tableUsageId: data.id,
                  customerName: customer.customerName || "Walk-in Customer",
                  isWalkIn: true
                });
              }
            });
          }
        }
      });
    } else {
      // Allow starting with no customers (will create a blank session)
      startSessionMutation.mutate({
        tableId: table.id,
        // Use null to start an empty session with no primary customer
        primaryUserId: null
      });
    }
  };

  // Handle customer selection
  const handleCustomerChange = (id: number | null, name?: string) => {
    setCustomerId(id);
    setCustomerName(name);
  };

  // Handle view customer details
  const handleViewCustomerDetails = (customer: TableSessionCustomer) => {
    setSelectedCustomer(customer);
  };

  // Get location from wouter
  const [, setLocation] = useLocation();

  // Handle actions
  const handleActionClick = (action: string) => {
    if (!table) return;
    onTableAction(table.id, action, table.currentUsage?.id);
  };

  // Calculate session duration
  const formatDuration = (startTime: string | Date) => {
    const start = startTime instanceof Date ? startTime : new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) {
      return `${diffMins} min${diffMins !== 1 ? 's' : ''}`;
    } else {
      const hours = Math.floor(diffMins / 60);
      const mins = diffMins % 60;
      return `${hours} hr${hours !== 1 ? 's' : ''} ${mins} min${mins !== 1 ? 's' : ''}`;
    }
  };

  // Calculate estimated charge
  const calculateCharge = (startTime: string | Date, hourlyRate: string) => {
    const start = startTime instanceof Date ? startTime : new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);
    const charge = diffHours * Number(hourlyRate);
    
    return charge.toFixed(2);
  };

  if (!table) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-800';
      case 'in-use':
        return 'bg-red-100 text-red-800';
      case 'reserved':
        return 'bg-yellow-100 text-yellow-800';
      case 'maintenance':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Determine actual status - if currentUsage exists, the table is in use
  // regardless of what the status property says
  const actualStatus = table?.currentUsage ? 'in-use' : table?.status;
  
  // For debugging
  useEffect(() => {
    if (table) {
      console.log('Table in side panel:', table.id, 'Status:', table.status, 'Current usage:', table.currentUsage);
      console.log('Actual status calculated:', actualStatus);
    }
  }, [table, actualStatus]);
  
  // Convert database orders to OrderItem format for CustomerTab
  useEffect(() => {
    if (tableOrders && tableOrders.length > 0) {
      console.log('[TABLE-SIDE-PANEL] Converting table orders to OrderItems format:', tableOrders);
      
      // Flatten all order items into a single array
      const allOrderItems: OrderItem[] = [];
      
      tableOrders.forEach(order => {
        if (order.items && Array.isArray(order.items)) {
          order.items.forEach(item => {
            allOrderItems.push({
              id: item.inventoryItemId,
              name: item.name || 'Unknown Item',
              quantity: item.quantity,
              price: typeof item.unitPrice === 'string' ? parseFloat(item.unitPrice) : item.price,
              orderId: order.id
            });
          });
        }
      });
      
      console.log('[TABLE-SIDE-PANEL] Converted OrderItems:', allOrderItems);
      setOrderItems(allOrderItems);
    } else {
      // If no orders, clear the order items
      setOrderItems([]);
    }
  }, [tableOrders]);

  return (
    <div className="bg-white h-full rounded-lg shadow-sm border overflow-hidden flex flex-col">
      <div className="flex justify-between items-center p-4 border-b">
        <div className="flex items-center space-x-2">
          <h2 className="text-xl font-semibold">{table.name}</h2>
          <Badge className={getStatusColor(actualStatus)}>
            {actualStatus}
          </Badge>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-5 w-5" />
        </Button>
      </div>
      
      {actualStatus === 'in-use' && table.currentUsage && (
        <div className="bg-white p-3 border-b">
          {/* Summary info */}
          <p className="text-sm text-gray-500 mb-1">
            Session started at {table.currentUsage ? format(new Date(table.currentUsage.startTime), "h:mm a") : "Unknown"}
          </p>
          {/* Display session ID for troubleshooting */}
          <p className="text-xs text-gray-400 mb-2 font-mono">
            Session ID: {fullTableUsage?.sessionId || table.currentUsage?.sessionId || 'Not available'}
          </p>
          
          {/* CustomerTab component to show the current billing */}
          <CustomerTab
            startTime={table.currentUsage?.startTime || new Date()}
            hourlyRate={table.hourlyRate}
            onRefresh={() => refetchOrders()}
            onAddItems={async (items) => {
              if (items.length === 0) return;
              
              setIsProcessingOrder(true);
              console.log('[DEBUG-ORDER] Starting order process for table usage:', table.currentUsage?.id);
              console.log('[DEBUG-ORDER] Items to add:', items);
              
              // Convert CartItems to OrderItems format with all required fields
              const newOrderItems = items.map(item => ({
                inventoryItemId: item.id,
                quantity: item.quantity,
                unitPrice: item.price.toString(),
                totalPrice: (item.price * item.quantity).toString()
              }));
              
              // Calculate total amount
              const totalAmount = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
              console.log('[DEBUG-ORDER] Order total:', totalAmount);
              
              try {
                // First create a POS order with all required fields - but with pending status
                const orderPayload = {
                  orderNumber: `ORD-${Date.now().toString().slice(-6)}`, // Generate a simple order number
                  userId: table.currentUsage?.primaryUserId || null,
                  tableUsageId: table.currentUsage?.id || 0,
                  subtotal: totalAmount.toString(),
                  discountAmount: "0",
                  taxAmount: "0",
                  totalAmount: totalAmount.toString(),
                  paymentStatus: "pending", // Change to pending instead of paid
                  paymentMethod: null,     // No payment method yet
                  items: newOrderItems
                };
                
                console.log('[DEBUG-ORDER] Sending order to server:', orderPayload);
                
                const orderResponse = await apiRequest('POST', '/api/pos/orders', orderPayload);
                console.log('[DEBUG-ORDER] Order response status:', orderResponse.status);
                
                let orderData;
                try {
                  orderData = await orderResponse.json();
                  console.log('[DEBUG-ORDER] Created POS order:', orderData);
                  
                  // Add the order items to the current state
                  // Convert server order items to client format for display
                  const clientOrderItems = items.map(item => ({
                    id: item.id,
                    name: item.name,
                    quantity: item.quantity,
                    price: parseFloat(item.price),
                    totalPrice: item.price * item.quantity,
                    orderId: orderData.id
                  }));
                  
                  console.log('[DEBUG-ORDER] Adding to client state:', clientOrderItems);
                  
                  // Update the orderItems state
                  setOrderItems(prev => {
                    const newOrderItems = [...prev, ...clientOrderItems];
                    console.log('[DEBUG-ORDER] Updated order items state:', newOrderItems);
                    return newOrderItems;
                  });
                  
                } catch (error) {
                  console.error('[DEBUG-ORDER] Error parsing POS order response:', error);
                }
                
                // We no longer create a transaction immediately
                // Transaction will be created at checkout
                
                // Update UI
                toast({
                  title: 'Order Added',
                  description: `${items.length} items added to the table tab`,
                });
                
                // Fetch orders directly to verify they were created
                console.log('[DEBUG-ORDER] Checking orders directly after creation...');
                try {
                  if (table.currentUsage?.id) {
                    const checkResponse = await fetch(`/api/pos/orders/table/${table.currentUsage.id}`);
                    const checkData = await checkResponse.json();
                    console.log('[DEBUG-ORDER] Direct check of orders after creation:', checkData);
                  }
                } catch (checkError) {
                  console.error('[DEBUG-ORDER] Error checking orders:', checkError);
                }
                
                // Invalidate queries to refresh data
                console.log('[DEBUG-ORDER] Invalidating queries for table usage:', table.currentUsage?.id);
                queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
                
                if (table.currentUsage?.id) {
                  queryClient.invalidateQueries({ queryKey: ['/api/pos/orders/table', table.currentUsage.id] });
                }
              } catch (error) {
                console.error('Error adding food & drink transaction:', error);
                toast({
                  title: 'Error',
                  description: 'Failed to process order. Please try again.',
                  variant: 'destructive',
                });
              } finally {
                setIsProcessingOrder(false);
              }
            }}
            orderItems={orderItems}
            customerName={table.currentUsage?.userName || "Walk-in Customer"}
          />
        </div>
      )}
      
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="flex-1 flex flex-col overflow-hidden">
        <TabsList className="justify-start px-4 pt-2 h-12 border-b rounded-none">
          <TabsTrigger value="details" className="flex gap-1">
            <Info className="h-4 w-4" />
            <span>Details & Customers</span>
          </TabsTrigger>
        </TabsList>
        
        <ScrollArea className="flex-1">
          {/* DETAILS TAB - Combined with Customer Management */}
          <TabsContent value="details" className="p-4 space-y-4 h-full">
            {/* Table Information */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Table Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Type</p>
                  <p className="font-medium">{table.type}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Rate</p>
                  <p className="font-medium">${Number(table.hourlyRate).toFixed(2)}/hr</p>
                </div>
              </div>
              
              {actualStatus === "in-use" && table.currentUsage && (
                <div className="bg-gray-50 p-3 rounded border">
                  <h4 className="text-sm font-medium mb-2">Current Session</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-gray-500">Started</p>
                      <p>{format(new Date(table.currentUsage.startTime), "h:mm a")}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Duration</p>
                      <p>{formatDuration(table.currentUsage.startTime)}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Current Charge</p>
                      <p>${calculateCharge(table.currentUsage.startTime, table.hourlyRate)}</p>
                    </div>
                  </div>
                </div>
              )}
              
              {table.status === "reserved" && table.reservation && (
                <div className="bg-gray-50 p-3 rounded border">
                  <h4 className="text-sm font-medium mb-2">Reservation</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-gray-500">Customer</p>
                      <p>{table.reservation.customerName}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Time</p>
                      <p>{format(new Date(table.reservation.startTime), "h:mm a")} - {format(new Date(table.reservation.endTime), "h:mm a")}</p>
                    </div>
                  </div>
                </div>
              )}

              <Separator />
            </div>

            {/* Current Customers Section */}
            {actualStatus === 'in-use' && table.currentUsage && (
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Current Customers</h3>
                
                {isLoadingCustomers ? (
                  <div className="flex justify-center p-4">
                    <Loader2 className="h-6 w-6 animate-spin text-gray-400" />
                  </div>
                ) : (
                  <div className="space-y-2">
                    {/* Primary customer from table usage */}
                    <div className="flex justify-between items-center p-2 bg-blue-50 rounded border border-blue-100">
                      <div>
                        <p className="font-medium flex items-center">
                          {table.currentUsage?.userName || 'Walk-in Customer'}
                          <Badge variant="outline" className="ml-2 text-xs">Primary</Badge>
                        </p>
                        <p className="text-xs text-gray-500">Session started {formatDistanceToNow(new Date(table.currentUsage.startTime), { addSuffix: true })}</p>
                      </div>
                    </div>
                    
                    {/* Additional customers */}
                    {Array.isArray(tableSessionCustomers) && tableSessionCustomers.length > 0 ? (
                      tableSessionCustomers.map((customer: TableSessionCustomer) => (
                        <div key={customer.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                          <div>
                            <div className="cursor-pointer" onClick={() => handleViewCustomerDetails(customer)}>
                            <p className="font-medium flex items-center">
                              <span>{customer.customerName || 'Walk-in Customer'}</span>
                              {customer.isWalkIn ? (
                                <span className="ml-2 text-xs bg-gray-100 px-1 py-0.5 rounded">Walk-in</span>
                              ) : customer.userId ? (
                                <span className="ml-2"><Badge variant="outline" className="text-xs">Member</Badge></span>
                              ) : null}
                              <Info className="h-4 w-4 ml-1 text-gray-400" />
                            </p>
                          </div>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => removeCustomerMutation.mutate(customer.id)}
                            disabled={removeCustomerMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      ))
                    ) : null}
                  </div>
                )}
                
                <Separator />
              </div>
            )}
            
            {/* Multiple Customers Start Session UI */}
            {actualStatus === 'available' && (
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Start Session with Customers</h3>
                
                {/* Customers to add list */}
                {customersToAdd.length > 0 && (
                  <div className="space-y-2 mb-4">
                    <p className="text-xs text-gray-500">Selected customers:</p>
                    {customersToAdd.map(customer => (
                      <div key={customer.id} className="flex justify-between items-center p-2 bg-gray-50 rounded border">
                        <div>
                          <p className="font-medium text-sm flex items-center">
                            <span>{customer.customerName || 'Walk-in Customer'}</span>
                            {customer.isWalkIn ? (
                              <span className="ml-2 text-xs bg-gray-100 px-1 py-0.5 rounded">Walk-in</span>
                            ) : customer.customerId ? (
                              <Badge variant="outline" className="ml-2 text-xs">Member</Badge>
                            ) : null}
                          </p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => handleRemoveCustomerFromList(customer.id)}
                        >
                          <X className="h-4 w-4 text-gray-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Customer selector */}
                <div>
                  <CustomerSelector 
                    value={customerId} 
                    onValueChange={handleCustomerChange}
                    allowGuest={true}
                    allowNewCustomer={true}
                    tableUsageId={table?.currentUsage?.id}
                  />
                </div>

                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={handleAddCustomerToList}
                    disabled={!customerId && !customerName}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add to List
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={handleAddBlankCustomer}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add Blank
                  </Button>
                </div>
                
                <Button 
                  className="w-full bg-secondary hover:bg-secondary-light mt-4"
                  onClick={handleStartSession}
                  disabled={startSessionMutation.isPending}
                >
                  {startSessionMutation.isPending ? (
                    <div className="flex items-center">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Starting Session...
                    </div>
                  ) : (
                    customersToAdd.length > 0 ? 
                      `Start Session with ${customersToAdd.length} Customers` : 
                      "Start Empty Session"
                  )}
                </Button>
              </div>
            )}
            
            {/* Add customer to existing session */}
            {actualStatus === 'in-use' && (
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Add Customer to Session</h3>
                
                <div>
                  <CustomerSelector 
                    value={customerId} 
                    onValueChange={handleCustomerChange}
                    allowGuest={true}
                    allowNewCustomer={true}
                    tableUsageId={table?.currentUsage?.id}
                  />
                </div>
                
                <div className="flex space-x-2">
                  <Button 
                    className="flex-1"
                    onClick={handleAddCustomer}
                    disabled={addCustomerMutation.isPending || (!customerId && !customerName)}
                  >
                    {addCustomerMutation.isPending ? (
                      <div className="flex items-center">
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Adding...
                      </div>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4 mr-2" />
                        Add Customer
                      </>
                    )}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      // Add a blank walk-in customer
                      addCustomerMutation.mutate({
                        tableUsageId: table.currentUsage?.id as number,
                        customerName: "Walk-in Customer",
                        isWalkIn: true
                      });
                    }}
                    disabled={addCustomerMutation.isPending}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add Blank
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
          

          

        </ScrollArea>
      </Tabs>
      
      <div className="p-4 border-t">
        {actualStatus === 'available' && (
          <div className="flex space-x-2">
            <Button 
              className="flex-1 bg-secondary hover:bg-secondary-light" 
              onClick={handleStartSession}
              disabled={startSessionMutation.isPending}
            >
              <Users className="h-4 w-4 mr-2" />
              {startSessionMutation.isPending ? (
                <div className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Starting...
                </div>
              ) : (
                "Start Table Session"
              )}
            </Button>
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={() => handleActionClick("maintenance")}
            >
              <Clock className="h-4 w-4 mr-1" />
              Maintenance
            </Button>
          </div>
        )}
        
        {actualStatus === 'in-use' && (
          <div className="flex flex-col space-y-2">
            <Button 
              className="w-full bg-red-500 hover:bg-red-600 text-white" 
              onClick={() => {
                if (table && table.currentUsage?.id) {
                  // Redirect to specific checkout page with table usage ID
                  setLocation(`/tables/${table.currentUsage.id}/checkout`);
                }
              }}
            >
              <CreditCard className="h-4 w-4 mr-2" />
              Checkout
            </Button>
            
            <Button 
              className="w-full bg-gray-500 hover:bg-gray-600 text-white" 
              onClick={() => {
                // Redirect to debug checkout page which shows all active sessions
                setLocation(`/debug-checkout`);
              }}
            >
              <CreditCard className="h-4 w-4 mr-2" />
              Debug Checkout
            </Button>
          </div>
        )}
        
        {actualStatus === 'reserved' && (
          <div className="flex space-x-2">
            <Button 
              className="flex-1" 
              onClick={handleStartSession}
              disabled={startSessionMutation.isPending}
            >
              <Users className="h-4 w-4 mr-2" />
              Start Session
            </Button>
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={() => handleActionClick("available")}
            >
              Cancel Reservation
            </Button>
          </div>
        )}
        
        {actualStatus === 'maintenance' && (
          <Button 
            className="w-full" 
            onClick={() => handleActionClick("available")}
          >
            Mark Available
          </Button>
        )}
      </div>
      
      {/* Customer Details Dialog */}
      <Dialog open={!!selectedCustomer} onOpenChange={(open) => !open && setSelectedCustomer(null)}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <UserCircle className="h-5 w-5 mr-2" />
              Customer Details
            </DialogTitle>
            <DialogDescription>
              Detailed information about the selected customer.
            </DialogDescription>
          </DialogHeader>
          
          {selectedCustomer && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h4 className="font-medium">Basic Information</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-gray-500">Name</p>
                    <p className="font-medium">{selectedCustomer.customerName || 'Not provided'}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Type</p>
                    <p className="font-medium">
                      {selectedCustomer.userId 
                        ? <Badge variant="outline">Member</Badge>
                        : <Badge variant="secondary">Walk-in</Badge>
                      }
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500">Added to Table</p>
                    <p>{format(new Date(selectedCustomer.addedAt), "MMM d, yyyy 'at' h:mm a")}</p>
                  </div>
                </div>
              </div>
              
              {/* Member-specific information */}
              {selectedCustomer.userId && (
                <div className="space-y-2">
                  <Separator />
                  <h4 className="font-medium">Membership Details</h4>
                  <div className="text-sm space-y-4">
                    <p className="flex items-center">
                      <UserCircle className="h-4 w-4 mr-2 text-primary" />
                      Member ID: #{selectedCustomer.userId}
                    </p>
                    <div className="flex items-center">
                      <Button variant="outline" size="sm" className="mr-2">
                        <Mail className="h-4 w-4 mr-2" />
                        Send Email
                      </Button>
                      <Button variant="outline" size="sm">
                        <Phone className="h-4 w-4 mr-2" />
                        Call
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              
              <DialogClose asChild>
                <Button className="w-full">Close</Button>
              </DialogClose>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}