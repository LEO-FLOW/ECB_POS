import { Clock, Coffee, DollarSign, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { InventoryDialog } from '../pos/inventory-dialog';
import { CartItem } from '../pos/inventory-selector';

export interface OrderItem {
  id: number;
  name: string;
  quantity: number;
  price: number;
  time?: string;
}

interface CustomerTabProps {
  startTime: string | Date;
  hourlyRate: string;
  onAddItems?: (items: CartItem[]) => void; // This is now optional
  orderItems?: OrderItem[];
  customerName?: string;
  onRefresh?: () => void; // New optional refresh callback
}

export function CustomerTab({
  startTime,
  hourlyRate,
  onAddItems,
  orderItems = [],
  customerName = 'Guest',
  onRefresh
}: CustomerTabProps) {
  // Calculate the time charge
  const calculateTimeCharge = () => {
    const start = new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);
    return diffHours * Number(hourlyRate);
  };

  // Format the time duration
  const formatDuration = () => {
    const start = new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) {
      return `${diffMins} min${diffMins !== 1 ? 's' : ''}`;
    } else {
      const hours = Math.floor(diffMins / 60);
      const mins = diffMins % 60;
      return `${hours} hr${hours !== 1 ? 's' : ''} ${mins} min${mins !== 1 ? 's' : ''}`;
    }
  };

  // Calculate the total for items
  const calculateItemsTotal = () => {
    return orderItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  // Calculate the grand total
  const calculateTotal = () => {
    return calculateTimeCharge() + calculateItemsTotal();
  };

  // Convert OrderItems to CartItems format for the dialog
  const mapOrderItemsToCartItems = (items: OrderItem[]): CartItem[] => {
    return items.map(item => ({
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: item.quantity,
      category: item.time ? 'Drinks' : 'Food' // Default category based on time
    }));
  };

  const handleAddItems = (items: CartItem[]) => {
    if (onAddItems) {
      onAddItems(items);
    }
  };

  return (
    <Card className="border-none shadow-none bg-transparent">
      <CardHeader className="pb-2 pt-0 px-0 flex justify-between items-center">
        <CardTitle className="text-md">Customer Tab</CardTitle>
        {onRefresh && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onRefresh} 
            className="h-8 px-2"
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            <span className="text-xs">Refresh</span>
          </Button>
        )}
      </CardHeader>
      <CardContent className="p-0 space-y-3">
        {/* Time Charge */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-gray-500" />
            <span>{formatDuration()} @ ${Number(hourlyRate).toFixed(2)}/hr</span>
          </div>
          <span className="font-medium">${calculateTimeCharge().toFixed(2)}</span>
        </div>

        {/* Order Items */}
        {orderItems.length > 0 && (
          <>
            <Separator />
            <div className="space-y-2">
              {orderItems.map(item => (
                <div key={item.id} className="flex justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <Coffee className="h-4 w-4 text-gray-500" />
                    <span>
                      {item.quantity}x {item.name}
                    </span>
                  </div>
                  <span className="font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Add Items Button (using Dialog) */}
        <InventoryDialog
          onOrderComplete={handleAddItems}
          initialItems={mapOrderItemsToCartItems(orderItems)}
          triggerButtonLabel="Add Items"
        />

        {/* Total */}
        <div className="flex justify-between pt-2 border-t mt-4">
          <span className="font-semibold flex items-center gap-1">
            <DollarSign className="h-4 w-4" />
            Total:
          </span>
          <span className="font-bold text-lg">${calculateTotal().toFixed(2)}</span>
        </div>
      </CardContent>
    </Card>
  );
}