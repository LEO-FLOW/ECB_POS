import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Table, TableUsage, User } from '@shared/schema';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from '@/components/ui/dialog';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { CustomerSelector } from '../customers/customer-selector';
import { InventorySelector, CartItem } from '../pos/inventory-selector';
import { CartDisplay } from '../pos/cart-display';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Loader2,
  Users,
  Clock,
  GlassWater,
  Info
} from 'lucide-react';

interface TableDetailsDialogProps {
  table: Table & { 
    currentUsage?: TableUsage & { userName?: string } | null;
    reservation?: any;
  } | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onTableAction: (action: string) => void;
}

export function TableDetailsDialog({
  table,
  open,
  onOpenChange,
  onTableAction
}: TableDetailsDialogProps) {
  const [selectedTab, setSelectedTab] = useState('details');
  const [customerId, setCustomerId] = useState<number | null>(
    table?.currentUsage?.userId || null
  );
  const [customerName, setCustomerName] = useState<string | undefined>(
    table?.currentUsage?.userName || undefined
  );
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isProcessingOrder, setIsProcessingOrder] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Reset state when table changes
    if (table) {
      setCustomerId(table.currentUsage?.userId || null);
      setCustomerName(table.currentUsage?.userName || undefined);
      
      if (table.status !== 'in-use') {
        setCartItems([]);
      } else {
        // If table is in use, we could fetch existing orders
        setSelectedTab('details');
      }
    }
  }, [table]);

  // Load existing orders if table is in use
  const { data: tableOrders = [], isLoading: isLoadingOrders } = useQuery({
    queryKey: ['/api/pos/orders/table', table?.currentUsage?.id],
    enabled: !!table?.currentUsage?.id,
  });

  const startSessionMutation = useMutation({
    mutationFn: async () => {
      if (!table) return null;

      return apiRequest("POST", "/api/table-usage", {
        tableId: table.id,
        userId: customerId,
        customerName: !customerId ? customerName : undefined,
        startTime: new Date().toISOString(),
        status: "active",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      toast({
        title: "Session Started",
        description: customerId 
          ? "Table session has been started with selected member" 
          : customerName 
            ? `Table session has been started with ${customerName}`
            : "Table session has been started",
      });
      setSelectedTab('details');
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to start session: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const assignCustomerMutation = useMutation({
    mutationFn: async () => {
      if (!table?.currentUsage?.id) return null;

      return apiRequest("PATCH", `/api/table-usage/${table.currentUsage.id}`, {
        userId: customerId,
        customerName: !customerId ? customerName : undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      toast({
        title: "Customer Assigned",
        description: customerId 
          ? "Member has been assigned to this table" 
          : customerName 
            ? `${customerName} has been assigned to this table`
            : "Customer has been assigned to this table",
      });
      setSelectedTab('details');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to assign customer: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: async () => {
      if (!table?.currentUsage?.id || cartItems.length === 0) return null;

      const subtotal = cartItems.reduce((sum, item) => {
        return sum + (Number(item.price) * item.quantity);
      }, 0);

      return apiRequest("POST", "/api/pos/orders", {
        tableUsageId: table.currentUsage.id,
        userId: customerId,
        subtotal: subtotal.toFixed(2),
        totalAmount: subtotal.toFixed(2),
        paymentStatus: "pending",
        items: cartItems.map(item => ({
          inventoryItemId: item.id,
          quantity: item.quantity,
          unitPrice: item.price,
          totalPrice: (Number(item.price) * item.quantity).toFixed(2)
        }))
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      queryClient.invalidateQueries({ queryKey: ['/api/pos/orders/table', table?.currentUsage?.id] });
      toast({
        title: "Order Created",
        description: "Items have been added to the tab",
      });
      setCartItems([]);
      setSelectedTab('details');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create order: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleStartSession = () => {
    startSessionMutation.mutate();
  };

  const handleAssignCustomer = () => {
    assignCustomerMutation.mutate();
  };

  const handleCustomerChange = (id: number | null, name?: string) => {
    setCustomerId(id);
    setCustomerName(name);
  };

  const handleAddToCart = (item: CartItem) => {
    setCartItems(prevItems => {
      const existingItemIndex = prevItems.findIndex(i => i.id === item.id);
      
      if (existingItemIndex >= 0) {
        if (item.quantity === 0) {
          // Remove item if quantity is 0
          return prevItems.filter(i => i.id !== item.id);
        }
        
        // Update existing item quantity
        const updatedItems = [...prevItems];
        updatedItems[existingItemIndex] = item;
        return updatedItems;
      } else {
        // Add new item
        return [...prevItems, item];
      }
    });
  };

  const handleRemoveCartItem = (itemId: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== itemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleCheckout = () => {
    setIsProcessingOrder(true);
    createOrderMutation.mutate();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-500 hover:bg-green-600';
      case 'in-use':
        return 'bg-blue-500 hover:bg-blue-600';
      case 'reserved':
        return 'bg-yellow-500 hover:bg-yellow-600';
      case 'maintenance':
        return 'bg-red-500 hover:bg-red-600';
      default:
        return 'bg-gray-500 hover:bg-gray-600';
    }
  };

  if (!table) return null;

  // Helper function to format duration
  const formatDuration = (startTime: string | Date): string => {
    const start = new Date(startTime);
    const now = new Date();
    const diffInMs = now.getTime() - start.getTime();
    const diffInMins = Math.floor(diffInMs / (1000 * 60));
    
    if (diffInMins < 60) {
      return `${diffInMins}m`;
    } else {
      const hours = Math.floor(diffInMins / 60);
      const mins = diffInMins % 60;
      return `${hours}h ${mins}m`;
    }
  };

  // Helper function to calculate charges
  const calculateCharge = (startTime: string | Date, hourlyRate: string | number): string => {
    const start = new Date(startTime);
    const now = new Date();
    const diffInMs = now.getTime() - start.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);
    
    return (diffInHours * Number(hourlyRate)).toFixed(2);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{table.name} Details</span>
            <Badge className={getStatusColor(table.status)}>
              {table.status}
            </Badge>
          </DialogTitle>
          {table.status === 'in-use' && table.currentUsage && (
            <DialogDescription>
              Session started at {format(new Date(table.currentUsage.startTime), "h:mm a")} • 
              {formatDuration(table.currentUsage.startTime)} • 
              ${calculateCharge(table.currentUsage.startTime, table.hourlyRate)}
            </DialogDescription>
          )}
        </DialogHeader>
        
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="mt-2">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="details" className="flex gap-1">
              <Info className="h-4 w-4" />
              <span>Details</span>
            </TabsTrigger>
            <TabsTrigger value="customer" className="flex gap-1">
              <Users className="h-4 w-4" />
              <span>Customer</span>
            </TabsTrigger>
            <TabsTrigger 
              value="order" 
              className="flex gap-1"
              disabled={table.status !== 'in-use'}
            >
              <GlassWater className="h-4 w-4" />
              <span>Food & Drinks</span>
            </TabsTrigger>
          </TabsList>
          
          {/* DETAILS TAB */}
          <TabsContent value="details" className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <p className="text-sm text-gray-500">Type</p>
                <p className="font-medium">{table.type}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-gray-500">Rate</p>
                <p className="font-medium">${Number(table.hourlyRate).toFixed(2)}/hr</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-gray-500">Location</p>
                <p className="font-medium">Main Room</p>
              </div>
            </div>
            
            {table.status === "in-use" && table.currentUsage && (
              <div className="bg-gray-50 p-3 rounded border">
                <h4 className="text-sm font-medium mb-2">Current Session</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-gray-500">Started</p>
                    <p>{format(new Date(table.currentUsage.startTime), "h:mm a")}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Duration</p>
                    <p>{formatDuration(table.currentUsage.startTime)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Current Charge</p>
                    <p>${calculateCharge(table.currentUsage.startTime, table.hourlyRate)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Customer</p>
                    <p>{table.currentUsage.userName || customerName || "Guest"}</p>
                  </div>
                </div>
              </div>
            )}
            
            {table.status === "reserved" && table.reservation && (
              <div className="bg-gray-50 p-3 rounded border">
                <h4 className="text-sm font-medium mb-2">Reservation</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-gray-500">Customer</p>
                    <p>{table.reservation.customerName}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Time</p>
                    <p>{format(new Date(table.reservation.startTime), "h:mm a")} - {format(new Date(table.reservation.endTime), "h:mm a")}</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="flex flex-wrap gap-2 pt-2">
              {table.status === "available" && (
                <Button 
                  className="flex-1" 
                  onClick={() => onTableAction("start-session")}
                >
                  Start Session
                </Button>
              )}
              
              {table.status === "in-use" && (
                <>
                  <Button 
                    variant="destructive" 
                    className="flex-1" 
                    onClick={() => onTableAction("end-session")}
                  >
                    End Session
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1" 
                    onClick={() => {
                      setSelectedTab("order");
                    }}
                  >
                    Add to Tab
                  </Button>
                </>
              )}
              
              {table.status === "reserved" && (
                <Button 
                  className="flex-1" 
                  onClick={() => onTableAction("start-session")}
                >
                  Start Session
                </Button>
              )}
              
              {(table.status === "in-use" || table.status === "reserved") && (
                <Button 
                  variant="outline" 
                  className="flex-1" 
                  onClick={() => onTableAction("available")}
                >
                  Mark Available
                </Button>
              )}
              
              {table.status !== "maintenance" ? (
                <Button 
                  variant="outline" 
                  className="flex-1" 
                  onClick={() => onTableAction("maintenance")}
                >
                  Maintenance
                </Button>
              ) : (
                <Button 
                  variant="outline" 
                  className="flex-1" 
                  onClick={() => onTableAction("available")}
                >
                  Available
                </Button>
              )}
            </div>
          </TabsContent>
          
          {/* CUSTOMER TAB */}
          <TabsContent value="customer" className="space-y-4">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">Select Customer</h3>
                <CustomerSelector 
                  value={customerId} 
                  onValueChange={handleCustomerChange}
                />
              </div>
              
              {table.status === 'available' ? (
                <Button 
                  className="w-full bg-secondary hover:bg-secondary-light"
                  onClick={handleStartSession}
                  disabled={startSessionMutation.isPending}
                >
                  {startSessionMutation.isPending ? (
                    <div className="flex items-center">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Starting Session...
                    </div>
                  ) : (
                    "Start Session with Customer"
                  )}
                </Button>
              ) : table.status === 'in-use' ? (
                <Button 
                  className="w-full"
                  onClick={handleAssignCustomer}
                  disabled={assignCustomerMutation.isPending}
                >
                  {assignCustomerMutation.isPending ? (
                    <div className="flex items-center">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Assigning Customer...
                    </div>
                  ) : (
                    "Assign Customer to Table"
                  )}
                </Button>
              ) : null}
            </div>
          </TabsContent>
          
          {/* ORDER TAB */}
          <TabsContent value="order" className="space-y-4 min-h-[300px]">
            {table.status === 'in-use' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Add Items</h3>
                  <InventorySelector 
                    onAddToCart={handleAddToCart} 
                    cartItems={cartItems}
                  />
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-2">Current Order</h3>
                  <CartDisplay 
                    items={cartItems}
                    onUpdateItem={handleAddToCart}
                    onRemoveItem={handleRemoveCartItem}
                    onCheckout={handleCheckout}
                    onClear={handleClearCart}
                  />
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}