import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Table, RoomFeature, LayoutConfig } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from 'zod';
import { Dialog } from "@/components/ui/dialog";
import { 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

import { 
  Loader2, 
  RefreshCcw, 
  Users, 
  Clock, 
  Edit2, 
  Save, 
  Plus, 
  Minus,
  Move,
  Grid3X3,
  DoorOpen,
  GlassWater,
  PanelTopClose,
  Home,
  Trash2,
  PenSquare,
  ChevronLeft,
  ChevronRight,
  FilePlus
} from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { Toggle } from "@/components/ui/toggle";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

interface ExtendedTable extends Table {
  currentUsage?: {
    id: number;
    startTime: string | Date;
    userId?: number;
    userName?: string;
  };
  reservation?: {
    id: number;
    customerName?: string;
    startTime: string | Date;
    endTime: string | Date;
  };
}

interface PoolRoomLayoutProps {
  editable?: boolean;
  onTableAction?: (tableId: number, status: string, tableUsageId?: number) => void;
  onAddTable?: () => void;
  selectedTableId?: number;
}

export function PoolRoomLayout({ editable = false, onTableAction, onAddTable, selectedTableId }: PoolRoomLayoutProps) {
  const { toast } = useToast();
  const canvasRef = useRef<HTMLDivElement>(null);
  const [draggingTable, setDraggingTable] = useState<ExtendedTable | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [tableDetailsOpen, setTableDetailsOpen] = useState(false);
  const [selectedTable, setSelectedTable] = useState<ExtendedTable | null>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [editMode, setEditMode] = useState(false);
  const [sizeMultiplier, setSizeMultiplier] = useState(1.0); // Default size multiplier
  const [draggingFeature, setDraggingFeature] = useState<RoomFeature | null>(null);
  const [featureOffset, setFeatureOffset] = useState({ x: 0, y: 0 });
  const [currentPage, setCurrentPage] = useState(0);
  const [canvasWidth, setCanvasWidth] = useState(1200);
  const [pagesEnabled, setPagesEnabled] = useState(false);
  
  const { data: tables = [], isLoading: tablesLoading, refetch: refetchTables } = useQuery<ExtendedTable[]>({
    queryKey: ["/api/tables"],
  });
  
  const { data: roomFeatures = [], isLoading: featuresLoading, refetch: refetchFeatures } = useQuery<RoomFeature[]>({
    queryKey: ["/api/room-features"],
  });
  
  const { data: layoutConfig, isLoading: layoutLoading } = useQuery<LayoutConfig>({
    queryKey: ["/api/layout-config"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/layout-config?default=true");
        const data = await res.json();
        return data;
      } catch (error) {
        console.error("Error fetching layout config:", error);
        // If there's no layout config, we'll use default values
        return null;
      }
    }
  });
  
  // Apply loaded layout config values if available
  useEffect(() => {
    if (layoutConfig) {
      if (layoutConfig.tableSize) {
        setSizeMultiplier(layoutConfig.tableSize / 100); // Assuming tableSize 100 = 1.0 multiplier
      }
      if (layoutConfig.canvasWidth) {
        setCanvasWidth(layoutConfig.canvasWidth);
      }
      if (typeof layoutConfig.currentPage === 'number') {
        setCurrentPage(layoutConfig.currentPage);
      }
      if (typeof layoutConfig.enableMultiPage === 'boolean') {
        setPagesEnabled(layoutConfig.enableMultiPage);
      }
    }
  }, [layoutConfig]);
  
  const updateTablePositionMutation = useMutation({
    mutationFn: async (data: { tableId: number; posX: number; posY: number }) => {
      return apiRequest("PATCH", `/api/tables/${data.tableId}/position`, {
        posX: data.posX,
        posY: data.posY
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update table position: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const updateFeaturePositionMutation = useMutation({
    mutationFn: async (data: { featureId: number; posX: number; posY: number; width?: number; height?: number }) => {
      const updateData: Partial<RoomFeature> = {
        posX: data.posX,
        posY: data.posY
      };
      
      if (data.width) updateData.width = data.width;
      if (data.height) updateData.height = data.height;
      
      return apiRequest("PATCH", `/api/room-features/${data.featureId}`, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/room-features"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update room feature: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const createRoomFeatureMutation = useMutation({
    mutationFn: async (data: { name: string; type: string; posX: number; posY: number; width: number; height: number }) => {
      return apiRequest("POST", "/api/room-features", {
        name: data.name,
        type: data.type,
        posX: data.posX,
        posY: data.posY,
        width: data.width,
        height: data.height
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/room-features"] });
      toast({
        title: "Success",
        description: "Room feature created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create room feature: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const deleteRoomFeatureMutation = useMutation({
    mutationFn: async (featureId: number) => {
      return apiRequest("DELETE", `/api/room-features/${featureId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/room-features"] });
      toast({
        title: "Success",
        description: "Room feature deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete room feature: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Layout configuration mutations
  const saveLayoutConfigMutation = useMutation({
    mutationFn: async (data: Partial<LayoutConfig>) => {
      if (layoutConfig?.id) {
        // Update existing layout
        return apiRequest("PATCH", `/api/layout-config/${layoutConfig.id}`, data);
      } else {
        // Create new layout
        return apiRequest("POST", "/api/layout-config", {
          name: "Default Layout",
          tableSize: Math.round(sizeMultiplier * 100),
          canvasWidth,
          currentPage,
          enableMultiPage: pagesEnabled,
          isDefault: true,
          ...data
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/layout-config"] });
      toast({
        title: "Success",
        description: "Layout configuration saved successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to save layout configuration: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleTableClick = (table: ExtendedTable, e: React.MouseEvent) => {
    if (isDragging) return; // Don't do anything if we're dragging
    
    if (editMode) {
      // In edit mode, we don't want to trigger actions
      return;
    }
    
    if (!editable || !onTableAction) return;
    
    // Instead of showing a dialog, directly call the onTableAction
    // This will update the side panel in the parent component
    onTableAction(table.id, "view-details", table.currentUsage?.id);
  };
  
  const handleTableAction = (action: string) => {
    if (selectedTable && onTableAction) {
      onTableAction(selectedTable.id, action, selectedTable.currentUsage?.id);
      setTableDetailsOpen(false);
    }
  };
  
  // Handle dragging elements (tables or features)
  const handleMouseDown = (e: React.MouseEvent, element: ExtendedTable | RoomFeature, isFeature = false) => {
    if (!editable || !editMode) return;
    e.stopPropagation();
    
    // Only allow dragging if left mouse button is pressed
    if (e.button !== 0) return;
    
    const rect = (e.target as HTMLElement).getBoundingClientRect();
    setOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    
    if (isFeature) {
      setDraggingFeature(element as RoomFeature);
    } else {
      setDraggingTable(element as ExtendedTable);
    }
    setIsDragging(true);
  };
  
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !canvasRef.current) return;
    
    const canvasRect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - canvasRect.left - offset.x;
    const y = e.clientY - canvasRect.top - offset.y;
    
    if (draggingTable) {
      // Keep table within canvas bounds
      const boundedX = Math.max(0, Math.min(x, canvasRect.width - 100));
      const boundedY = Math.max(0, Math.min(y, canvasRect.height - 80));
      
      const tableElement = document.getElementById(`table-${draggingTable.id}`);
      if (tableElement) {
        tableElement.style.left = `${boundedX}px`;
        tableElement.style.top = `${boundedY}px`;
      }
    } else if (draggingFeature) {
      // Keep feature within canvas bounds
      const boundedX = Math.max(0, Math.min(x, canvasRect.width - (draggingFeature.width || 100)));
      const boundedY = Math.max(0, Math.min(y, canvasRect.height - (draggingFeature.height || 100)));
      
      const featureElement = document.getElementById(`feature-${draggingFeature.id}`);
      if (featureElement) {
        featureElement.style.left = `${boundedX}px`;
        featureElement.style.top = `${boundedY}px`;
      }
    }
  };
  
  const handleMouseUp = () => {
    if (!isDragging || !canvasRef.current) return;
    
    if (draggingTable) {
      const tableElement = document.getElementById(`table-${draggingTable.id}`);
      if (tableElement) {
        const style = window.getComputedStyle(tableElement);
        const left = parseInt(style.left, 10);
        const top = parseInt(style.top, 10);
        
        updateTablePositionMutation.mutate({
          tableId: draggingTable.id,
          posX: left,
          posY: top
        });
      }
      setDraggingTable(null);
    } else if (draggingFeature) {
      const featureElement = document.getElementById(`feature-${draggingFeature.id}`);
      if (featureElement) {
        const style = window.getComputedStyle(featureElement);
        const left = parseInt(style.left, 10);
        const top = parseInt(style.top, 10);
        
        updateFeaturePositionMutation.mutate({
          featureId: draggingFeature.id,
          posX: left,
          posY: top
        });
      }
      setDraggingFeature(null);
    }
    
    setIsDragging(false);
  };
  
  // Handle feature interactions (edit, delete)
  const handleFeatureAction = (feature: RoomFeature, action: string) => {
    if (action === 'delete') {
      deleteRoomFeatureMutation.mutate(feature.id);
    }
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800 border-green-800";
      case "in-use":
        return "bg-red-100 text-red-800 border-red-800";
      case "reserved":
        return "bg-yellow-100 text-yellow-800 border-yellow-800";
      case "maintenance":
        return "bg-gray-100 text-gray-800 border-gray-800";
      default:
        return "";
    }
  };
  
  // Preserve base sizes for each table type
  const getBaseTableSize = (type: string) => {
    // Base sizes
    switch (type) {
      case "7ft Bar":
        return { width: 80, height: 40 };
      case "8ft Standard":
        return { width: 100, height: 50 };
      case "9ft Tournament":
        return { width: 120, height: 60 };
      case "Snooker":
        return { width: 140, height: 70 };
      default:
        return { width: 100, height: 50 };
    }
  };
  
  const getTableSize = (type: string) => {
    const baseSize = getBaseTableSize(type);
    
    // Apply size multiplier
    return {
      width: Math.round(baseSize.width * sizeMultiplier),
      height: Math.round(baseSize.height * sizeMultiplier)
    };
  };
  
  // Form schema for room feature creation
  const addFeatureSchema = z.object({
    name: z.string().min(1, { message: "Name is required" }),
    type: z.string().min(1, { message: "Type is required" }),
    width: z.coerce.number().min(20, { message: "Width must be at least 20" }),
    height: z.coerce.number().min(20, { message: "Height must be at least 20" }),
  });
  
  type AddFeatureFormValues = z.infer<typeof addFeatureSchema>;
  
  const [addFeatureDialogOpen, setAddFeatureDialogOpen] = useState(false);
  const [newLayoutDialogOpen, setNewLayoutDialogOpen] = useState(false);
  const [newLayoutName, setNewLayoutName] = useState("");
  const [isDefaultLayout, setIsDefaultLayout] = useState(false);
  
  const addFeatureForm = useForm<AddFeatureFormValues>({
    resolver: zodResolver(addFeatureSchema),
    defaultValues: {
      name: "",
      type: "entrance",
      width: 100,
      height: 80,
    },
  });
  
  const handleAddFeature = (values: AddFeatureFormValues) => {
    // Default position in the center of the canvas
    let posX = 250;
    let posY = 250;
    
    if (canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      posX = Math.round(rect.width / 2 - values.width / 2);
      posY = Math.round(rect.height / 2 - values.height / 2);
    }
    
    createRoomFeatureMutation.mutate({
      name: values.name,
      type: values.type,
      posX,
      posY,
      width: values.width,
      height: values.height
    });
    
    setAddFeatureDialogOpen(false);
    addFeatureForm.reset();
  };
  
  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Pool Room Layout</h3>
        {editable && (
          <div className="flex space-x-2 items-center">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Toggle 
                    pressed={editMode} 
                    onPressedChange={(value) => {
                      if (editMode && !value) {
                        // Exiting edit mode, save the layout configuration
                        saveLayoutConfigMutation.mutate({
                          name: layoutConfig?.name || "Default Layout",
                          tableSize: Math.round(sizeMultiplier * 100),
                          canvasWidth,
                          currentPage,
                          enableMultiPage: pagesEnabled,
                          isDefault: true
                        });
                      }
                      setEditMode(value);
                    }}
                    aria-label="Toggle edit mode"
                    className="bg-gray-700 text-white hover:bg-gray-800 data-[state=on]:bg-primary data-[state=on]:text-white shadow-md"
                  >
                    {editMode ? (
                      <Save className="h-4 w-4 mr-1 text-white" />
                    ) : (
                      <Edit2 className="h-4 w-4 mr-1 text-white" />
                    )}
                    {editMode ? "Done" : "Edit Layout"}
                  </Toggle>
                </TooltipTrigger>
                <TooltipContent>
                  {editMode 
                    ? "Save layout changes and exit edit mode" 
                    : "Enter edit mode to reposition tables"
                  }
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            {editMode && (
              <>
                {onAddTable && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          variant="default" 
                          size="sm" 
                          className="shadow-md bg-gray-700 text-white hover:bg-gray-800" 
                          onClick={onAddTable}
                        >
                          <Plus className="h-4 w-4 mr-1 text-white" />
                          Add Table
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        Add a new pool table
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
                
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="default" 
                        size="sm" 
                        className="shadow-md bg-green-700 text-white hover:bg-green-800" 
                        onClick={() => setAddFeatureDialogOpen(true)}
                      >
                        <Plus className="h-4 w-4 mr-1 text-white" />
                        Add Room Feature
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      Add a new room feature (entrance, bar, etc.)
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </>
            )}
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="default" 
                    size="sm"
                    className="shadow-md bg-gray-700 text-white hover:bg-gray-800"
                    onClick={() => {
                      refetchTables();
                      refetchFeatures();
                    }}
                    disabled={tablesLoading || featuresLoading}
                  >
                    <RefreshCcw className="h-4 w-4 mr-1 text-white" />
                    Refresh
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  Refresh table data
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        )}
      </div>
      
      {/* Layout Controls */}
      <div className="mb-4 px-2">
        <div className="flex flex-col gap-3">
          {/* Table Size Control */}
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700 min-w-[80px]">Table Size:</span>
            <div className="flex items-center flex-1 max-w-xs">
              <Button 
                variant="outline" 
                size="sm" 
                className="px-2 h-8 rounded-full shadow-sm bg-white hover:bg-primary/5 border-primary/20"
                onClick={() => setSizeMultiplier(Math.max(0.5, sizeMultiplier - 0.1))}
              >
                <Minus className="h-3 w-3" />
              </Button>
              <Slider 
                min={0.5} 
                max={1.5} 
                step={0.1} 
                value={[sizeMultiplier]} 
                onValueChange={(values) => setSizeMultiplier(values[0])}
                className="w-32 mx-3"
              />
              <Button 
                variant="outline" 
                size="sm" 
                className="px-2 h-8 rounded-full shadow-sm bg-white hover:bg-primary/5 border-primary/20"
                onClick={() => setSizeMultiplier(Math.min(1.5, sizeMultiplier + 0.1))}
              >
                <Plus className="h-3 w-3" />
              </Button>
              <span className="ml-2 text-xs text-gray-500">
                {Math.round(sizeMultiplier * 100)}%
              </span>
            </div>
          </div>
          
          {/* Canvas Width Control */}
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700 min-w-[80px]">Canvas Width:</span>
            <div className="flex items-center flex-1 max-w-xs">
              <Button 
                variant="outline" 
                size="sm" 
                className="px-2 h-8 rounded-full shadow-sm bg-white hover:bg-primary/5 border-primary/20"
                onClick={() => setCanvasWidth(Math.max(800, canvasWidth - 100))}
              >
                <Minus className="h-3 w-3" />
              </Button>
              <Slider 
                min={800} 
                max={2400} 
                step={100} 
                value={[canvasWidth]} 
                onValueChange={(values) => setCanvasWidth(values[0])}
                className="w-32 mx-3"
              />
              <Button 
                variant="outline" 
                size="sm" 
                className="px-2 h-8 rounded-full shadow-sm bg-white hover:bg-primary/5 border-primary/20"
                onClick={() => setCanvasWidth(Math.min(2400, canvasWidth + 100))}
              >
                <Plus className="h-3 w-3" />
              </Button>
              <span className="ml-2 text-xs text-gray-500">
                {canvasWidth}px
              </span>
            </div>
          </div>
          
          {/* Page Controls */}
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700 min-w-[80px]">Multi-page:</span>
            <div className="flex items-center flex-1">
              <Switch
                id="pages-enabled"
                checked={pagesEnabled}
                onCheckedChange={setPagesEnabled}
              />
              <Label htmlFor="pages-enabled" className="ml-2 text-sm text-gray-600">
                Enable multiple pages
              </Label>
            </div>
          </div>
          
          {pagesEnabled && (
            <div className="flex items-center space-x-3 justify-center py-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
                disabled={currentPage === 0}
                className="h-8 w-8 p-0 rounded-full"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm font-medium">
                Page {currentPage + 1}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(currentPage + 1)}
                className="h-8 w-8 p-0 rounded-full"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
          
          {/* Layout Configuration Controls */}
          <div className="border-t mt-3 pt-3 flex justify-between">
            <Button
              variant="outline"
              size="sm"
              className="shadow-sm bg-white hover:bg-primary/5 border-primary/20 flex items-center"
              onClick={() => {
                saveLayoutConfigMutation.mutate({
                  name: layoutConfig?.name || "Default Layout",
                  tableSize: Math.round(sizeMultiplier * 100),
                  canvasWidth,
                  currentPage,
                  enableMultiPage: pagesEnabled,
                  isDefault: true,
                });
              }}
            >
              <Save className="h-4 w-4 mr-1.5 text-primary" />
              Save Layout
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              className="shadow-sm bg-white hover:bg-primary/5 border-primary/20 flex items-center"
              onClick={() => setNewLayoutDialogOpen(true)}
            >
              <FilePlus className="h-4 w-4 mr-1.5 text-primary" />
              Create New Layout
            </Button>
          </div>
        </div>
      </div>
      
      {tablesLoading || featuresLoading ? (
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="relative border border-gray-200 rounded-lg overflow-hidden">
          {/* Canvas wrapper with horizontal scroll */}
          <div
            className="overflow-x-auto"
            style={{ 
              maxWidth: '100%', 
              height: pagesEnabled && currentPage > 0 ? '0px' : '600px',
              opacity: pagesEnabled && currentPage > 0 ? 0 : 1,
              display: pagesEnabled && currentPage > 0 ? 'none' : 'block'
            }}
          >
            <div 
              ref={canvasRef}
              className="relative bg-gray-50 h-[600px] rounded-lg"
              style={{ width: `${canvasWidth}px` }}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              {/* Grid pattern for better positioning */}
              {editMode && (
                <div className="absolute inset-0 grid grid-cols-12 grid-rows-12 gap-0 pointer-events-none">
                  {Array.from({ length: 12 }).map((_, rowIndex) => (
                    Array.from({ length: 12 }).map((_, colIndex) => (
                      <div 
                        key={`${rowIndex}-${colIndex}`}
                        className="border border-dashed border-gray-200 opacity-40"
                      />
                    ))
                  ))}
                </div>
              )}
              
              {/* Room features */}
              {roomFeatures.map((feature) => {
                const initialPosX = feature.posX !== undefined ? feature.posX : 0;
                const initialPosY = feature.posY !== undefined ? feature.posY : 0;
                const width = feature.width || 100;
                const height = feature.height || 80;
                
                // Choose icon based on feature type
                let FeatureIcon = Home;
                switch (feature.type.toLowerCase()) {
                  case 'entrance':
                    FeatureIcon = DoorOpen;
                    break;
                  case 'bar':
                    FeatureIcon = GlassWater;
                    break;
                  case 'restroom':
                    FeatureIcon = Users;
                    break;
                  case 'counter':
                    FeatureIcon = PanelTopClose;
                    break;
                  default:
                    FeatureIcon = Home;
                }
                
                return (
                  <div
                    key={feature.id}
                    id={`feature-${feature.id}`}
                    className={`absolute ${editMode ? 'cursor-move' : ''} bg-gray-200 border border-gray-300 flex flex-col items-center justify-center shadow-sm transition-shadow hover:shadow-md`}
                    style={{
                      left: `${initialPosX}px`,
                      top: `${initialPosY}px`,
                      width: `${width}px`,
                      height: `${height}px`,
                      zIndex: isDragging && draggingFeature?.id === feature.id ? 10 : 0
                    }}
                    onMouseDown={(e) => editMode && handleMouseDown(e, feature, true)}
                  >
                    <div className="flex items-center justify-center w-full h-full p-2">
                      <FeatureIcon className="h-4 w-4 mr-1.5 text-gray-600" />
                      <span className="text-sm font-medium text-gray-700">{feature.name}</span>
                    </div>
                    
                    {/* Edit controls */}
                    {editMode && (
                      <div className="absolute -top-3 -right-3 flex space-x-1">
                        <div 
                          className="bg-blue-500 text-white text-xs font-bold rounded-full h-7 w-7 flex items-center justify-center shadow-md border border-white/30 cursor-move"
                        >
                          <Move className="h-4 w-4" />
                        </div>
                        <div 
                          className="bg-red-500 text-white text-xs font-bold rounded-full h-7 w-7 flex items-center justify-center shadow-md border border-white/30 cursor-pointer"
                          onClick={() => handleFeatureAction(feature, 'delete')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
              
              {/* Tables */}
              {tables.map((table) => {
                const { width, height } = getTableSize(table.type);
                const initialPosX = table.posX !== undefined ? table.posX : 100 + (table.id * 50);
                const initialPosY = table.posY !== undefined ? table.posY : 100 + (table.id * 30);
                
                return (
                  <div
                    key={table.id}
                    id={`table-${table.id}`}
                    className={`absolute ${editMode ? 'cursor-move' : 'cursor-pointer'} flex flex-col items-center p-2 rounded shadow-md transition-transform`}
                    style={{
                      left: `${initialPosX}px`,
                      top: `${initialPosY}px`,
                      width: `${width}px`,
                      zIndex: isDragging && draggingTable?.id === table.id ? 10 : 1
                    }}
                    onClick={(e) => handleTableClick(table, e)}
                    onMouseDown={(e) => handleMouseDown(e, table)}
                  >
                    <div 
                      className={`w-full rounded-md ${getStatusColor(table.status)} border-2 flex items-center justify-center`}
                      style={{ height: `${Math.round(height)}px` }}
                    >
                      <span className="text-sm font-semibold">{table.name}</span>
                    </div>
                    
                    {table.status === "in-use" && table.currentUsage && !editMode && (
                      <div className="absolute -top-3 -right-3 bg-primary text-white text-xs font-bold rounded-full h-7 w-7 flex items-center justify-center shadow-md border border-white/30">
                        {formatDuration(table.currentUsage.startTime)}
                      </div>
                    )}
                    
                    {/* Display a small icon if there's additional information */}
                    {table.status === "in-use" && table.currentUsage && !editMode && (
                      <div className="absolute -bottom-2 -left-2 bg-white rounded-full p-1 shadow-md border border-primary/20">
                        <Users className="h-4 w-4 text-primary" />
                      </div>
                    )}
                    
                    {table.status === "reserved" && table.reservation && !editMode && (
                      <div className="absolute -bottom-2 -left-2 bg-white rounded-full p-1 shadow-md border border-yellow-400/30">
                        <Clock className="h-4 w-4 text-yellow-600" />
                      </div>
                    )}
                    
                    {/* Edit mode indicator */}
                    {editMode && (
                      <div className="absolute -top-3 -right-3 bg-blue-500 text-white text-xs font-bold rounded-full h-7 w-7 flex items-center justify-center shadow-md border border-white/30">
                        <Move className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* Page 2+ content (visible only when pagesEnabled is true and currentPage > 0) */}
          {pagesEnabled && currentPage > 0 && (
            <div className="h-[600px] bg-gray-50 rounded-lg flex items-center justify-center">
              <div className="text-center p-8">
                <h3 className="text-xl font-bold mb-2">Page {currentPage + 1}</h3>
                <p className="text-gray-500 mb-4">This page is in development</p>
                <p className="text-sm text-gray-400">You can add content for additional pool hall spaces here</p>
              </div>
            </div>
          )}
        </div>
      )}
      
      {/* Add Room Feature Dialog */}
      <Dialog open={addFeatureDialogOpen} onOpenChange={setAddFeatureDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Room Feature</DialogTitle>
            <DialogDescription>
              Add structural elements like entrance, bar areas, restrooms, or counters to match your physical space.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...addFeatureForm}>
            <form onSubmit={addFeatureForm.handleSubmit(handleAddFeature)} className="space-y-4">
              <FormField
                control={addFeatureForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Main Entrance" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addFeatureForm.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Type</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select feature type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="entrance">Entrance</SelectItem>
                        <SelectItem value="bar">Bar Area</SelectItem>
                        <SelectItem value="restroom">Restroom</SelectItem>
                        <SelectItem value="counter">Counter/Desk</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={addFeatureForm.control}
                  name="width"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Width (px)</FormLabel>
                      <FormControl>
                        <Input type="number" min="20" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={addFeatureForm.control}
                  name="height"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Height (px)</FormLabel>
                      <FormControl>
                        <Input type="number" min="20" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setAddFeatureDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Add Feature</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* New Layout Configuration Dialog */}
      <Dialog open={newLayoutDialogOpen} onOpenChange={setNewLayoutDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Layout Configuration</DialogTitle>
            <DialogDescription>
              Create a new layout configuration with the current setup.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="layout-name">Layout Name</Label>
              <Input 
                id="layout-name" 
                placeholder="e.g., Competition Layout, Evening Setup"
                value={newLayoutName}
                onChange={(e) => setNewLayoutName(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="default-layout" 
                  checked={isDefaultLayout}
                  onCheckedChange={(checked) => setIsDefaultLayout(checked === true)}
                />
                <Label htmlFor="default-layout">Set as default layout</Label>
              </div>
              <p className="text-xs text-muted-foreground">
                The default layout will be loaded automatically when the page loads.
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setNewLayoutName("");
                setIsDefaultLayout(false);
                setNewLayoutDialogOpen(false);
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={() => {
                if (newLayoutName) {
                  saveLayoutConfigMutation.mutate({
                    name: newLayoutName,
                    tableSize: Math.round(sizeMultiplier * 100),
                    canvasWidth,
                    currentPage,
                    enableMultiPage: pagesEnabled,
                    isDefault: isDefaultLayout
                  });
                  setNewLayoutName("");
                  setIsDefaultLayout(false);
                  setNewLayoutDialogOpen(false);
                }
              }}
              disabled={!newLayoutName}
            >
              Create Layout
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Helper function to format duration
function formatDuration(startTime: string | Date): string {
  const start = new Date(startTime);
  const now = new Date();
  const diffInMs = now.getTime() - start.getTime();
  const diffInMins = Math.floor(diffInMs / (1000 * 60));
  
  if (diffInMins < 60) {
    return `${diffInMins}m`;
  } else {
    const hours = Math.floor(diffInMins / 60);
    const mins = diffInMins % 60;
    return `${hours}h ${mins}m`;
  }
}

// Helper function to calculate charges
function calculateCharge(startTime: string | Date, hourlyRate: string | number): string {
  const start = new Date(startTime);
  const now = new Date();
  const diffInMs = now.getTime() - start.getTime();
  const diffInHours = diffInMs / (1000 * 60 * 60);
  
  return (diffInHours * Number(hourlyRate)).toFixed(2);
}