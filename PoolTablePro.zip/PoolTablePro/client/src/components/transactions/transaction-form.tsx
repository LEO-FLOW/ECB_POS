import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTransactionSchema } from "@shared/schema";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

interface TransactionFormProps {
  onSuccess?: () => void;
}

const formSchema = insertTransactionSchema.extend({
  customerId: z.string().optional(),
  tableUsageId: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export function TransactionForm({ onSuccess }: TransactionFormProps) {
  const { toast } = useToast();
  
  const { data: members, isLoading: membersLoading } = useQuery({
    queryKey: ["/api/members"],
  });
  
  const { data: activeTableUsages, isLoading: tableUsagesLoading } = useQuery({
    queryKey: ["/api/table-usage/active"],
  });
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      userId: undefined,
      amount: undefined,
      type: "",
      description: "",
      relatedTableUsageId: undefined,
      customerId: undefined,
      tableUsageId: undefined,
    },
  });
  
  const createTransactionMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/transactions", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/recent"] });
      toast({
        title: "Transaction created",
        description: "The transaction has been recorded successfully",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create transaction: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: FormData) => {
    const formattedData = {
      ...data,
      userId: data.customerId ? parseInt(data.customerId) : undefined,
      amount: parseFloat(data.amount as any),
      relatedTableUsageId: data.tableUsageId ? parseInt(data.tableUsageId) : undefined,
    };
    
    delete formattedData.customerId;
    delete formattedData.tableUsageId;
    
    createTransactionMutation.mutate(formattedData);
  };
  
  const transactionTypes = [
    { value: "table-session", label: "Table Session" },
    { value: "membership", label: "Membership" },
    { value: "food-drinks", label: "Food & Drinks" },
    { value: "other", label: "Other" },
  ];
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Transaction Type</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select transaction type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {transactionTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="amount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Amount ($)</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  step="0.01" 
                  placeholder="0.00" 
                  {...field}
                  onChange={(e) => field.onChange(e.target.value === "" ? undefined : e.target.value)}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="customerId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Customer (Optional)</FormLabel>
              <Select 
                onValueChange={field.onChange} 
                defaultValue={field.value?.toString()}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a customer" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="">Guest (non-member)</SelectItem>
                  {membersLoading ? (
                    <SelectItem value="loading" disabled>Loading members...</SelectItem>
                  ) : (
                    members?.map((member: any) => (
                      <SelectItem key={member.id} value={member.id.toString()}>
                        {member.fullName}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {form.watch("type") === "table-session" && (
          <FormField
            control={form.control}
            name="tableUsageId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Related Table Session</FormLabel>
                <Select 
                  onValueChange={field.onChange} 
                  defaultValue={field.value?.toString()}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a table session" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="">Manual entry (no table session)</SelectItem>
                    {tableUsagesLoading ? (
                      <SelectItem value="loading" disabled>Loading active sessions...</SelectItem>
                    ) : activeTableUsages?.length === 0 ? (
                      <SelectItem value="none" disabled>No active table sessions</SelectItem>
                    ) : (
                      activeTableUsages?.map((usage: any) => (
                        <SelectItem key={usage.id} value={usage.id.toString()}>
                          Table {usage.tableId} - {usage.userName || "Guest"}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Enter transaction details" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Button 
          type="submit" 
          className="w-full bg-accent hover:bg-accent-light"
          disabled={createTransactionMutation.isPending}
        >
          {createTransactionMutation.isPending ? "Processing Transaction..." : "Process Transaction"}
        </Button>
      </form>
    </Form>
  );
}
