import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { Footer } from "./footer";
import { 
  LayoutDashboard, 
  Table, 
  Calendar, 
  Users, 
  CreditCard, 
  Bell, 
  LogOut, 
  Menu, 
  X,
  UserCog,
  Package
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useMobile } from "@/hooks/use-mobile";

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const isMobile = useMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        toast({
          title: "Logged out",
          description: "You have been successfully logged out",
        });
      }
    });
  };
  
  const navItems = [
    { href: "/", label: "Dashboard", icon: <LayoutDashboard className="w-5 h-5" /> },
    { href: "/tables", label: "Tables", icon: <Table className="w-5 h-5" /> },
    { href: "/reservations", label: "Reservations", icon: <Calendar className="w-5 h-5" /> },
    { href: "/members", label: "Members", icon: <Users className="w-5 h-5" /> },
    { href: "/transactions", label: "Transactions", icon: <CreditCard className="w-5 h-5" /> },
    { href: "/coaching", label: "Coaching", icon: <UserCog className="w-5 h-5" /> },
    { href: "/inventory", label: "Inventory", icon: <Package className="w-5 h-5" /> },
  ];
  
  const userInitials = user?.fullName 
    ? user.fullName.split(" ").map(n => n[0]).join("").toUpperCase()
    : user?.username?.substring(0, 2).toUpperCase() || "U";
  
  return (
    <div className="min-h-screen flex flex-col">
      {/* Main Navigation */}
      <nav className="bg-primary text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-8 h-8 bg-accent rounded-full mr-2"></div>
                <span className="font-heading font-bold text-xl">CueBall Manager</span>
              </div>
              <div className="hidden md:ml-6 md:flex md:space-x-8">
                {/* Desktop Navigation */}
                {navItems.map((item) => (
                  <Link 
                    key={item.href} 
                    href={item.href}
                    className={`
                      border-b-2 px-1 pt-1 text-sm font-medium
                      ${location === item.href 
                        ? "border-accent" 
                        : "border-transparent hover:border-gray-300"}
                    `}
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>
            <div className="flex items-center">
              <div className="hidden md:ml-4 md:flex md:items-center">
                <Button 
                  size="icon"
                  variant="ghost"
                  className="hover:bg-primary-light text-white"
                >
                  <Bell className="h-5 w-5" />
                </Button>
                <div className="ml-4 relative">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center p-0"
                      >
                        <span className="text-white font-semibold">{userInitials}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={handleLogout}>
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>Log out</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
              <div className="-mr-2 flex md:hidden">
                {/* Mobile menu button */}
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-white"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                >
                  {mobileMenuOpen ? (
                    <X className="block h-6 w-6" />
                  ) : (
                    <Menu className="block h-6 w-6" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden">
            <div className="pt-2 pb-3 space-y-1">
              {navItems.map((item) => (
                <Link 
                  key={item.href} 
                  href={item.href}
                  className={`
                    flex items-center px-3 py-2 text-base font-medium
                    ${location === item.href
                      ? "bg-primary-light text-white"
                      : "text-gray-300 hover:bg-primary-light hover:text-white"}
                  `}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </Link>
              ))}
            </div>
            <div className="pt-4 pb-3 border-t border-gray-700">
              <div className="flex items-center px-5">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
                    <span className="text-white font-semibold">{userInitials}</span>
                  </div>
                </div>
                <div className="ml-3">
                  <div className="text-base font-medium text-white">{user?.fullName}</div>
                  <div className="text-sm font-medium text-gray-300">{user?.username}</div>
                </div>
                <Button 
                  size="icon"
                  variant="ghost"
                  className="ml-auto text-white hover:bg-primary-light"
                >
                  <Bell className="h-6 w-6" />
                </Button>
              </div>
              <div className="mt-3 px-2 space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-gray-300 hover:bg-primary-light hover:text-white"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-3 h-5 w-5" />
                  Log out
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Page Content */}
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          {children}
        </div>
      </main>

      <Footer />
    </div>
  );
}
