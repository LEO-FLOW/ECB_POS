import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckIcon } from "lucide-react";

interface MembershipTier {
  id: number;
  name: string;
  monthlyPrice: number;
  tableRateDiscount: number;
  foodDrinkDiscount: number;
  guestPasses: number;
  advanceReservationDays: number;
  description: string;
}

interface MembershipStats {
  totalMembers: number;
  activeMembers: number;
  monthlyRevenue: number;
  retentionRate: number;
  newMembersThisMonth: number;
  expiringMemberships: number;
  monthlyRevenueChange: number;
  retentionRateChange: number;
}

interface MembershipSummaryProps {
  stats?: MembershipStats;
  tiers?: MembershipTier[];
}

export function MembershipSummary({ stats, tiers }: MembershipSummaryProps) {
  const isLoading = !stats || !tiers;
  
  const formatTierName = (name: string) => {
    return name.charAt(0).toUpperCase() + name.slice(1);
  };
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };
  
  const formatPercent = (value: number) => {
    return `${value}%`;
  };
  
  return (
    <div className="mb-8">
      <h2 className="text-lg font-heading font-semibold text-gray-900 mb-4">Membership Overview</h2>
      <Card>
        <CardHeader>
          <CardTitle>Membership Statistics</CardTitle>
          <p className="text-sm text-gray-500">Overview of current membership status and activity.</p>
        </CardHeader>
        
        <div className="border-t border-gray-200">
          <div className="bg-gray-50 px-4 py-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <dt className="text-sm font-medium text-gray-500">Total Members</dt>
              {isLoading ? (
                <dd className="mt-1 h-8 w-20 bg-gray-200 animate-pulse rounded"></dd>
              ) : (
                <>
                  <dd className="mt-1 text-3xl font-semibold text-gray-900">{stats.totalMembers}</dd>
                  <p className="text-sm text-gray-500 mt-1">
                    <span className="text-green-600">+{stats.newMembersThisMonth}</span> this month
                  </p>
                </>
              )}
            </div>
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Active Memberships</dt>
              {isLoading ? (
                <dd className="mt-1 h-8 w-20 bg-gray-200 animate-pulse rounded"></dd>
              ) : (
                <>
                  <dd className="mt-1 text-3xl font-semibold text-gray-900">{stats.activeMembers}</dd>
                  <p className="text-sm text-gray-500 mt-1">
                    <span className="text-yellow-600">-{stats.expiringMemberships}</span> expirations pending
                  </p>
                </>
              )}
            </div>
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Average Monthly Revenue</dt>
              {isLoading ? (
                <dd className="mt-1 h-8 w-20 bg-gray-200 animate-pulse rounded"></dd>
              ) : (
                <>
                  <dd className="mt-1 text-3xl font-semibold text-gray-900">{formatCurrency(stats.monthlyRevenue)}</dd>
                  <p className="text-sm text-gray-500 mt-1">
                    <span className={stats.monthlyRevenueChange >= 0 ? "text-green-600" : "text-red-600"}>
                      {stats.monthlyRevenueChange >= 0 ? "+" : ""}{formatPercent(stats.monthlyRevenueChange)}
                    </span> from last month
                  </p>
                </>
              )}
            </div>
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Member Retention Rate</dt>
              {isLoading ? (
                <dd className="mt-1 h-8 w-20 bg-gray-200 animate-pulse rounded"></dd>
              ) : (
                <>
                  <dd className="mt-1 text-3xl font-semibold text-gray-900">{formatPercent(stats.retentionRate)}</dd>
                  <p className="text-sm text-gray-500 mt-1">
                    <span className={stats.retentionRateChange >= 0 ? "text-green-600" : "text-red-600"}>
                      {stats.retentionRateChange >= 0 ? "+" : ""}{formatPercent(stats.retentionRateChange)}
                    </span> from last quarter
                  </p>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-200 bg-white">
          <h3 className="text-lg font-medium text-gray-900 px-4 py-5 sm:px-6">Membership Tiers</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 p-4">
            {isLoading ? (
              <>
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="border rounded-lg p-4 bg-gray-50 animate-pulse">
                    <div className="h-6 w-24 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 w-40 bg-gray-200 rounded mb-4"></div>
                    <div className="h-8 w-28 bg-gray-200 rounded mb-4"></div>
                    <div className="space-y-2">
                      <div className="h-4 w-full bg-gray-200 rounded"></div>
                      <div className="h-4 w-full bg-gray-200 rounded"></div>
                      <div className="h-4 w-full bg-gray-200 rounded"></div>
                    </div>
                  </div>
                ))}
              </>
            ) : (
              <>
                {tiers.map((tier) => (
                  <div 
                    key={tier.id} 
                    className={`border rounded-lg p-4 bg-gray-50 ${
                      tier.name === "silver" || tier.name === "gold" ? "border-accent" : ""
                    }`}
                  >
                    <h4 className="font-heading font-semibold text-gray-900">{formatTierName(tier.name)} Tier</h4>
                    <p className="text-sm text-gray-600 mt-1">{tier.description}</p>
                    <div className="mt-2">
                      <span className="text-2xl font-bold text-primary">{formatCurrency(tier.monthlyPrice)}</span>
                      <span className="text-gray-500 text-sm">/month</span>
                    </div>
                    <ul className="mt-4 space-y-2">
                      <li className="flex items-center text-sm">
                        <CheckIcon className="h-5 w-5 text-green-500 mr-2" />
                        {formatPercent(tier.tableRateDiscount * 100)} discount on table rates
                      </li>
                      {tier.foodDrinkDiscount > 0 && (
                        <li className="flex items-center text-sm">
                          <CheckIcon className="h-5 w-5 text-green-500 mr-2" />
                          {formatPercent(tier.foodDrinkDiscount * 100)} discount on food and drinks
                        </li>
                      )}
                      {tier.advanceReservationDays > 0 && (
                        <li className="flex items-center text-sm">
                          <CheckIcon className="h-5 w-5 text-green-500 mr-2" />
                          {tier.name === "silver" ? "Priority" : "VIP"} reservations
                          {tier.name === "gold" && ` (${tier.advanceReservationDays} days ahead)`}
                        </li>
                      )}
                      {tier.guestPasses > 0 && (
                        <li className="flex items-center text-sm">
                          <CheckIcon className="h-5 w-5 text-green-500 mr-2" />
                          {tier.guestPasses} free guest {tier.guestPasses === 1 ? "pass" : "passes"} per month
                        </li>
                      )}
                      {tier.name === "bronze" && (
                        <li className="flex items-center text-sm">
                          <CheckIcon className="h-5 w-5 text-green-500 mr-2" />
                          Access to members-only events
                        </li>
                      )}
                      {tier.name === "gold" && (
                        <li className="flex items-center text-sm">
                          <CheckIcon className="h-5 w-5 text-green-500 mr-2" />
                          Free entry to tournaments
                        </li>
                      )}
                    </ul>
                    <div className="mt-4">
                      <span className="text-xs font-medium text-gray-500">
                        {/* Placeholder for active member count per tier */}
                        {Math.floor(Math.random() * 50) + 30} active members
                      </span>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
