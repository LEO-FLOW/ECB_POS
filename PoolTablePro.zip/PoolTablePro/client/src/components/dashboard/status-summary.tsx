import { Card, CardContent } from "@/components/ui/card";
import { CheckIcon, ClockIcon, Calendar, Users } from "lucide-react";

interface StatusSummaryProps {
  tables?: {
    id: number;
    status: string;
  }[];
  members?: {
    totalMembers: number;
    activeMembers: number;
    memberIncreasePercentage: number;
  };
}

export function StatusSummary({ tables = [], members }: StatusSummaryProps) {
  // Calculate table stats
  const availableTables = tables.filter(t => t.status === "available").length;
  const inUseTables = tables.filter(t => t.status === "in-use").length;
  const reservedTables = tables.filter(t => t.status === "reserved").length;
  const totalTables = tables.length;
  
  const availablePercentage = totalTables ? Math.round((availableTables / totalTables) * 100) : 0;
  const inUsePercentage = totalTables ? Math.round((inUseTables / totalTables) * 100) : 0;
  const reservedPercentage = totalTables ? Math.round((reservedTables / totalTables) * 100) : 0;
  
  const isLoading = !tables || tables.length === 0;
  
  return (
    <div className="mb-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {/* Available Tables */}
      <Card>
        <CardContent className="px-4 py-5">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-green-500 text-white rounded-md p-3">
              <CheckIcon className="h-6 w-6" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">
                  Available Tables
                </dt>
                <dd className="flex items-baseline">
                  {isLoading ? (
                    <div className="h-8 w-16 bg-gray-200 animate-pulse rounded"></div>
                  ) : (
                    <>
                      <div className="text-2xl font-semibold text-gray-900">
                        {availableTables}
                      </div>
                      <div className="ml-2 flex items-baseline text-sm font-semibold text-green-500">
                        <span>{availablePercentage}%</span>
                      </div>
                    </>
                  )}
                </dd>
              </dl>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* In-Use Tables */}
      <Card>
        <CardContent className="px-4 py-5">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-red-500 text-white rounded-md p-3">
              <ClockIcon className="h-6 w-6" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">
                  In-Use Tables
                </dt>
                <dd className="flex items-baseline">
                  {isLoading ? (
                    <div className="h-8 w-16 bg-gray-200 animate-pulse rounded"></div>
                  ) : (
                    <>
                      <div className="text-2xl font-semibold text-gray-900">
                        {inUseTables}
                      </div>
                      <div className="ml-2 flex items-baseline text-sm font-semibold text-red-500">
                        <span>{inUsePercentage}%</span>
                      </div>
                    </>
                  )}
                </dd>
              </dl>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Reserved Tables */}
      <Card>
        <CardContent className="px-4 py-5">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-yellow-500 text-white rounded-md p-3">
              <Calendar className="h-6 w-6" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">
                  Reserved Tables
                </dt>
                <dd className="flex items-baseline">
                  {isLoading ? (
                    <div className="h-8 w-16 bg-gray-200 animate-pulse rounded"></div>
                  ) : (
                    <>
                      <div className="text-2xl font-semibold text-gray-900">
                        {reservedTables}
                      </div>
                      <div className="ml-2 flex items-baseline text-sm font-semibold text-yellow-500">
                        <span>{reservedPercentage}%</span>
                      </div>
                    </>
                  )}
                </dd>
              </dl>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Members */}
      <Card>
        <CardContent className="px-4 py-5">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-primary text-white rounded-md p-3">
              <Users className="h-6 w-6" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">
                  Active Members
                </dt>
                <dd className="flex items-baseline">
                  {!members ? (
                    <div className="h-8 w-16 bg-gray-200 animate-pulse rounded"></div>
                  ) : (
                    <>
                      <div className="text-2xl font-semibold text-gray-900">
                        {members.activeMembers}
                      </div>
                      <div className="ml-2 flex items-baseline text-sm font-semibold text-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 self-center" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                        </svg>
                        <span className="ml-1">{members.memberIncreasePercentage}%</span>
                      </div>
                    </>
                  )}
                </dd>
              </dl>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
