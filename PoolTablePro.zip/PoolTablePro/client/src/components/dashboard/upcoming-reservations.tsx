import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { format, isToday, isTomorrow } from "date-fns";

interface UpcomingReservationsProps {
  reservations?: any[];
}

export function UpcomingReservations({ reservations = [] }: UpcomingReservationsProps) {
  const formatDate = (date: string | Date) => {
    const dateObj = new Date(date);
    if (isToday(dateObj)) return "Today";
    if (isTomorrow(dateObj)) return "Tomorrow";
    return format(dateObj, "MMM d");
  };
  
  const getInitials = (name: string) => {
    if (!name) return "?";
    return name.split(" ").map(n => n[0]).join("");
  };
  
  return (
    <div>
      <h2 className="text-lg font-heading font-semibold text-gray-900 mb-4">Upcoming Reservations</h2>
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        {!reservations || reservations.length === 0 ? (
          <div className="py-12 text-center">
            <p className="text-gray-500">No upcoming reservations</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {reservations.slice(0, 4).map((reservation) => (
              <li key={reservation.id}>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div 
                        className="h-10 w-10 rounded-full bg-accent flex items-center justify-center text-white font-semibold"
                      >
                        <span>{getInitials(reservation.customerName)}</span>
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-900">{reservation.customerName}</p>
                        <p className="text-sm text-gray-500">
                          Table {reservation.tableId} • {format(new Date(reservation.startTime), "h:mm a")} - {format(new Date(reservation.endTime), "h:mm a")}
                        </p>
                      </div>
                    </div>
                    <div className="ml-2 flex-shrink-0 flex">
                      <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                        {formatDate(reservation.date)}
                      </p>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
        <div className="bg-gray-50 px-4 py-3 text-right sm:px-6">
          <Link href="/reservations">
            <Button variant="outline" size="sm">
              View All Reservations
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
