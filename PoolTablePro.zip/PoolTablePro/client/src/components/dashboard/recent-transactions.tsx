import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { format, formatDistanceToNow } from "date-fns";

interface RecentTransactionsProps {
  transactions?: any[];
}

export function RecentTransactions({ transactions = [] }: RecentTransactionsProps) {
  const formatTransactionType = (type: string) => {
    switch (type) {
      case "table-session":
        return "Table Session";
      case "membership":
        return "Membership";
      case "food-drinks":
        return "Food & Drinks";
      default:
        return type;
    }
  };
  
  const formatTimeAgo = (date: string | Date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };
  
  return (
    <div>
      <h2 className="text-lg font-heading font-semibold text-gray-900 mb-4">Recent Transactions</h2>
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        {!transactions || transactions.length === 0 ? (
          <div className="py-12 text-center">
            <p className="text-gray-500">No recent transactions</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {transactions.slice(0, 4).map((transaction) => (
              <li key={transaction.id}>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {formatTransactionType(transaction.type)}
                      </p>
                      <p className="text-sm text-gray-500">
                        {transaction.description}
                      </p>
                    </div>
                    <div className="ml-2 flex-shrink-0 flex">
                      <p className="text-sm font-medium text-gray-900">
                        ${Number(transaction.amount).toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <div className="mt-2 text-xs text-gray-500">
                    {formatTimeAgo(transaction.timestamp)}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
        <div className="bg-gray-50 px-4 py-3 text-right sm:px-6">
          <Link href="/transactions">
            <Button variant="outline" size="sm">
              View All Transactions
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
