import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { TableCard } from "@/components/tables/table-card";

interface PoolTableGridProps {
  tables: any[];
}

export function PoolTableGrid({ tables }: PoolTableGridProps) {
  const { toast } = useToast();
  
  const updateTableStatusMutation = useMutation({
    mutationFn: async ({ tableId, status }: { tableId: number, status: string }) => {
      return apiRequest("PATCH", `/api/tables/${tableId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update table status: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const startSessionMutation = useMutation({
    mutationFn: async ({ tableId, userId }: { tableId: number, userId?: number }) => {
      return apiRequest("POST", `/api/table-usage`, { tableId, userId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      toast({
        title: "Success",
        description: "Table session started successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to start session: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const endSessionMutation = useMutation({
    mutationFn: async (tableUsageId: number) => {
      return apiRequest("PATCH", `/api/table-usage/${tableUsageId}/end`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      queryClient.invalidateQueries({ queryKey: ["/api/table-usage"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Success",
        description: "Table session ended and charge applied",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to end session: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleTableAction = (tableId: number, currentStatus: string, tableUsageId?: number) => {
    if (currentStatus === "available") {
      startSessionMutation.mutate({ tableId });
    } else if (currentStatus === "in-use" && tableUsageId) {
      endSessionMutation.mutate(tableUsageId);
    } else if (currentStatus === "reserved") {
      startSessionMutation.mutate({ tableId });
    }
  };
  
  return (
    <div className="mb-8">
      <h2 className="text-lg font-heading font-semibold text-gray-900 mb-4">Pool Tables Status</h2>
      {!tables || tables.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-500">No tables available</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {tables.map((table) => (
            <TableCard 
              key={table.id} 
              table={table} 
              onTableAction={handleTableAction} 
              isLoading={
                startSessionMutation.isPending || 
                endSessionMutation.isPending
              }
            />
          ))}
        </div>
      )}
    </div>
  );
}
