import { useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { User, TableSessionCustomer } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter, 
  DialogDescription 
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { 
  Command, 
  CommandEmpty, 
  CommandGroup, 
  CommandInput, 
  CommandItem,
  CommandSeparator,
} from '@/components/ui/command';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { Check, ChevronsUpDown, UserPlus, User as UserIcon, Users } from 'lucide-react';
import { cn } from '@/lib/utils';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { MemberForm } from '@/components/members/member-form';

interface CustomerSelectorProps {
  value?: number | null;
  onValueChange: (value: number | null, name?: string) => void;
  allowGuest?: boolean;
  allowNewCustomer?: boolean;
  tableUsageId?: number; // To filter walk-in customers relevant to this table
}

export function CustomerSelector({ 
  value, 
  onValueChange, 
  allowGuest = true, 
  allowNewCustomer = true,
  tableUsageId,
}: CustomerSelectorProps) {
  const [open, setOpen] = useState(false);
  const [showNewCustomerDialog, setShowNewCustomerDialog] = useState(false);

  // Get registered members and walk-in customers
  // Using random key to force refresh on every component render
  const cacheKey = useRef(Math.random().toString()).current;
  const { data: members = [], isLoading: isLoadingMembers } = useQuery<User[]>({
    queryKey: ["/api/members", cacheKey],
    refetchOnMount: "always", // Always refresh when component mounts/remounts
    refetchOnWindowFocus: true, // Refresh when window gets focus
    staleTime: 0 // Consider data stale immediately
  });

  // Query for table session customers - we want ALL customers including members and walk-ins
  const { data: tableSessionCustomers = [], isLoading: isLoadingCustomers } = useQuery<TableSessionCustomer[]>({
    queryKey: ["/api/table-session-customers", cacheKey], // Use same cache key to force refresh
    // Include all customers but exclude ones from the current table
    select: (data) => {
      console.log("All table session customers:", JSON.stringify(data));
      return data.filter(c => {
        // If we're adding to a table, don't show customers already on that table
        const notOnCurrentTable = !tableUsageId || c.tableUsageId !== tableUsageId;
        return notOnCurrentTable;
      });
    },
    refetchOnMount: "always", 
    refetchOnWindowFocus: true,
    staleTime: 0
  });

  // Extract unique walk-in customers (by name) to avoid duplicates
  const uniqueWalkIns = tableSessionCustomers.reduce((acc, customer) => {
    // Only include walk-in customers (with isWalkIn flag)
    if (customer.isWalkIn && customer.customerName && !acc.some(c => c.customerName === customer.customerName)) {
      console.log("Found walk-in customer:", customer);
      acc.push(customer);
    }
    return acc;
  }, [] as TableSessionCustomer[]);
  
  // Extract non-walk-in customers (registered customers who aren't members)
  const registeredNonMembers = tableSessionCustomers.reduce((acc, customer) => {
    // Include customers who aren't walk-ins and have a userId but aren't in the members list
    if (!customer.isWalkIn && customer.userId && customer.customerName && 
        !acc.some(c => c.userId === customer.userId) && 
        !members.some(m => m.id === customer.userId)) {
      acc.push(customer);
    }
    return acc;
  }, [] as TableSessionCustomer[]);
  
  console.log("Unique walk-ins:", uniqueWalkIns.length);
  console.log("Registered non-members:", registeredNonMembers.length);

  // Find selected member name
  const selectedMember = value ? members.find(member => {
    // Handle both normal numeric IDs and string IDs for walk-in customers
    return typeof member.id === 'number' ? member.id === value : false;
  }) : null;
  
  const handleSelectGuest = () => {
    onValueChange(null);
    setOpen(false);
  };

  const handleAddNewCustomer = () => {
    setShowNewCustomerDialog(true);
    setOpen(false);
  };

  const handleCreateNewCustomer = async (user: User) => {
    try {
      // Use the table's current usage ID if available to add the customer to the session
      if (tableUsageId) {
        // Create a new table session customer directly
        const response = await apiRequest('POST', '/api/table-session-customers', {
          tableUsageId,
          customerName: user.fullName,
          userId: user.id,
          isWalkIn: user.isWalkIn || false,
        });
        
        const newCustomer = await response.json();
        // Invalidate the customers query to force a refresh
        queryClient.invalidateQueries({ queryKey: ['/api/table-session-customers'] });
        
        // Update the value immediately
        if (user.isWalkIn) {
          onValueChange(null, user.fullName);
        } else {
          onValueChange(user.id, user.fullName);
        }
      } else {
        // Just pass the name if we're not adding to a current session
        if (user.isWalkIn) {
          onValueChange(null, user.fullName);
        } else {
          onValueChange(user.id, user.fullName);
        }
      }
      
      // Close dialog
      setShowNewCustomerDialog(false);
      
      // Force a re-query of the customers list
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
    } catch (error) {
      console.error('Error creating new customer:', error);
    }
  };
  
  const handleSelectWalkIn = (name: string) => {
    onValueChange(null, name || 'Walk-in Customer');
    setOpen(false);
  };

  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-full justify-between"
          >
            {value && selectedMember
              ? selectedMember.fullName 
              : value === null && !selectedMember
              ? "Walk-in Customer"
              : "Select customer..."}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[300px] p-0">
          <Command>
            <CommandInput placeholder="Search members..." />
            <CommandEmpty>No members found.</CommandEmpty>
            <CommandGroup>
              {allowGuest && (
                <CommandItem
                  onSelect={handleSelectGuest}
                  className="flex items-center"
                >
                  <UserIcon className="mr-2 h-4 w-4" />
                  <span>Walk-in Customer</span>
                  {value === null && <Check className="ml-auto h-4 w-4" />}
                </CommandItem>
              )}
              
              {/* Registered members */}
              <CommandGroup heading="Members">
                {isLoadingMembers ? (
                  <CommandItem>Loading members...</CommandItem>
                ) : members.length > 0 ? (
                  members.map((member) => {
                    // Check if this is a walk-in customer (string ID) or a registered member (number ID)
                    const isWalkIn = typeof member.id === 'string' && String(member.id).startsWith('walkin-');
                    
                    return (
                      <CommandItem
                        key={member.id}
                        onSelect={() => {
                          if (isWalkIn) {
                            // For walk-ins, pass the name instead of the ID
                            onValueChange(null, member.username || 'Walk-in Customer');
                          } else {
                            // For registered members, pass the numeric ID
                            onValueChange(member.id as number);
                          }
                          setOpen(false);
                        }}
                        className="flex items-center"
                      >
                        {isWalkIn ? (
                          <Users className="mr-2 h-4 w-4" />
                        ) : (
                          <UserIcon className="mr-2 h-4 w-4" />
                        )}
                        <span>{member.fullName || member.username || 'Walk-in Customer'}</span>
                        {!isWalkIn && member.id === value && <Check className="ml-auto h-4 w-4" />}
                      </CommandItem>
                    );
                  })
                ) : (
                  <CommandItem disabled>No members found</CommandItem>
                )}
              </CommandGroup>
              
              {/* Walk-in customers */}
              {uniqueWalkIns.length > 0 && (
                <CommandGroup heading="Recent Walk-in Customers">
                  {isLoadingCustomers ? (
                    <CommandItem>Loading walk-in customers...</CommandItem>
                  ) : (
                    uniqueWalkIns.map((customer) => (
                      <CommandItem
                        key={customer.id}
                        onSelect={() => handleSelectWalkIn(customer.customerName || 'Walk-in Customer')}
                        className="flex items-center"
                      >
                        <Users className="mr-2 h-4 w-4" />
                        <span>{customer.customerName || 'Walk-in Customer'}</span>
                      </CommandItem>
                    ))
                  )}
                </CommandGroup>
              )}
              
              {/* Registered non-members */}
              {registeredNonMembers.length > 0 && (
                <CommandGroup heading="Registered Customers">
                  {isLoadingCustomers ? (
                    <CommandItem>Loading registered customers...</CommandItem>
                  ) : (
                    registeredNonMembers.map((customer) => (
                      <CommandItem
                        key={customer.id}
                        onSelect={() => {
                          // For registered non-members, pass the userId
                          onValueChange(customer.userId || null, customer.customerName);
                          setOpen(false);
                        }}
                        className="flex items-center"
                      >
                        <UserIcon className="mr-2 h-4 w-4" />
                        <span>{customer.customerName}</span>
                      </CommandItem>
                    ))
                  )}
                </CommandGroup>
              )}
              
              {/* Add new customer option */}
              {allowNewCustomer && (
                <>
                  <CommandSeparator />
                  <CommandItem
                    onSelect={handleAddNewCustomer}
                    className="flex items-center text-primary"
                  >
                    <UserPlus className="mr-2 h-4 w-4" />
                    <span>Add new customer</span>
                  </CommandItem>
                </>
              )}
            </CommandGroup>
          </Command>
        </PopoverContent>
      </Popover>
      
      {/* New Customer Dialog */}
      <Dialog open={showNewCustomerDialog} onOpenChange={setShowNewCustomerDialog}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Customer</DialogTitle>
            <DialogDescription>
              Enter customer details to add them to this session.
            </DialogDescription>
          </DialogHeader>
          
          <MemberForm 
            onSuccess={handleCreateNewCustomer}
            onCancel={() => setShowNewCustomerDialog(false)}
            mode="customer"
            autoFocus
          />
        </DialogContent>
      </Dialog>
    </>
  );
}