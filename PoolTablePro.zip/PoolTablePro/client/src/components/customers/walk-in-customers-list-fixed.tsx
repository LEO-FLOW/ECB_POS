import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { TableSessionCustomer } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { UserPlus, UserRound, Users } from 'lucide-react';

export function WalkInCustomersListFixed() {
  const [convertDialogOpen, setConvertDialogOpen] = useState(false);
  const [addWalkInDialogOpen, setAddWalkInDialogOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<TableSessionCustomer | null>(null);
  const [newWalkInName, setNewWalkInName] = useState('');
  const [memberData, setMemberData] = useState({
    fullName: '',
    email: '',
    phoneNumber: '',
    membershipTier: 'none',
    isWalkIn: true
  });
  const { toast } = useToast();
  
  // Query all table session customers
  const { data: tableSessionCustomers = [], isLoading } = useQuery<TableSessionCustomer[]>({
    queryKey: ["/api/table-session-customers"],
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
    staleTime: 0
  });
  
  // Add debugging logging
  useEffect(() => {
    console.log("Raw table session customers:", tableSessionCustomers);
    if (tableSessionCustomers.length > 0) {
      tableSessionCustomers.forEach((customer, index) => {
        console.log(`Customer ${index}:`, customer);
        console.log(`  - Name: ${customer.customerName}`);
        console.log(`  - ID: ${customer.id}`);
        console.log(`  - Table Usage ID: ${customer.tableUsageId}`);
        console.log(`  - Added At: ${customer.addedAt}`);
      });
    }
  }, [tableSessionCustomers]);
  
  // Only display walk-in customers that have a name
  const walkInCustomers = tableSessionCustomers
    .filter(customer => customer.customerName)
    .sort((a, b) => {
      if (!a.addedAt || !b.addedAt) return 0;
      return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
    });
  
  // Mutation to create a new member from walk-in customer
  const createMemberMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/members", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/members"] });
      toast({
        title: "Success",
        description: "Walk-in customer converted to member successfully",
      });
      setConvertDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to convert customer: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Mutation to add a new walk-in customer
  const addWalkInCustomerMutation = useMutation({
    mutationFn: async (customerName: string) => {
      // Find an active table usage to attach this customer to
      const response = await apiRequest("GET", "/api/tables");
      const tables = await response.json();
      
      // Find a table that is in use
      let activeTable = tables.find((table: any) => table.status === "in-use");
      
      // If no active table, create a new table usage for the first available table
      if (!activeTable) {
        console.log("No active tables, creating a new session");
        const availableTable = tables.find((table: any) => table.status === "available");
        
        if (!availableTable) {
          throw new Error("No available tables found. All tables are currently in use or reserved.");
        }
        
        // Create a new table usage
        const startTableResponse = await apiRequest("POST", "/api/table-usage", {
          tableId: availableTable.id,
          primaryUserId: null,
          startTime: new Date().toISOString()
        });
        
        const tableUsage = await startTableResponse.json();
        
        // Refresh tables data to get the newly created usage
        const refreshResponse = await apiRequest("GET", "/api/tables");
        const refreshedTables = await refreshResponse.json();
        
        // Find our now-active table
        activeTable = refreshedTables.find((table: any) => table.id === availableTable.id);
        
        if (!activeTable || !activeTable.currentUsage) {
          throw new Error("Failed to start table session.");
        }
      }
      
      // Add the customer to the active table usage
      return apiRequest("POST", "/api/table-session-customers", {
        tableUsageId: activeTable.currentUsage.id,
        customerName: customerName
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/table-session-customers"] });
      toast({
        title: "Success",
        description: "Walk-in customer added successfully",
      });
      setAddWalkInDialogOpen(false);
      setNewWalkInName('');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add walk-in customer: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Reset form data
  const resetForm = () => {
    setMemberData({
      fullName: '',
      email: '',
      phoneNumber: '',
      membershipTier: 'none',
      isWalkIn: true
    });
    setSelectedCustomer(null);
  };
  
  // Open conversion dialog and pre-fill name
  const handleConvert = (customer: TableSessionCustomer) => {
    setSelectedCustomer(customer);
    setMemberData({
      ...memberData,
      fullName: customer.customerName || '',
      // Don't set username anymore as it's optional
      isWalkIn: true, // Mark this as converted from walk-in
    });
    setConvertDialogOpen(true);
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Set membership dates based on tier
    const membershipStartDate = new Date();
    
    // Set end date to 1 month later if a paid tier is selected
    let membershipEndDate = null;
    if (memberData.membershipTier !== "none") {
      membershipEndDate = new Date();
      membershipEndDate.setMonth(membershipEndDate.getMonth() + 1);
    }
    
    // Set discount rate based on tier
    let discountRate = 0;
    if (memberData.membershipTier === "bronze") {
      discountRate = 0.05;
    } else if (memberData.membershipTier === "silver") {
      discountRate = 0.15;
    } else if (memberData.membershipTier === "gold") {
      discountRate = 0.25;
    }
    
    const data = {
      ...memberData,
      isStaff: false,
      membershipStartDate: memberData.membershipTier !== "none" ? membershipStartDate.toISOString() : null,
      membershipEndDate: membershipEndDate ? membershipEndDate.toISOString() : null,
      discountRate: discountRate,
    };
    
    createMemberMutation.mutate(data);
  };

  return (
    <>
      <Card className="mt-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Users className="mr-2 h-5 w-5" />
              Walk-in Customers
            </CardTitle>
            <CardDescription>
              Customers who have used tables without a membership
            </CardDescription>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            className="flex items-center gap-1"
            onClick={() => setAddWalkInDialogOpen(true)}
          >
            <UserPlus className="h-4 w-4" />
            <span>Add Walk-in</span>
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p>Loading walk-in customers...</p>
          ) : walkInCustomers.length > 0 ? (
            <Table>
              <TableCaption>All walk-in customers who have used tables</TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>First Visit</TableHead>
                  <TableHead>Table</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {walkInCustomers.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell className="font-medium flex items-center">
                      <UserRound className="mr-2 h-4 w-4" />
                      {customer.customerName}
                    </TableCell>
                    <TableCell>
                      {customer.addedAt && new Date(customer.addedAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>Table {customer.tableUsageId}</TableCell>
                    <TableCell>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => handleConvert(customer)}
                      >
                        <UserPlus className="h-4 w-4" />
                        <span className="hidden sm:inline">Convert to Member</span>
                        <span className="sm:hidden">Convert</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-6">
              <p className="text-gray-500 mb-4">No walk-in customers found</p>
              <Button 
                onClick={() => setAddWalkInDialogOpen(true)}
                className="bg-secondary hover:bg-secondary-light"
              >
                <UserPlus className="h-5 w-5 mr-2" />
                Add Your First Walk-in Customer
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Dialog open={convertDialogOpen} onOpenChange={setConvertDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Convert to Member</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="fullName">Full Name</Label>
              <Input 
                id="fullName" 
                value={memberData.fullName} 
                onChange={(e) => setMemberData({...memberData, fullName: e.target.value})}
                required
              />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  value={memberData.email} 
                  onChange={(e) => setMemberData({...memberData, email: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="phoneNumber">Phone Number</Label>
                <Input 
                  id="phoneNumber" 
                  type="tel" 
                  placeholder="(555) 123-4567"
                  value={memberData.phoneNumber} 
                  onChange={(e) => setMemberData({...memberData, phoneNumber: e.target.value})}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="membershipTier">Membership Tier</Label>
              <select 
                id="membershipTier"
                className="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                value={memberData.membershipTier}
                onChange={(e) => setMemberData({...memberData, membershipTier: e.target.value})}
              >
                <option value="none">None</option>
                <option value="bronze">Bronze</option>
                <option value="silver">Silver</option>
                <option value="gold">Gold</option>
              </select>
              <p className="text-xs text-gray-500 mt-1">
                The member will be created without login credentials. They can be set up later.
              </p>
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setConvertDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={createMemberMutation.isPending}
              >
                {createMemberMutation.isPending ? "Converting..." : "Convert to Member"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      <Dialog open={addWalkInDialogOpen} onOpenChange={setAddWalkInDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Walk-in Customer</DialogTitle>
          </DialogHeader>
          
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              if (newWalkInName.trim()) {
                addWalkInCustomerMutation.mutate(newWalkInName.trim());
              }
            }} 
            className="space-y-4"
          >
            <div>
              <Label htmlFor="customerName">Customer Name</Label>
              <Input 
                id="customerName" 
                placeholder="Enter walk-in customer name"
                value={newWalkInName} 
                onChange={(e) => setNewWalkInName(e.target.value)}
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                This customer will be added to an active table session
              </p>
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setAddWalkInDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={addWalkInCustomerMutation.isPending || !newWalkInName.trim()}
              >
                {addWalkInCustomerMutation.isPending ? "Adding..." : "Add Customer"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}