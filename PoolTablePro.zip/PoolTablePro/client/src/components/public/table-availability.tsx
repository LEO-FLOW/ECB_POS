import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, isSameDay, addDays, parseISO } from "date-fns";
import { Calendar, Clock, CheckCircle, XCircle, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { DatePicker } from "@/components/ui/calendar";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, Reservation } from "@shared/schema";
import { ReservationModal } from "./reservation-modal";

// Common time blocks that are convenient for customers
const POPULAR_TIME_BLOCKS = [
  { label: "Morning", start: 9, end: 12 },
  { label: "Afternoon", start: 12, end: 17 },
  { label: "Evening", start: 17, end: 22 },
  { label: "All Hours", start: 9, end: 24 },
];

export function TableAvailability() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedTimeBlock, setSelectedTimeBlock] = useState(POPULAR_TIME_BLOCKS[1]); // Default to afternoon
  const [showReservationModal, setShowReservationModal] = useState(false);
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string | null>(null);

  // Generate time slots based on selected time block
  const timeSlots: string[] = [];
  for (let hour = selectedTimeBlock.start; hour < selectedTimeBlock.end; hour++) {
    // Add both top of the hour and half past
    timeSlots.push(format(new Date().setHours(hour, 0, 0, 0), "h:mm a"));
    if (hour < selectedTimeBlock.end - 1) {
      timeSlots.push(format(new Date().setHours(hour, 30, 0, 0), "h:mm a"));
    }
  }

  // Fetch table data
  const { data: tables = [], isLoading: tablesLoading } = useQuery<Table[]>({
    queryKey: ["/api/tables"],
  });

  // Fetch reservations for the selected date
  const { data: reservations = [], isLoading: reservationsLoading } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
    select: (data: Reservation[]) => {
      return data.filter((reservation) => {
        const reservationDate = new Date(reservation.startTime);
        return isSameDay(reservationDate, selectedDate);
      });
    }
  });

  // Check if a time slot is available for a table
  const isTimeSlotAvailable = (table: Table, timeSlot: string) => {
    if (!reservations.length) return true;

    const timeSlotDate = new Date(selectedDate);
    const [hourStr, minuteStr] = timeSlot.split(":");
    const [hour, period] = hourStr.split(" ");
    let hourValue = parseInt(hour);
    let minuteValue = minuteStr ? parseInt(minuteStr) : 0;
    
    // Convert from 12-hour to 24-hour format
    if (period && period.toLowerCase() === "pm" && hourValue < 12) {
      hourValue += 12;
    } else if (period && period.toLowerCase() === "am" && hourValue === 12) {
      hourValue = 0;
    }
    
    timeSlotDate.setHours(hourValue, minuteValue, 0, 0);
    
    // Check if the table has a reservation that overlaps with this time slot
    return !reservations.some((reservation: Reservation) => {
      if (reservation.tableId !== table.id) return false;
      
      const startTime = new Date(reservation.startTime);
      const endTime = new Date(reservation.endTime);
      
      // Check if the time slot falls within the reservation time
      return timeSlotDate >= startTime && timeSlotDate < endTime;
    });
  };

  // Get availability summary for a table
  const getTableAvailability = (table: Table) => {
    const availableSlots = timeSlots.filter(slot => isTimeSlotAvailable(table, slot));
    return {
      table,
      availableSlots,
      availabilityPercentage: timeSlots.length > 0 ? (availableSlots.length / timeSlots.length) * 100 : 0
    };
  };

  // Sort tables by availability
  const sortedTables = [...tables].sort((a, b) => {
    const aAvailability = getTableAvailability(a);
    const bAvailability = getTableAvailability(b);
    return bAvailability.availabilityPercentage - aAvailability.availabilityPercentage;
  });

  const handleReservation = (table: Table, timeSlot: string) => {
    setSelectedTable(table);
    setSelectedTimeSlot(timeSlot);
    setShowReservationModal(true);
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8">
      {/* Date and Time Block Selection */}
      <div className="mb-8 bg-white rounded-lg shadow-sm border p-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Find Available Tables</h2>
            <p className="text-gray-500 mt-1">Select a date and time to see which tables are available</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full sm:w-auto flex items-center justify-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {format(selectedDate, "EEEE, MMMM d")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <DatePicker
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  disabled={(date) => date < new Date() || date > addDays(new Date(), 14)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>
        
        {/* Time block selection */}
        <div className="flex flex-wrap gap-2 justify-center md:justify-start">
          {POPULAR_TIME_BLOCKS.map((block) => (
            <Button
              key={block.label}
              variant={selectedTimeBlock === block ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedTimeBlock(block)}
              className="flex items-center gap-1.5"
            >
              <Clock className="h-3.5 w-3.5" />
              {block.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Table Availability Display */}
      {tablesLoading || reservationsLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-7 w-48 mb-3" />
                <Skeleton className="h-4 w-32 mb-6" />
                <div className="grid grid-cols-4 gap-2">
                  {[...Array(8)].map((_, j) => (
                    <Skeleton key={j} className="h-12 w-full" />
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {sortedTables.map((table: Table) => {
            const { availableSlots, availabilityPercentage } = getTableAvailability(table);
            const isHighlyAvailable = availabilityPercentage > 75;
            const isLimitedAvailability = availabilityPercentage > 25 && availabilityPercentage <= 75;
            const isLowAvailability = availabilityPercentage <= 25 && availabilityPercentage > 0;
            
            return (
              <Card key={table.id} className={`overflow-hidden border-l-4 ${
                isHighlyAvailable ? 'border-l-green-500' : 
                isLimitedAvailability ? 'border-l-amber-500' : 
                isLowAvailability ? 'border-l-red-500' : 'border-l-gray-300'
              }`}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{table.name}</CardTitle>
                      <CardDescription>{table.type} - ${table.hourlyRate}/hour</CardDescription>
                    </div>
                    
                    <div className="flex items-center gap-1 text-sm px-2.5 py-1 rounded-full bg-gray-100">
                      {isHighlyAvailable && <CheckCircle className="h-4 w-4 text-green-500" />} 
                      {isLimitedAvailability && <Clock className="h-4 w-4 text-amber-500" />}
                      {isLowAvailability && <XCircle className="h-4 w-4 text-red-500" />}
                      {availabilityPercentage === 0 && <XCircle className="h-4 w-4 text-gray-400" />}
                      <span className={`font-medium ${
                        isHighlyAvailable ? 'text-green-700' : 
                        isLimitedAvailability ? 'text-amber-700' : 
                        isLowAvailability ? 'text-red-700' : 'text-gray-500'
                      }`}>
                        {availableSlots.length === 0 ? 'Not Available' :
                         isHighlyAvailable ? 'Highly Available' :
                         isLimitedAvailability ? 'Limited Availability' : 'Low Availability'}
                      </span>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
                    {timeSlots.map((timeSlot: string) => {
                      const isAvailable = isTimeSlotAvailable(table, timeSlot);
                      return (
                        <Button
                          key={`${table.id}-${timeSlot}`}
                          variant={isAvailable ? "outline" : "ghost"}
                          size="sm"
                          className={`text-xs h-12 ${
                            isAvailable 
                              ? "hover:bg-green-50 hover:text-green-600 border-green-200 bg-green-50/30" 
                              : "opacity-50 cursor-not-allowed bg-gray-50 text-gray-400"
                          }`}
                          disabled={!isAvailable}
                          onClick={() => isAvailable && handleReservation(table, timeSlot)}
                        >
                          {timeSlot}
                        </Button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Legend */}
      <div className="mt-8 flex flex-wrap gap-4 bg-white p-4 rounded-lg border shadow-sm">
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-green-500"></div>
          <span className="text-sm">Highly Available</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-amber-500"></div>
          <span className="text-sm">Limited Availability</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-red-500"></div>
          <span className="text-sm">Low Availability</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-gray-300"></div>
          <span className="text-sm">Not Available</span>
        </div>
      </div>

      {/* Quick Guide */}
      <div className="mt-6 bg-gray-50 p-4 rounded-lg">
        <h3 className="font-medium text-lg mb-2">Quick Guide</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <p className="mb-2 flex items-center gap-2">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-white">1</span>
              <span>Select a date and time block</span>
            </p>
            <p className="mb-2 flex items-center gap-2">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-white">2</span>
              <span>Look for tables with green availability indicators</span>
            </p>
          </div>
          <div>
            <p className="mb-2 flex items-center gap-2">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-white">3</span>
              <span>Click on an available time slot to make a reservation</span>
            </p>
            <p className="flex items-center gap-2">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-white">4</span>
              <span>Login or register to confirm your booking</span>
            </p>
          </div>
        </div>
      </div>

      {/* Member benefit alert */}
      <div className="mt-4 bg-accent bg-opacity-10 p-4 rounded-lg border border-accent">
        <h3 className="font-medium text-accent mb-1">Member Benefit</h3>
        <p className="text-sm">Members can make reservations up to 14 days in advance and receive discounted rates!</p>
      </div>

      {/* Reservation modal */}
      {showReservationModal && selectedTable && selectedTimeSlot && (
        <ReservationModal
          open={showReservationModal}
          onOpenChange={setShowReservationModal}
          table={selectedTable}
          timeSlot={selectedTimeSlot}
          date={selectedDate}
          redirectToLogin={true}
        />
      )}
    </div>
  );
}