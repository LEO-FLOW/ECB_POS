import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format, addHours } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Table } from "@shared/schema";

interface ReservationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  table: Table | null;
  timeSlot: string | null;
  date: Date;
  redirectToLogin?: boolean;
}

export function ReservationModal({
  open,
  onOpenChange,
  table,
  timeSlot,
  date,
  redirectToLogin = false,
}: ReservationModalProps) {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [duration, setDuration] = useState(1);

  if (!table || !timeSlot) return null;

  const startTime = new Date(date);
  const timeParts = timeSlot.match(/(\d+):(\d+) (AM|PM)/i);
  
  if (timeParts) {
    let hours = parseInt(timeParts[1]);
    const minutes = parseInt(timeParts[2]);
    const period = timeParts[3].toUpperCase();
    
    // Convert to 24-hour format
    if (period === "PM" && hours < 12) {
      hours += 12;
    } else if (period === "AM" && hours === 12) {
      hours = 0;
    }
    
    startTime.setHours(hours, minutes, 0, 0);
  }
  
  const endTime = addHours(startTime, duration);
  
  const reservationMutation = useMutation({
    mutationFn: async (reservationData: any) => {
      return apiRequest("POST", "/api/reservations", reservationData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      toast({
        title: "Reservation Confirmed",
        description: "Your table has been reserved successfully!",
      });
      onOpenChange(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Reservation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setName("");
    setEmail("");
    setPhone("");
    setNotes("");
    setDuration(1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (redirectToLogin) {
      // Save reservation data to localStorage and redirect to login
      const reservationData = {
        tableId: table.id,
        tableName: table.name,
        date: date.toISOString(),
        timeSlot,
        duration,
        name,
        email,
        phone,
        notes,
      };
      
      localStorage.setItem("pendingReservation", JSON.stringify(reservationData));
      window.location.href = "/auth";
      return;
    }
    
    const reservationData = {
      tableId: table.id,
      customerName: name,
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      status: "confirmed",
      contactEmail: email,
      contactPhone: phone,
      notes: notes,
    };
    
    reservationMutation.mutate(reservationData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Reserve {table.name}</DialogTitle>
          <DialogDescription>
            {format(startTime, "EEEE, MMMM d, yyyy")} at {format(startTime, "h:mm a")}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Your Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="John Doe"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="john@example.com"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(555) 123-4567"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="duration">Duration (hours)</Label>
            <div className="flex items-center">
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="rounded-r-none"
                onClick={() => setDuration(Math.max(1, duration - 1))}
              >
                -
              </Button>
              <div className="px-4 py-2 border-y text-center w-16">
                {duration}
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="rounded-l-none"
                onClick={() => setDuration(Math.min(4, duration + 1))}
              >
                +
              </Button>
            </div>
            <p className="text-sm text-gray-500">
              {format(endTime, "h:mm a")} (End time)
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notes">Special Requests</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Any special requests or notes"
              className="resize-none"
            />
          </div>
          
          <div className="pt-4 border-t">
            <div className="flex justify-between mb-4">
              <span>Table Rate:</span>
              <span>${table.hourlyRate}/hour</span>
            </div>
            <div className="flex justify-between font-medium">
              <span>Estimated Total:</span>
              <span>${(Number(table.hourlyRate) * duration).toFixed(2)}</span>
            </div>
            
            <p className="text-xs text-gray-500 mt-2">
              * Final charges will be based on actual usage. Payment is due at checkout.
            </p>
          </div>
          
          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={reservationMutation.isPending}
            >
              {reservationMutation.isPending ? "Booking..." : "Book Now"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}