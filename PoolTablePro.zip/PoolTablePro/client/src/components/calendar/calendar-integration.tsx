import { useState, useEffect, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Calendar } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { CalendarPlus, Users, CalendarCheck, ExternalLink } from "lucide-react";

interface CalendarIntegrationProps {
  onConnect?: () => void;
}

export function CalendarIntegration({ onConnect }: CalendarIntegrationProps) {
  const [selectedProvider, setSelectedProvider] = useState<"calendly" | "google">("calendly");
  const [isConnected, setIsConnected] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [bookingType, setBookingType] = useState<string>("coaching");
  const [showCalendly, setShowCalendly] = useState(false);
  const calendlyContainerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const handleConnect = () => {
    setIsConnected(true);
    if (onConnect) onConnect();
    
    toast({
      title: "Connected to calendar",
      description: `Successfully connected to ${selectedProvider === "calendly" ? "Calendly" : "Google Calendar"}`,
    });
  };

  const handleBookingTypeChange = (value: string) => {
    setBookingType(value);
  };

  const handleCalendlyEmbed = () => {
    setShowCalendly(true);
  };

  const availableTimes = [
    "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", 
    "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"
  ];

  useEffect(() => {
    if (showCalendly && calendlyContainerRef.current) {
      // In a real implementation, we would load the Calendly embed script here
      // and initialize it with the appropriate parameters
      const mockCalendlyUI = document.createElement('div');
      mockCalendlyUI.innerHTML = `
        <div class="p-4 bg-gray-100 rounded-lg text-center">
          <h3 class="font-medium text-lg mb-2">Calendly Integration</h3>
          <p class="text-gray-500 mb-4">In a production environment, this would display the Calendly booking widget</p>
          <p class="text-sm">To integrate with Calendly:</p>
          <p class="text-sm">1. Create a Calendly account</p>
          <p class="text-sm">2. Set up your availability</p>
          <p class="text-sm">3. Copy your Calendly embed code</p>
          <p class="text-sm">4. Replace this placeholder with your embed code</p>
          <div class="mt-3">
            <a href="https://calendly.com/" target="_blank" rel="noopener noreferrer" 
               class="text-blue-600 hover:underline inline-flex items-center gap-1">
              Visit Calendly <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>
      `;
      calendlyContainerRef.current.appendChild(mockCalendlyUI);
    }
  }, [showCalendly]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarPlus className="h-5 w-5" />
            Calendar Integration
          </CardTitle>
          <CardDescription>
            Connect to your preferred calendar service to manage coaching sessions and 1:1 appointments
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue={selectedProvider} onValueChange={(value) => setSelectedProvider(value as "calendly" | "google")}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="calendly">Calendly</TabsTrigger>
              <TabsTrigger value="google">Google Calendar</TabsTrigger>
            </TabsList>
            <TabsContent value="calendly" className="space-y-4 mt-4">
              <p className="text-sm text-gray-500">
                Calendly allows your customers to book appointments directly based on your availability.
              </p>
              {isConnected ? (
                <div className="space-y-4">
                  <div className="flex items-center p-2 bg-green-50 text-green-700 rounded-md">
                    <CalendarCheck className="h-5 w-5 mr-2" />
                    <span>Connected to Calendly</span>
                  </div>
                  <Button onClick={handleCalendlyEmbed} className="w-full bg-gray-700 hover:bg-gray-800 text-white">
                    Embed Booking Widget
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="calendly-key">Calendly API Key</Label>
                    <Input id="calendly-key" type="password" placeholder="Enter your Calendly API key" />
                    <p className="text-xs text-gray-500">
                      You can find this in your Calendly account settings.
                    </p>
                  </div>
                  <Button onClick={handleConnect} className="w-full bg-gray-700 hover:bg-gray-800 text-white">
                    Connect to Calendly
                  </Button>
                </div>
              )}
            </TabsContent>
            <TabsContent value="google" className="space-y-4 mt-4">
              <p className="text-sm text-gray-500">
                Connect to your Google Calendar to sync appointments and availability.
              </p>
              {isConnected ? (
                <div className="flex items-center p-2 bg-green-50 text-green-700 rounded-md">
                  <CalendarCheck className="h-5 w-5 mr-2" />
                  <span>Connected to Google Calendar</span>
                </div>
              ) : (
                <Button onClick={handleConnect} className="w-full bg-gray-700 hover:bg-gray-800 text-white">
                  Connect Google Calendar
                </Button>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {showCalendly && (
        <Card>
          <CardHeader>
            <CardTitle>Calendly Booking Widget</CardTitle>
            <CardDescription>Your customers can use this to book appointments</CardDescription>
          </CardHeader>
          <CardContent>
            <div ref={calendlyContainerRef} className="min-h-[400px]">
              {/* Calendly widget will be inserted here */}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Manage 1:1 Services
          </CardTitle>
          <CardDescription>
            Set up and manage your coaching and 1:1 services
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="booking-type">Service Type</Label>
              <Select defaultValue={bookingType} onValueChange={handleBookingTypeChange}>
                <SelectTrigger id="booking-type">
                  <SelectValue placeholder="Select service type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="coaching">Coaching Session</SelectItem>
                  <SelectItem value="instruction">Billiards Instruction</SelectItem>
                  <SelectItem value="tournament">Tournament Prep</SelectItem>
                  <SelectItem value="private">Private Party</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Pick a Date</Label>
                <div className="mt-2">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    className="rounded-md border"
                    disabled={(date) => date < new Date()}
                  />
                </div>
              </div>
              <div>
                <Label>Available Times</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {availableTimes.map((time) => (
                    <Button
                      key={time}
                      variant={selectedTime === time ? "default" : "outline"}
                      className={selectedTime === time ? "bg-gray-700 hover:bg-gray-800" : ""}
                      onClick={() => setSelectedTime(time)}
                    >
                      {time}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full bg-gray-700 hover:bg-gray-800 text-white">
            Add to Schedule
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}