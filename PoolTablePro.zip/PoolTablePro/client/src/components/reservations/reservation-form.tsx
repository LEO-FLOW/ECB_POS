import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertReservationSchema } from "@shared/schema";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { DatePicker } from "@/components/ui/calendar";
import { format, addHours, setHours, setMinutes } from "date-fns";
import { Calendar, Clock } from "lucide-react";

interface ReservationFormProps {
  onSuccess?: () => void;
}

const formSchema = insertReservationSchema.extend({
  date: z.date(),
  startTime: z.date(),
  endTime: z.date(),
  customerId: z.union([z.string(), z.number()]).optional(),
  tableId: z.union([z.string(), z.number()]), // Accept both string and number
});

type FormData = z.infer<typeof formSchema>;

export function ReservationForm({ onSuccess }: ReservationFormProps) {
  const [date, setDate] = useState<Date>(new Date());
  const [startTime, setStartTime] = useState<Date>(
    setMinutes(setHours(new Date(), new Date().getHours() + 1), 0)
  );
  const [endTime, setEndTime] = useState<Date>(
    addHours(setMinutes(setHours(new Date(), new Date().getHours() + 1), 0), 2)
  );
  
  const { toast } = useToast();
  
  // Define types for tables and members
  interface Table {
    id: number;
    name: string;
    type: string;
    status: string;
    hourlyRate: string;
  }
  
  interface Member {
    id: number;
    username: string;
    fullName: string;
    email?: string;
  }
  
  const { data: tables = [], isLoading: tablesLoading } = useQuery<Table[]>({
    queryKey: ["/api/tables"],
  });
  
  const { data: members = [], isLoading: membersLoading } = useQuery<Member[]>({
    queryKey: ["/api/members"],
  });
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      tableId: undefined,
      customerName: "",
      customerId: undefined,
      date: date,
      startTime: startTime,
      endTime: endTime,
      status: "confirmed",
    },
  });
  
  const createReservationMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/reservations", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reservations/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      toast({
        title: "Reservation created",
        description: "The reservation has been created successfully",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create reservation: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: FormData) => {
    // Format data for submission
    const formattedData = {
      tableId: typeof data.tableId === 'string' ? parseInt(data.tableId) : data.tableId,
      userId: data.customerId ? (typeof data.customerId === 'string' ? parseInt(data.customerId) : data.customerId) : undefined,
      customerName: data.customerName,
      status: "pending",
      duration: 60, // Default 1 hour in minutes
      date: format(data.date, "yyyy-MM-dd"),
      startTime: format(data.startTime, "HH:mm"),
      endTime: format(data.endTime, "HH:mm"),
    };
    
    console.log("Submitting reservation data:", formattedData);
    
    createReservationMutation.mutate(formattedData);
  };
  
  // Define TimeOption type for better type safety
  interface TimeOption {
    value: string;
    label: string;
  }
  
  // Generate time options with proper typing
  const timeOptions: TimeOption[] = [];
  for (let hour = 9; hour < 24; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const time = new Date();
      time.setHours(hour, minute, 0, 0);
      timeOptions.push({
        value: format(time, "HH:mm"),
        label: format(time, "h:mm a"),
      });
    }
  }
  
  // Handle customer selection
  const onCustomerSelect = (value: string) => {
    if (value === "guest") {
      form.setValue("customerId", undefined);
      form.setValue("customerName", "");
    } else {
      const selectedMember = members.find((m: Member) => m.id.toString() === value);
      if (selectedMember) {
        // Convert to number since form expects a number for customerId
        form.setValue("customerId", parseInt(value));
        form.setValue("customerName", selectedMember.fullName);
      }
    }
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="tableId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Table</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a table" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {tablesLoading ? (
                    <SelectItem value="loading" disabled>Loading tables...</SelectItem>
                  ) : (
                    tables.map((table: Table) => (
                      <SelectItem key={table.id} value={table.id.toString()}>
                        {table.name} ({table.type})
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="border-t pt-4">
          <FormField
            control={form.control}
            name="customerId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Customer</FormLabel>
                <Select 
                  onValueChange={(value) => {
                    field.onChange(value);
                    onCustomerSelect(value);
                  }} 
                  defaultValue={field.value?.toString()}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a customer" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="guest">Guest (non-member)</SelectItem>
                    {membersLoading ? (
                      <SelectItem value="loading" disabled>Loading members...</SelectItem>
                    ) : (
                      members.map((member: Member) => (
                        <SelectItem key={member.id} value={member.id.toString()}>
                          {member.fullName}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {!form.watch("customerId") && (
            <FormField
              control={form.control}
              name="customerName"
              render={({ field }) => (
                <FormItem className="mt-4">
                  <FormLabel>Guest Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter guest name" 
                      value={field.value || ""} // Ensure value is always a string
                      onChange={field.onChange}
                      onBlur={field.onBlur}
                      name={field.name}
                      ref={field.ref}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
        </div>
        
        <div className="border-t pt-4">
          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className="pl-3 text-left font-normal flex items-center justify-between"
                      >
                        {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                        <Calendar className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <DatePicker
                      mode="single"
                      selected={field.value}
                      onSelect={(date) => {
                        if (date) {
                          setDate(date);
                          field.onChange(date);
                        }
                      }}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            <FormField
              control={form.control}
              name="startTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Start Time</FormLabel>
                  <Select
                    onValueChange={(value) => {
                      const [hours, minutes] = value.split(':').map(Number);
                      const newStartTime = new Date(date);
                      newStartTime.setHours(hours, minutes);
                      setStartTime(newStartTime);
                      field.onChange(newStartTime);
                      
                      // Update end time if it's less than start time
                      const currentEndTime = form.getValues("endTime");
                      if (currentEndTime < newStartTime) {
                        const newEndTime = addHours(newStartTime, 1);
                        setEndTime(newEndTime);
                        form.setValue("endTime", newEndTime);
                      }
                    }}
                    defaultValue={format(field.value, "HH:mm")}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select start time" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {timeOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="endTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>End Time</FormLabel>
                  <Select
                    onValueChange={(value) => {
                      const [hours, minutes] = value.split(':').map(Number);
                      const newEndTime = new Date(date);
                      newEndTime.setHours(hours, minutes);
                      setEndTime(newEndTime);
                      field.onChange(newEndTime);
                    }}
                    defaultValue={format(field.value, "HH:mm")}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select end time" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {timeOptions
                        .filter((option) => {
                          const [hours, minutes] = option.value.split(':').map(Number);
                          const optionTime = new Date(date);
                          optionTime.setHours(hours, minutes);
                          return optionTime > startTime;
                        })
                        .map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
        
        <Button 
          type="submit" 
          className="w-full bg-secondary hover:bg-secondary-light"
          disabled={createReservationMutation.isPending}
        >
          {createReservationMutation.isPending ? "Creating Reservation..." : "Create Reservation"}
        </Button>
      </form>
    </Form>
  );
}
