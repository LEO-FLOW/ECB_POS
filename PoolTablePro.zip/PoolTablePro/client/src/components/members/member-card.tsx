import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { User } from "@shared/schema";
import { MoreVertical, Mail, Phone, Calendar, CreditCard } from "lucide-react";
import { useState } from "react";
import { format, isAfter } from "date-fns";

interface MemberCardProps {
  member: User;
}

export function MemberCard({ member }: MemberCardProps) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };
  
  const getMembershipStatus = () => {
    if (member.membershipTier === "none" || !member.membershipTier) {
      return { label: "No Membership", color: "bg-gray-100 text-gray-800" };
    }
    
    if (!member.membershipEndDate) {
      return { label: "Inactive", color: "bg-gray-100 text-gray-800" };
    }
    
    const endDate = new Date(member.membershipEndDate);
    const isActive = isAfter(endDate, new Date());
    
    if (isActive) {
      return { label: "Active", color: "bg-green-100 text-green-800" };
    } else {
      return { label: "Expired", color: "bg-red-100 text-red-800" };
    }
  };
  
  const formatMembershipTier = (tier: string) => {
    if (!tier || tier === "none") return "None";
    return tier.charAt(0).toUpperCase() + tier.slice(1);
  };
  
  const getMembershipDates = () => {
    if (!member.membershipStartDate || !member.membershipEndDate) {
      return "No membership";
    }
    
    return `${format(new Date(member.membershipStartDate), "MMM d, yyyy")} - ${format(new Date(member.membershipEndDate), "MMM d, yyyy")}`;
  };
  
  const membershipStatus = getMembershipStatus();
  
  return (
    <>
      <Card className="hover:shadow-md transition-shadow duration-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className={`h-12 w-12 rounded-full bg-${member.membershipTier === "gold" ? "accent" : member.membershipTier === "silver" ? "primary-light" : "primary"} flex items-center justify-center text-white font-semibold`}>
                {getInitials(member.fullName)}
              </div>
              <div>
                <h3 className="text-md font-medium text-gray-900">{member.fullName}</h3>
                <p className="text-sm text-gray-500">@{member.username}</p>
              </div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setDetailsOpen(true)}>
                  View Details
                </DropdownMenuItem>
                <DropdownMenuItem>Edit Member</DropdownMenuItem>
                <DropdownMenuItem>Renew Membership</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-red-600">
                  Deactivate
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          <div className="mt-4 space-y-2">
            {member.email && (
              <div className="flex items-center text-sm text-gray-500">
                <Mail className="h-4 w-4 mr-2" />
                {member.email}
              </div>
            )}
            
            <div className="flex items-center justify-between">
              <div className="flex items-center text-sm text-gray-500">
                <Calendar className="h-4 w-4 mr-2" />
                {member.membershipTier !== "none" && member.membershipTier
                  ? `${formatMembershipTier(member.membershipTier)} Tier`
                  : "No Membership"}
              </div>
              <Badge className={membershipStatus.color}>
                {membershipStatus.label}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Member Details</DialogTitle>
          </DialogHeader>
          <div className="flex items-center space-x-4 mb-4">
            <div className={`h-16 w-16 rounded-full bg-${member.membershipTier === "gold" ? "accent" : member.membershipTier === "silver" ? "primary-light" : "primary"} flex items-center justify-center text-white font-semibold text-xl`}>
              {getInitials(member.fullName)}
            </div>
            <div>
              <h3 className="text-xl font-medium text-gray-900">{member.fullName}</h3>
              <p className="text-sm text-gray-500">@{member.username}</p>
              <Badge className={membershipStatus.color}>
                {membershipStatus.label}
              </Badge>
            </div>
          </div>
          
          <div className="space-y-4">
            {member.email && (
              <div className="flex items-center text-sm">
                <Mail className="h-5 w-5 mr-3 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Email</p>
                  <p className="text-sm text-gray-500">{member.email}</p>
                </div>
              </div>
            )}
            
            <div className="flex items-center text-sm">
              <Calendar className="h-5 w-5 mr-3 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-700">Membership</p>
                <p className="text-sm text-gray-500">
                  {formatMembershipTier(member.membershipTier || "none")} Tier
                </p>
                <p className="text-xs text-gray-400">{getMembershipDates()}</p>
              </div>
            </div>
            
            {member.discountRate && parseFloat(member.discountRate) > 0 && (
              <div className="flex items-center text-sm">
                <CreditCard className="h-5 w-5 mr-3 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Discount Rate</p>
                  <p className="text-sm text-gray-500">{parseFloat(member.discountRate) * 100}%</p>
                </div>
              </div>
            )}
            
            <div className="flex items-center text-sm">
              <Calendar className="h-5 w-5 mr-3 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-700">Member Since</p>
                <p className="text-sm text-gray-500">
                  {member.createdAt ? format(new Date(member.createdAt), "MMMM d, yyyy") : "Unknown"}
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex space-x-3 mt-4">
            <Button className="flex-1 bg-secondary hover:bg-secondary-light">
              Edit Member
            </Button>
            <Button className="flex-1" variant="outline">
              Renew Membership
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
