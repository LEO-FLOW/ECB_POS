import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { insertUserSchema, User } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Form, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormControl, 
  FormMessage 
} from "@/components/ui/form";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface MemberFormProps {
  onSuccess?: (user: User) => void;
  onCancel?: () => void;
  includeMembershipControls?: boolean;
  includeStaffControls?: boolean;
  mode?: 'member' | 'customer';
  defaultValues?: Partial<any>;
  autoFocus?: boolean;
}

export function MemberForm({
  onSuccess,
  onCancel,
  includeMembershipControls = true,
  includeStaffControls = false,
  mode = 'member',
  defaultValues,
  autoFocus = false
}: MemberFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch membership tiers
  const { data: membershipTiers } = useQuery({
    queryKey: ["/api/members/tiers"],
  });
  
  // Set up the form
  const form = useForm({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phoneNumber: "",
      membershipTier: "none",
      isStaff: false,
      isWalkIn: mode === 'customer',
      ...defaultValues
    },
  });
  
  // Set up mutation for creating a new member/customer
  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      setIsSubmitting(true);
      const response = await apiRequest("POST", "/api/members", data);
      const newUser = await response.json();
      return newUser;
    },
    onSuccess: (data) => {
      // Invalidate all related queries
      queryClient.invalidateQueries({ queryKey: ["/api/members"] });
      queryClient.invalidateQueries({ queryKey: ["/api/table-session-customers"] });
      
      // Show success message
      toast({
        title: mode === 'member' ? "Member added" : "Customer added",
        description: `New ${mode} has been added successfully`,
      });
      
      // Reset form
      form.reset();
      
      // Call callback if provided
      if (onSuccess) {
        onSuccess(data);
      }
      
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add ${mode}: ${error.message}`,
        variant: "destructive",
      });
      setIsSubmitting(false);
    },
  });
  
  // Handle form submission
  const onSubmit = (formData: any) => {
    // Set membership dates based on tier
    const membershipStartDate = new Date();
    
    // Set end date to 1 month later if a paid tier is selected
    let membershipEndDate = null;
    if (formData.membershipTier !== "none") {
      membershipEndDate = new Date();
      membershipEndDate.setMonth(membershipEndDate.getMonth() + 1);
    }
    
    // Set discount rate based on tier
    let discountRate = 0;
    if (formData.membershipTier === "bronze") {
      discountRate = 0.05;
    } else if (formData.membershipTier === "silver") {
      discountRate = 0.15;
    } else if (formData.membershipTier === "gold") {
      discountRate = 0.25;
    }
    
    const memberData = {
      ...formData,
      membershipStartDate: formData.membershipTier !== "none" ? membershipStartDate : null,
      membershipEndDate: membershipEndDate,
      discountRate: discountRate,
    };
    
    createMutation.mutate(memberData);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="fullName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{mode === 'member' ? "Full Name" : "Name"}</FormLabel>
              <FormControl>
                <Input 
                  placeholder="John Doe" 
                  {...field} 
                  autoFocus={autoFocus}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="john@example.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="phoneNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Phone Number</FormLabel>
                <FormControl>
                  <Input type="tel" placeholder="(555) 123-4567" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        {includeMembershipControls && (
          <FormField
            control={form.control}
            name="membershipTier"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Membership Tier</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select membership tier" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="bronze">Bronze</SelectItem>
                    <SelectItem value="silver">Silver</SelectItem>
                    <SelectItem value="gold">Gold</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        
        {includeStaffControls && (
          <FormField
            control={form.control}
            name="isStaff"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                <FormControl>
                  <input
                    type="checkbox"
                    checked={field.value}
                    onChange={field.onChange}
                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>Staff Member</FormLabel>
                  <p className="text-sm text-gray-500">
                    Staff members can access the management dashboard
                  </p>
                </div>
              </FormItem>
            )}
          />
        )}
        
        <div className="flex space-x-2 justify-end pt-2">
          {onCancel && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel}
            >
              Cancel
            </Button>
          )}
          
          <Button 
            type="submit" 
            className="bg-secondary hover:bg-secondary-light"
            disabled={isSubmitting}
          >
            {isSubmitting 
              ? `Adding ${mode === 'member' ? 'Member' : 'Customer'}...` 
              : `Add ${mode === 'member' ? 'Member' : 'Customer'}`
            }
          </Button>
        </div>
      </form>
    </Form>
  );
}