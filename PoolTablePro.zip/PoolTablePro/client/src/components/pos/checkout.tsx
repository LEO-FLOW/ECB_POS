import { useState, useEffect } from 'react';
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle, AlertTriangle } from 'lucide-react';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface CheckoutFormProps {
  clientSecret: string;
  orderDetails: {
    tableUsage?: {
      id: number;
      tableName: string;
      startTime: string;
      duration: string;
      amount: string;
    };
    orderItems?: {
      name: string;
      quantity: number;
      price: string;
    }[];
    subtotal: string;
    total: string;
  };
  onSuccess: () => void;
  onCancel: () => void;
  mockMode?: boolean;
  mockPaymentIntentId?: string | null;
}

const CheckoutForm = ({ clientSecret, orderDetails, onSuccess, onCancel, mockMode, mockPaymentIntentId }: CheckoutFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);
    setPaymentStatus('processing');

    // Handle mock payment in development mode
    if (mockMode && mockPaymentIntentId) {
      console.log("Processing mock payment with ID:", mockPaymentIntentId);
      
      try {
        // Process the mock payment on the server
        const response = await apiRequest("POST", "/api/pos/payment-success", {
          paymentIntentId: mockPaymentIntentId,
          mockMode: true,
          amount: Number(orderDetails.total),
          description: `Table usage and items payment`,
          tableUsageId: orderDetails.tableUsage?.id,
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to process mock payment");
        }
        
        // Mock payment successful
        setPaymentStatus('success');
        toast({
          title: "Payment Successful (Development Mode)",
          description: "Mock payment processed successfully!",
        });
        
        // Give a moment to show the success message
        setTimeout(() => {
          onSuccess();
        }, 1500);
      } catch (err: any) {
        setErrorMessage(err.message || "An unexpected error occurred");
        setPaymentStatus('error');
        toast({
          title: "Mock Payment Failed",
          description: err.message,
          variant: "destructive",
        });
      } finally {
        setIsProcessing(false);
      }
      
      return;
    }

    // Real Stripe payment processing
    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
      redirect: 'if_required',
    });

    if (error) {
      setErrorMessage(error.message || "An unexpected error occurred");
      setPaymentStatus('error');
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else if (paymentIntent && paymentIntent.status === 'succeeded') {
      setPaymentStatus('success');
      toast({
        title: "Payment Successful",
        description: "Thank you for your payment!",
      });
      
      // Give a moment to show the success message
      setTimeout(() => {
        onSuccess();
      }, 1500);
    }
    
    setIsProcessing(false);
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-6">
        <h3 className="text-lg font-bold mb-2">Order Details</h3>
        
        {orderDetails.tableUsage && (
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-600 mb-2">Table Usage</h4>
            <div className="bg-gray-50 p-3 rounded border space-y-1">
              <div className="flex justify-between">
                <span>{orderDetails.tableUsage.tableName}</span>
                <span className="font-medium">${orderDetails.tableUsage.amount}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-500">
                <span>Duration: {orderDetails.tableUsage.duration}</span>
              </div>
            </div>
          </div>
        )}
        
        {orderDetails.orderItems && orderDetails.orderItems.length > 0 && (
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-600 mb-2">Items</h4>
            <div className="bg-gray-50 p-3 rounded border space-y-2">
              {orderDetails.orderItems.map((item, index) => (
                <div key={index} className="flex justify-between">
                  <span>
                    {item.quantity}x {item.name}
                  </span>
                  <span className="font-medium">${(Number(item.price) * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="mt-4 pt-2 border-t">
          <div className="flex justify-between mb-1">
            <span className="font-medium">Subtotal</span>
            <span className="font-medium">${orderDetails.subtotal}</span>
          </div>
          <div className="flex justify-between text-lg font-bold">
            <span>Total</span>
            <span>${orderDetails.total}</span>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg mb-6">
        <h3 className="text-lg font-bold mb-4">Payment Method</h3>
        <PaymentElement />
      </div>
      
      {paymentStatus === 'success' ? (
        <div className="flex items-center justify-center p-4 bg-green-50 text-green-700 rounded-lg mb-4">
          <CheckCircle className="h-6 w-6 mr-2" />
          <span>Payment successful! Thank you for your order.</span>
        </div>
      ) : paymentStatus === 'error' ? (
        <div className="flex items-center justify-center p-4 bg-red-50 text-red-700 rounded-lg mb-4">
          <AlertTriangle className="h-6 w-6 mr-2" />
          <span>{errorMessage || "An error occurred during payment processing."}</span>
        </div>
      ) : null}
      
      <div className="flex gap-3">
        <Button 
          type="button" 
          variant="outline" 
          className="flex-1" 
          onClick={onCancel}
          disabled={isProcessing || paymentStatus === 'success'}
        >
          Cancel
        </Button>
        <Button 
          type="submit" 
          className="flex-1 bg-primary text-white" 
          disabled={!stripe || isProcessing || paymentStatus === 'success'}
        >
          {isProcessing ? (
            <div className="flex items-center">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </div>
          ) : (
            `Pay $${orderDetails.total}`
          )}
        </Button>
      </div>
    </form>
  );
};

interface StripeCheckoutProps {
  orderData: {
    tableUsageId?: number;
    orderIds?: number[];
    amount: number;
    description: string;
  };
  orderDetails: {
    tableUsage?: {
      id: number;
      tableName: string;
      startTime: string;
      duration: string;
      amount: string;
    };
    orderItems?: {
      name: string;
      quantity: number;
      price: string;
    }[];
    subtotal: string;
    total: string;
  };
  onSuccess: () => void;
  onCancel: () => void;
}

export default function StripeCheckout({ orderData, orderDetails, onSuccess, onCancel }: StripeCheckoutProps) {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const [mockMode, setMockMode] = useState(false);
  const [mockPaymentIntentId, setMockPaymentIntentId] = useState<string | null>(null);

  useEffect(() => {
    async function createPaymentIntent() {
      try {
        setIsLoading(true);
        const response = await apiRequest("POST", "/api/pos/create-payment-intent", orderData);
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to create payment intent");
        }
        
        const data = await response.json();
        setClientSecret(data.clientSecret);
        
        // Check if we're in mock mode (development environment)
        if (data.mockMode) {
          setMockMode(true);
          setMockPaymentIntentId(data.paymentIntentId);
          console.log("Using mock payment mode for development");
        }
      } catch (err: any) {
        setError(err.message);
        toast({
          title: "Error",
          description: err.message || "Failed to initialize payment",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }
    
    createPaymentIntent();
  }, [orderData]);

  if (isLoading) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-10">
            <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
            <p className="text-gray-500">Initializing payment...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <AlertTriangle className="h-10 w-10 text-red-500 mb-4" />
            <p className="text-red-500 font-medium mb-2">Payment Error</p>
            <p className="text-gray-500">{error}</p>
            <Button onClick={onCancel} className="mt-6">
              Go Back
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Complete Your Payment</CardTitle>
        <CardDescription>
          Secure payment processing by Stripe
        </CardDescription>
      </CardHeader>
      <CardContent>
        {clientSecret && (
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            <CheckoutForm
              clientSecret={clientSecret}
              orderDetails={orderDetails}
              onSuccess={onSuccess}
              onCancel={onCancel}
              mockMode={mockMode}
              mockPaymentIntentId={mockPaymentIntentId}
            />
          </Elements>
        )}
      </CardContent>
    </Card>
  );
}