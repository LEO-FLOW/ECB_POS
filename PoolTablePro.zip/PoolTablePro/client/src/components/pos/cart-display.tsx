import { Button } from '@/components/ui/button';
import { Trash, Plus, Minus, ShoppingCart } from 'lucide-react';
import { CartItem } from './inventory-selector';

export interface CartDisplayProps {
  items: CartItem[];
  onUpdateItem: (item: CartItem) => void;
  onRemoveItem: (itemId: number) => void;
  onClear: () => void;
  onCheckout: () => void;
}

export function CartDisplay({ 
  items, 
  onUpdateItem, 
  onRemoveItem, 
  onClear, 
  onCheckout 
}: CartDisplayProps) {
  const handleIncreaseQuantity = (item: CartItem) => {
    onUpdateItem({
      ...item,
      quantity: item.quantity + 1
    });
  };
  
  const handleDecreaseQuantity = (item: CartItem) => {
    if (item.quantity > 1) {
      onUpdateItem({
        ...item,
        quantity: item.quantity - 1
      });
    } else {
      onRemoveItem(item.id);
    }
  };
  
  const calculateSubtotal = () => {
    return items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };
  
  return (
    <div className="border rounded-md overflow-hidden">
      <div className="bg-gray-100 p-3 flex justify-between items-center">
        <h3 className="font-medium flex items-center">
          <ShoppingCart className="h-4 w-4 mr-2" /> Current Cart
        </h3>
        {items.length > 0 && (
          <Button 
            size="sm" 
            variant="ghost" 
            className="h-8 px-2 text-gray-500"
            onClick={onClear}
          >
            <Trash className="h-4 w-4" />
          </Button>
        )}
      </div>
      
      <div className="p-3">
        {items.length > 0 ? (
          <div className="space-y-3">
            {items.map(item => (
              <div key={item.id} className="flex justify-between items-center border-b pb-2">
                <div className="flex-1">
                  <p className="font-medium">{item.name}</p>
                  <p className="text-sm text-gray-500">${item.price.toFixed(2)} each</p>
                </div>
                
                <div className="flex items-center gap-1">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-6 w-6"
                    onClick={() => handleDecreaseQuantity(item)}
                  >
                    <Minus className="h-3 w-3" />
                  </Button>
                  <span className="w-8 text-center">{item.quantity}</span>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-6 w-6"
                    onClick={() => handleIncreaseQuantity(item)}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
                
                <div className="ml-4 text-right">
                  <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
              </div>
            ))}
            
            <div className="pt-3 flex justify-between font-medium text-lg">
              <span>Total:</span>
              <span>${calculateSubtotal().toFixed(2)}</span>
            </div>
            
            <Button 
              className="w-full mt-3" 
              size="lg"
              onClick={onCheckout}
            >
              Add to Table
            </Button>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <p>No items in cart</p>
            <p className="text-sm">Add items from the inventory</p>
          </div>
        )}
      </div>
    </div>
  );
}