import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { InventorySelector, CartItem } from './inventory-selector';
import { CartDisplay } from './cart-display';
import { Coffee } from 'lucide-react';

interface InventoryDialogProps {
  onOrderComplete: (items: CartItem[]) => void;
  initialItems?: CartItem[];
  triggerButtonLabel?: string;
}

export function InventoryDialog({ 
  onOrderComplete, 
  initialItems = [],
  triggerButtonLabel = "Add Items"
}: InventoryDialogProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>(initialItems);
  const [isProcessingOrder, setIsProcessingOrder] = useState(false);

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      // Reset cart items when dialog is closed without completion
      setCartItems(initialItems);
    }
    setIsOpen(open);
  };

  const handleCheckout = () => {
    if (cartItems.length === 0) return;
    
    setIsProcessingOrder(true);
    
    // Call the onOrderComplete prop with the current cart items
    onOrderComplete(cartItems);
    
    // Close the dialog
    setIsOpen(false);
    setIsProcessingOrder(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="w-full flex items-center justify-center gap-2"
        >
          <Coffee className="h-4 w-4" />
          {triggerButtonLabel}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Add Food & Drinks</DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-6 py-4">
          <div className="grid gap-4">
            <InventorySelector
              onAddToCart={(item) => {
                // If item already exists in cart, replace it, else add it
                const itemIndex = cartItems.findIndex(cartItem => cartItem.id === item.id);
                if (itemIndex >= 0) {
                  const newCartItems = [...cartItems];
                  newCartItems[itemIndex] = item;
                  setCartItems(newCartItems);
                } else {
                  setCartItems([...cartItems, item]);
                }
              }}
              cartItems={cartItems}
            />
          </div>
          
          <div className="grid gap-4">
            <CartDisplay
              items={cartItems}
              onUpdateItem={(item) => {
                const newCartItems = cartItems.map(cartItem => 
                  cartItem.id === item.id ? item : cartItem
                );
                setCartItems(newCartItems);
              }}
              onRemoveItem={(itemId) => {
                setCartItems(cartItems.filter(item => item.id !== itemId));
              }}
              onClear={() => setCartItems([])}
              onCheckout={handleCheckout}
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => setIsOpen(false)}
          >
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}