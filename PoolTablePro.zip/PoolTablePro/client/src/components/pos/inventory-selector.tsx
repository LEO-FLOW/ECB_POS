import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Plus, Minus } from 'lucide-react';

export interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  category: string;
}

interface InventorySelectorProps {
  onAddToCart: (item: CartItem) => void;
  cartItems: CartItem[];
}

// TypeScript interface for inventory items
interface InventoryItem {
  id: number;
  name: string;
  price: string;
  categoryId: number;
  categoryName: string;
  description?: string;
  cost: string;
  sku?: string;
  barcode?: string;
  currentStock?: number;
  minStockLevel?: number;
  imageUrl?: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export function InventorySelector({ onAddToCart, cartItems }: InventorySelectorProps) {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Fetch inventory items with type
  const { data: items = [] } = useQuery<InventoryItem[]>({
    queryKey: ['/api/inventory/items']
  });
  
  // Helper function to get category name - use the categoryName field directly
  const getCategoryName = (item: InventoryItem): string => {
    return item.categoryName || 'Unknown';
  };
  
  const getItemQuantityInCart = (itemId: number): number => {
    const item = cartItems.find(item => item.id === itemId);
    return item ? item.quantity : 0;
  };
  
  const handleAddItem = (item: InventoryItem): void => {
    const existingItem = cartItems.find(cartItem => cartItem.id === item.id);
    
    onAddToCart({
      id: item.id,
      name: item.name,
      price: parseFloat(item.price), // Convert string price to number
      quantity: existingItem ? existingItem.quantity + 1 : 1,
      category: getCategoryName(item)
    });
  };
  
  const handleRemoveItem = (item: InventoryItem): void => {
    const existingItem = cartItems.find(cartItem => cartItem.id === item.id);
    
    if (existingItem && existingItem.quantity > 1) {
      onAddToCart({
        id: item.id,
        name: item.name,
        price: parseFloat(item.price), // Convert string price to number
        quantity: existingItem.quantity - 1,
        category: getCategoryName(item)
      });
    }
  };
  
  // Safe filtering with proper type handling
  const filteredItems = searchQuery 
    ? (items as InventoryItem[]).filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        getCategoryName(item).toLowerCase().includes(searchQuery.toLowerCase())
      )
    : items;
  
  const drinkItems = (filteredItems as InventoryItem[]).filter(item => getCategoryName(item) === 'Drinks');
  const foodItems = (filteredItems as InventoryItem[]).filter(item => getCategoryName(item) === 'Snacks');
  const otherItems = (filteredItems as InventoryItem[]).filter(item => 
    getCategoryName(item) === 'Pool Accessories' || 
    !['Drinks', 'Snacks'].includes(getCategoryName(item))
  );
  
  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input 
          placeholder="Search items..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
        />
        <Button variant="outline" size="icon">
          <Search className="h-4 w-4" />
        </Button>
      </div>
      
      <Tabs defaultValue="drinks">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="drinks">Drinks</TabsTrigger>
          <TabsTrigger value="food">Snacks</TabsTrigger>
          <TabsTrigger value="other">Pool Accessories</TabsTrigger>
        </TabsList>
        
        <TabsContent value="drinks" className="space-y-2">
          {drinkItems.length > 0 ? (
            <div className="grid grid-cols-1 gap-2">
              {drinkItems.map(item => (
                <ItemCard 
                  key={item.id} 
                  item={item} 
                  quantity={getItemQuantityInCart(item.id)}
                  onAdd={() => handleAddItem(item)}
                  onRemove={() => handleRemoveItem(item)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-4 text-gray-500">No drinks found</div>
          )}
        </TabsContent>
        
        <TabsContent value="food" className="space-y-2">
          {foodItems.length > 0 ? (
            <div className="grid grid-cols-1 gap-2">
              {foodItems.map(item => (
                <ItemCard 
                  key={item.id} 
                  item={item} 
                  quantity={getItemQuantityInCart(item.id)}
                  onAdd={() => handleAddItem(item)}
                  onRemove={() => handleRemoveItem(item)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-4 text-gray-500">No snacks found</div>
          )}
        </TabsContent>
        
        <TabsContent value="other" className="space-y-2">
          {otherItems.length > 0 ? (
            <div className="grid grid-cols-1 gap-2">
              {otherItems.map(item => (
                <ItemCard 
                  key={item.id} 
                  item={item} 
                  quantity={getItemQuantityInCart(item.id)}
                  onAdd={() => handleAddItem(item)}
                  onRemove={() => handleRemoveItem(item)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-4 text-gray-500">No pool accessories found</div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ItemCard({ 
  item, 
  quantity, 
  onAdd, 
  onRemove 
}: { 
  item: InventoryItem; 
  quantity: number; 
  onAdd: () => void; 
  onRemove: () => void; 
}) {
  return (
    <div className="flex justify-between items-center p-2 border rounded hover:bg-gray-50">
      <div>
        <p className="font-medium">{item.name}</p>
        <div className="flex items-center gap-2">
          <p className="text-sm text-gray-500">${parseFloat(item.price).toFixed(2)}</p>
          {item.categoryName && (
            <Badge variant="outline" className="text-xs">
              {item.categoryName}
            </Badge>
          )}
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        {quantity > 0 && (
          <>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-7 w-7"
              onClick={onRemove}
            >
              <Minus className="h-3 w-3" />
            </Button>
            <span className="w-5 text-center">{quantity}</span>
          </>
        )}
        <Button 
          variant="outline" 
          size="icon" 
          className="h-7 w-7"
          onClick={onAdd}
        >
          <Plus className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}