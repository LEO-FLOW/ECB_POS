import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function formatDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  
  if (hours === 0) {
    return `${remainingMinutes}m`;
  } else if (remainingMinutes === 0) {
    return `${hours}h`;
  } else {
    return `${hours}h ${remainingMinutes}m`;
  }
}

export function calculateSessionDuration(startTime: string | Date, endTime?: string | Date): number {
  const start = new Date(startTime);
  const end = endTime ? new Date(endTime) : new Date();
  
  const diffInMs = end.getTime() - start.getTime();
  const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
  
  return diffInMinutes;
}

export function calculateSessionCost(durationInMinutes: number, hourlyRate: number): number {
  const durationInHours = durationInMinutes / 60;
  return durationInHours * hourlyRate;
}

export function applyDiscount(amount: number, discountRate: number = 0): number {
  return amount * (1 - discountRate);
}
