import { MainLayout } from "@/components/layout/main-layout";
import { useQuery } from "@tanstack/react-query";
import { Transaction } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { PlusIcon, Search, Calendar, Download, ChevronUp, ChevronDown } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { TransactionForm } from "@/components/transactions/transaction-form";
import { useState } from "react";
import { 
  format, 
  parseISO, 
  startOfDay, 
  endOfDay, 
  startOfWeek, 
  endOfWeek, 
  startOfMonth, 
  endOfMonth 
} from "date-fns";
import { Input } from "@/components/ui/input";
import { DatePicker } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

export default function TransactionsPage() {
  const [transactionDialogOpen, setTransactionDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [dateRange, setDateRange] = useState<{from: Date, to: Date} | undefined>();
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [transactionType, setTransactionType] = useState<string | undefined>(undefined);

  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const today = new Date();
  const weekStart = startOfWeek(today);
  const weekEnd = endOfWeek(today);
  const monthStart = startOfMonth(today);
  const monthEnd = endOfMonth(today);
  
  // Group transactions by relatedTableUsageId
  const groupTransactionsByTableUsage = (txList: Transaction[]) => {
    if (!txList || txList.length === 0) return [];
    
    // First separate transactions that have relatedTableUsageId and those that don't
    const tableRelatedTx: Record<number, Transaction[]> = {};
    const standaloneTx: Transaction[] = [];
    
    txList.forEach(tx => {
      if (tx.relatedTableUsageId) {
        if (!tableRelatedTx[tx.relatedTableUsageId]) {
          tableRelatedTx[tx.relatedTableUsageId] = [];
        }
        tableRelatedTx[tx.relatedTableUsageId].push(tx);
      } else {
        standaloneTx.push(tx);
      }
    });
    
    // Convert grouped transactions to standalone transaction format
    const groupedTx = Object.values(tableRelatedTx).map(group => {
      // Find the table-session transaction to use as the main transaction
      const mainTx = group.find(tx => tx.type === "table-session") || group[0];
      
      // Calculate total amount from all transactions in this group
      const totalAmount = group.reduce((sum, tx) => sum + Number(tx.amount), 0);
      
      // Create an enhanced version of the main transaction with additional info
      return {
        ...mainTx,
        amount: totalAmount.toString(),
        isGrouped: true,
        relatedTransactions: group.filter(tx => tx.id !== mainTx.id),
        description: mainTx.description,
      };
    });
    
    // Combine standalone and grouped transactions
    return [...standaloneTx, ...groupedTx];
  };

  // First filter the transactions
  const rawFilteredTransactions = transactions?.filter(transaction => {
    // Search query filter
    const descriptionMatch = transaction.description?.toLowerCase().includes(searchQuery.toLowerCase()) || false;
    const typeMatch = transaction.type.toLowerCase().includes(searchQuery.toLowerCase());
    const searchMatches = descriptionMatch || typeMatch;
    
    // Date range filter
    let dateMatches = true;
    if (dateRange?.from && dateRange?.to) {
      const transactionDate = new Date(transaction.timestamp);
      dateMatches = transactionDate >= startOfDay(dateRange.from) && 
                   transactionDate <= endOfDay(dateRange.to);
    }
    
    // Transaction type filter
    let typeFilterMatches = true;
    if (transactionType && transactionType !== "all") {
      typeFilterMatches = transaction.type === transactionType;
    }
    
    return searchMatches && dateMatches && typeFilterMatches;
  }) || [];
  
  // Then group them
  const filteredTransactions = groupTransactionsByTableUsage(rawFilteredTransactions);

  // Create date-filtered groups
  const todayTransactions = groupTransactionsByTableUsage(
    rawFilteredTransactions.filter(tx => {
      const txDate = new Date(tx.timestamp);
      return txDate >= startOfDay(today) && txDate <= endOfDay(today);
    })
  );
  
  const weekTransactions = groupTransactionsByTableUsage(
    rawFilteredTransactions.filter(tx => {
      const txDate = new Date(tx.timestamp);
      return txDate >= weekStart && txDate <= weekEnd;
    })
  );
  
  const monthTransactions = groupTransactionsByTableUsage(
    rawFilteredTransactions.filter(tx => {
      const txDate = new Date(tx.timestamp);
      return txDate >= monthStart && txDate <= monthEnd;
    })
  );

  const calculateTotal = (txList: Transaction[]) => {
    return txList.reduce((sum, tx) => sum + Number(tx.amount), 0).toFixed(2);
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case "table-session": return "bg-blue-100 text-blue-800";
      case "membership": return "bg-purple-100 text-purple-800";
      case "food-drinks": return "bg-orange-100 text-orange-800";
      case "other": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const formatTransactionType = (type: string) => {
    switch (type) {
      case "table-session": return "Table Session";
      case "membership": return "Membership";
      case "food-drinks": return "Food & Drinks";
      case "other": return "Other";
      default: return type;
    }
  };

  // Enhanced Transaction Item that can display grouped transactions
  const TransactionItem = ({ transaction }: { transaction: any }) => {
    const [expanded, setExpanded] = useState(false);
    const isGrouped = transaction.isGrouped && transaction.relatedTransactions?.length > 0;
    
    return (
      <Card className="mb-4">
        <CardContent className="py-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center">
                <Badge className={getTransactionTypeColor(transaction.type)}>
                  {formatTransactionType(transaction.type)}
                </Badge>
                <p className="ml-2 text-sm font-medium text-gray-900">{transaction.description}</p>
                {isGrouped && (
                  <Badge className="ml-2 bg-gray-100 text-gray-800">
                    Multiple Items
                  </Badge>
                )}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {format(parseISO(transaction.timestamp.toString()), "MMM d, yyyy • h:mm a")}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">${Number(transaction.amount).toFixed(2)}</p>
              <p className="text-xs text-gray-500 mt-1">
                User ID: {transaction.userId || "Guest"}
              </p>
            </div>
          </div>
          
          {isGrouped && (
            <div className="mt-2">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-xs flex items-center gap-1 px-2 h-8"
                onClick={() => setExpanded(!expanded)}
              >
                {expanded ? "Hide details" : "Show details"}
                {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
              </Button>
              
              {expanded && (
                <div className="mt-2 space-y-2 pl-4 border-l-2 border-gray-200">
                  {transaction.relatedTransactions.map((relatedTx: Transaction) => (
                    <div key={relatedTx.id} className="flex justify-between text-sm">
                      <div className="flex items-center">
                        <Badge variant="outline" className={getTransactionTypeColor(relatedTx.type)}>
                          {formatTransactionType(relatedTx.type)}
                        </Badge>
                        <p className="ml-2 text-gray-600">{relatedTx.description}</p>
                      </div>
                      <p className="font-medium">${Number(relatedTx.amount).toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  const TransactionSummary = ({ transactions }: { transactions: Transaction[] }) => {
    const total = calculateTotal(transactions);
    
    const tableSessionTotal = calculateTotal(
      transactions.filter(tx => tx.type === "table-session")
    );
    
    const membershipTotal = calculateTotal(
      transactions.filter(tx => tx.type === "membership")
    );
    
    const foodDrinksTotal = calculateTotal(
      transactions.filter(tx => tx.type === "food-drinks")
    );
    
    const otherTotal = calculateTotal(
      transactions.filter(tx => tx.type === "other")
    );
    
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Transaction Summary</CardTitle>
          <CardDescription>Overview of selected transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-xs text-blue-800 font-medium">Table Sessions</p>
              <p className="text-xl font-bold text-blue-900">${tableSessionTotal}</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-xs text-purple-800 font-medium">Memberships</p>
              <p className="text-xl font-bold text-purple-900">${membershipTotal}</p>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <p className="text-xs text-orange-800 font-medium">Food & Drinks</p>
              <p className="text-xl font-bold text-orange-900">${foodDrinksTotal}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-xs text-gray-800 font-medium">Other</p>
              <p className="text-xl font-bold text-gray-900">${otherTotal}</p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="bg-gray-50 flex justify-between items-center">
          <p className="font-medium">Total</p>
          <p className="text-2xl font-bold">${total}</p>
        </CardFooter>
      </Card>
    );
  };

  return (
    <MainLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-heading font-bold text-gray-900 mb-4 sm:mb-0">Transactions</h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline"
            className="flex items-center gap-2 bg-gray-200 border-gray-300 hover:bg-gray-300 text-gray-800 shadow-sm"
          >
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button 
            onClick={() => setTransactionDialogOpen(true)}
            className="bg-gray-700 hover:bg-gray-800 text-white shadow-md"
          >
            <PlusIcon className="h-5 w-5 mr-2 text-white" />
            New Transaction
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search transactions..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="flex items-center gap-2 bg-gray-200 border-gray-300 hover:bg-gray-300 text-gray-800 shadow-sm">
              <Calendar className="h-4 w-4" />
              {dateRange?.from ? (
                dateRange.to ? (
                  <>
                    {format(dateRange.from, "MMM d, yyyy")} - {format(dateRange.to, "MMM d, yyyy")}
                  </>
                ) : (
                  format(dateRange.from, "MMM d, yyyy")
                )
              ) : (
                "Date Range"
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="end">
            <DatePicker
              mode="range"
              selected={dateRange}
              onSelect={(range) => {
                setDateRange(range as any);
                if (range?.from && range?.to) {
                  setDatePickerOpen(false);
                }
              }}
              numberOfMonths={2}
              initialFocus
            />
          </PopoverContent>
        </Popover>
        <Select onValueChange={setTransactionType} value={transactionType || undefined}>
          <SelectTrigger className="w-[180px] bg-gray-200 border-gray-300 hover:bg-gray-300 text-gray-800 shadow-sm">
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="table-session">Table Session</SelectItem>
            <SelectItem value="membership">Membership</SelectItem>
            <SelectItem value="food-drinks">Food & Drinks</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filteredTransactions.length > 0 && (
        <TransactionSummary transactions={filteredTransactions as any} />
      )}

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-2">
                    <div className="h-6 w-24 bg-gray-200 rounded-full"></div>
                    <div className="h-4 w-40 bg-gray-200 rounded"></div>
                  </div>
                  <div className="h-6 w-16 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="today">Today (${calculateTotal(todayTransactions as any)})</TabsTrigger>
            <TabsTrigger value="week">This Week (${calculateTotal(weekTransactions as any)})</TabsTrigger>
            <TabsTrigger value="month">This Month (${calculateTotal(monthTransactions as any)})</TabsTrigger>
            <TabsTrigger value="all">All (${calculateTotal(filteredTransactions as any)})</TabsTrigger>
          </TabsList>
          
          <TabsContent value="today" className="space-y-2">
            {todayTransactions.length > 0 ? (
              todayTransactions.map(transaction => (
                <TransactionItem key={transaction.id} transaction={transaction} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No transactions today</p>
            )}
          </TabsContent>
          
          <TabsContent value="week" className="space-y-2">
            {weekTransactions.length > 0 ? (
              weekTransactions.map(transaction => (
                <TransactionItem key={transaction.id} transaction={transaction} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No transactions this week</p>
            )}
          </TabsContent>
          
          <TabsContent value="month" className="space-y-2">
            {monthTransactions.length > 0 ? (
              monthTransactions.map(transaction => (
                <TransactionItem key={transaction.id} transaction={transaction} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No transactions this month</p>
            )}
          </TabsContent>
          
          <TabsContent value="all" className="space-y-2">
            {filteredTransactions.length > 0 ? (
              filteredTransactions.map(transaction => (
                <TransactionItem key={transaction.id} transaction={transaction} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No transactions found</p>
            )}
          </TabsContent>
        </Tabs>
      )}

      <Dialog open={transactionDialogOpen} onOpenChange={setTransactionDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogTitle>Create New Transaction</DialogTitle>
          <TransactionForm onSuccess={() => setTransactionDialogOpen(false)} />
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}