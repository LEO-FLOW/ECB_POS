import { MainLayout } from "@/components/layout/main-layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Table as TableType, TableUsage, User } from "@shared/schema";
import { TableCard } from "@/components/tables/table-card";
import { PoolRoomLayout } from "@/components/tables/pool-room-layout";
import { TableSidePanel } from "@/components/tables/table-side-panel";
import { Button } from "@/components/ui/button";
import { 
  PlusIcon, 
  LayoutGrid, 
  GridIcon, 
  UserPlus, 
  Users, 
  Clock, 
  CreditCard, 
  Coffee, 
  Search,
  CheckCircle2,
  X
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogTitle, DialogHeader } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTableSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow, format } from "date-fns";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from "@/components/ui/accordion";

export default function TablesPage() {
  const [newTableDialogOpen, setNewTableDialogOpen] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "layout">("layout");
  const [addServiceDialogOpen, setAddServiceDialogOpen] = useState(false);
  const [selectedTableId, setSelectedTableId] = useState<number | null>(null);
  const [selectedTableUsageId, setSelectedTableUsageId] = useState<number | null>(null);
  const [selectedTable, setSelectedTable] = useState<TableType | null>(null);
  const [showDetailsPanel, setShowDetailsPanel] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [customerSearchOpen, setCustomerSearchOpen] = useState(false);
  const { toast } = useToast();
  
  const { data: tables = [], isLoading } = useQuery<TableType[]>({
    queryKey: ["/api/tables"],
  });

  const { data: members = [] } = useQuery<User[]>({
    queryKey: ["/api/members"],
  });
  
  const { data: inventoryItems = [] } = useQuery({
    queryKey: ["/api/inventory/items"],
    queryFn: async () => {
      // In a production app, this would fetch real inventory items
      return [
        { id: 1, name: "Coffee", price: 2.50, category: "Drinks", inStock: true },
        { id: 2, name: "Beer", price: 5.00, category: "Drinks", inStock: true },
        { id: 3, name: "Soda", price: 1.50, category: "Drinks", inStock: true },
        { id: 4, name: "Sandwich", price: 8.00, category: "Snacks", inStock: true },
        { id: 5, name: "Chips", price: 1.00, category: "Snacks", inStock: true },
        { id: 6, name: "Chalk", price: 1.00, category: "Pool Accessories", inStock: true },
        { id: 7, name: "Pool Cue Rental", price: 5.00, category: "Pool Accessories", inStock: true },
      ];
    }
  });

  // Get the customer's active orders for the selected table
  const { data: tableOrders = [] } = useQuery({
    queryKey: ["/api/orders/table", selectedTableId],
    enabled: !!selectedTableId,
    queryFn: async () => {
      // In a production app, this would fetch real orders for the table
      if (!selectedTableId) return [];
      return [
        { id: 1, name: "Beer", price: 5.00, quantity: 2, total: 10.00, time: "10 min ago" },
        { id: 2, name: "Chips", price: 1.00, quantity: 1, total: 1.00, time: "5 min ago" },
      ];
    }
  });
  
  const createTableMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/tables", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      toast({
        title: "Success",
        description: "Table created successfully",
      });
      setNewTableDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create table: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const updateTableStatusMutation = useMutation({
    mutationFn: async ({ tableId, status }: { tableId: number; status: string }) => {
      return apiRequest("PATCH", `/api/tables/${tableId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      toast({
        title: "Status Updated",
        description: "Table status has been updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update table status: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const startSessionMutation = useMutation({
    mutationFn: async ({ tableId, userId }: { tableId: number; userId?: number }) => {
      return apiRequest("POST", "/api/table-usage", {
        tableId,
        userId,
        startTime: new Date().toISOString(),
        status: "active",
      });
    },
    onSuccess: async (response, variables) => {
      // After a successful session start, make sure the table is selected
      // and the side panel shows details for this table
      
      // Get the tableUsageId from the response first
      const data = await response.json();
      const tableUsageId = data?.id;
      
      // Update the tables data
      await queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      
      // Fetch the tables directly to get the latest data
      const tablesResponse = await fetch('/api/tables');
      const tables = await tablesResponse.json();
      
      // Find the updated table with current usage information
      const updatedTable = tables.find((t: TableType) => t.id === variables.tableId);
      
      if (updatedTable) {
        // Update the UI
        setSelectedTable(updatedTable);
        setSelectedTableId(variables.tableId);
        setSelectedTableUsageId(tableUsageId || null);
        setShowDetailsPanel(true);
      }
      
      toast({
        title: "Session Started",
        description: "Table session has been started",
      });
      setCustomerSearchOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to start session: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const endSessionMutation = useMutation({
    mutationFn: async ({ tableUsageId }: { tableUsageId: number }) => {
      // First get the table usage details to calculate charge
      const tableUsage = await apiRequest("GET", `/api/table-usage/${tableUsageId}`)
        .then(res => res.json());
      
      // Get the table details to get hourly rate and name
      const table = tables.find(t => t.id === tableUsage.tableId);
      if (!table) throw new Error("Table not found");
      
      // Calculate the total hours used
      const startTime = new Date(tableUsage.startTime);
      const endTime = new Date();
      const diffMs = endTime.getTime() - startTime.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);
      const charge = diffHours * Number(table.hourlyRate);
      
      // Create a transaction for the table time
      await apiRequest("POST", "/api/transactions", {
        userId: tableUsage.primaryUserId,
        amount: charge.toFixed(2),
        type: "table-session",
        description: `Table ${table.name} - ${diffHours.toFixed(2)} hours @ $${table.hourlyRate}/hr`,
        relatedTableUsageId: tableUsageId
      });
      
      // End the table usage session
      return apiRequest("PATCH", `/api/table-usage/${tableUsageId}`, {
        endTime: endTime.toISOString(),
        status: "completed",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Session Ended",
        description: "Table session has been ended and payment processed",
      });
    },
    onError: (error) => {
      console.error("Failed to end session:", error);
      toast({
        title: "Error",
        description: `Failed to end session: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const addOrderItemMutation = useMutation({
    mutationFn: async ({ tableId, itemId, quantity }: { tableId: number; itemId: number; quantity: number }) => {
      // This would add an item to the table's order/tab
      return apiRequest("POST", "/api/orders/items", { tableId, itemId, quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders/table", selectedTableId] });
      toast({
        title: "Item Added",
        description: "Item has been added to the table's tab",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add item: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const form = useForm({
    resolver: zodResolver(insertTableSchema),
    defaultValues: {
      name: "",
      type: "",
      status: "available",
      hourlyRate: "",
    },
  });
  
  const onSubmit = (data: any) => {
    createTableMutation.mutate({
      ...data,
      hourlyRate: data.hourlyRate.toString(), // Make sure hourlyRate is sent as a string
    });
  };

  const handleTableAction = (tableId: number, action: string, tableUsageId?: number) => {
    // Set the selected table - do this for all actions
    const table = tables.find(t => t.id === tableId);
    if (table) {
      setSelectedTable(table);
      setSelectedTableId(tableId);
      setSelectedTableUsageId(tableUsageId || null);
    }

    switch (action) {
      case "available":
      case "maintenance":
        updateTableStatusMutation.mutate({ tableId, status: action });
        break;
      case "start-session":
        // Start session directly from side panel instead of showing dialog
        // The side panel will have the customer selector
        break;
      case "end-session":
        if (tableUsageId) {
          endSessionMutation.mutate({ tableUsageId });
        }
        break;
      case "add-service":
        setAddServiceDialogOpen(true);
        break;
      case "view-details":
        // Just selecting the table is enough
        break;
      default:
        break;
    }
  };

  const handleAddOrderItem = (itemId: number) => {
    if (selectedTableId) {
      addOrderItemMutation.mutate({ tableId: selectedTableId, itemId, quantity: 1 });
    }
  };

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    // Filter members based on search query
    const results = members.filter(member => 
      member.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (member.fullName && member.fullName.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    setSearchResults(results);
  };

  const handleSelectCustomer = (userId?: number) => {
    if (selectedTableId) {
      startSessionMutation.mutate({ tableId: selectedTableId, userId });
    }
  };

  // Close details panel when no table is selected
  useEffect(() => {
    if (!selectedTableId) {
      setShowDetailsPanel(false);
    }
  }, [selectedTableId]);

  // Update selected table when tables data changes
  useEffect(() => {
    if (selectedTableId) {
      const updatedTable = tables.find(t => t.id === selectedTableId);
      if (updatedTable) {
        setSelectedTable(updatedTable);
        console.log('Updating selected table with latest data:', updatedTable);
      }
    }
  }, [tables, selectedTableId]);

  // Update search results when query changes
  useEffect(() => {
    handleSearch();
  }, [searchQuery, members]);
  
  return (
    <MainLayout>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-heading font-bold text-gray-900">Pool Tables</h1>
        
        <div className="flex items-center gap-3">
          <Tabs value={viewMode} className="mr-2">
            <TabsList className="h-9">
              <TabsTrigger value="layout" onClick={() => setViewMode("layout")}>
                <LayoutGrid className="h-4 w-4 mr-1" /> Room Layout
              </TabsTrigger>
              <TabsTrigger value="grid" onClick={() => setViewMode("grid")}>
                <GridIcon className="h-4 w-4 mr-1" /> Grid View
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <Button onClick={() => setNewTableDialogOpen(true)} className="bg-secondary hover:bg-secondary-light">
            <PlusIcon className="h-5 w-5 mr-2" />
            Add New Table
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="bg-white rounded-lg shadow p-6 h-80 animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/4 mb-8"></div>
          <div className="grid grid-cols-3 gap-4">
            <div className="h-20 bg-gray-200 rounded"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Pool Room Layout/Grid View - Takes 8 columns */}
          <div className="lg:col-span-8">
            {viewMode === "layout" ? (
              <PoolRoomLayout 
                editable={true} 
                onTableAction={handleTableAction}
                onAddTable={() => setNewTableDialogOpen(true)}
                selectedTableId={selectedTableId || undefined}
              />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                {tables.map((table) => (
                  <TableCard 
                    key={table.id} 
                    table={table} 
                    onTableAction={handleTableAction}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Table Side Panel - Always visible, takes 4 columns */}
          <div className="lg:col-span-4">
            {selectedTable ? (
              <TableSidePanel
                table={selectedTable}
                onClose={() => {
                  setSelectedTable(null);
                  setSelectedTableId(null);
                  setShowDetailsPanel(false);
                }}
                onTableAction={handleTableAction}
              />
            ) : (
              <div className="bg-gray-50 h-full rounded-lg border p-8 flex flex-col items-center justify-center text-center">
                <PlusIcon className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-500">No Table Selected</h3>
                <p className="text-gray-400 mt-2">
                  Click on a table to view details and manage sessions
                </p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Add New Table Dialog */}
      <Dialog open={newTableDialogOpen} onOpenChange={setNewTableDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Table</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Table Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Table 1" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Table Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select table type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="7ft Bar">7ft Bar</SelectItem>
                        <SelectItem value="8ft Standard">8ft Standard</SelectItem>
                        <SelectItem value="9ft Tournament">9ft Tournament</SelectItem>
                        <SelectItem value="Snooker">Snooker</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="hourlyRate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Hourly Rate ($)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="12.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button 
                type="submit" 
                className="w-full bg-secondary hover:bg-secondary-light"
                disabled={createTableMutation.isPending}
              >
                {createTableMutation.isPending ? "Creating..." : "Create Table"}
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Customer Search Dialog for Starting Sessions */}
      <Dialog open={customerSearchOpen} onOpenChange={setCustomerSearchOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Customer to Table</DialogTitle>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="flex gap-2">
              <Input 
                placeholder="Search by name or username..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
              <Button variant="outline" size="icon" onClick={handleSearch}>
                <Search className="h-4 w-4" />
              </Button>
            </div>
            
            {searchResults.length > 0 ? (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {searchResults.map(customer => (
                  <div 
                    key={customer.id} 
                    className="flex justify-between items-center p-2 hover:bg-gray-100 rounded cursor-pointer"
                    onClick={() => handleSelectCustomer(customer.id)}
                  >
                    <div>
                      <p className="font-medium">{customer.fullName || customer.username}</p>
                      <p className="text-xs text-gray-500">{customer.username}</p>
                    </div>
                    <Button size="icon" variant="ghost">
                      <CheckCircle2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : searchQuery ? (
              <p className="text-gray-500 py-2">No customers found with that name</p>
            ) : null}
            
            <div className="flex flex-col gap-2 pt-2">
              <Button onClick={() => handleSelectCustomer()} className="w-full">
                <Users className="h-4 w-4 mr-2" /> Start as Walk-in Customer
              </Button>
              <Button variant="outline" onClick={() => setCustomerSearchOpen(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Services/Items Dialog */}
      <Dialog open={addServiceDialogOpen} onOpenChange={setAddServiceDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Add Items to Table</DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <Tabs defaultValue="drinks">
              <TabsList className="mb-4">
                <TabsTrigger value="drinks">Drinks</TabsTrigger>
                <TabsTrigger value="food">Snacks</TabsTrigger>
                <TabsTrigger value="other">Pool Accessories</TabsTrigger>
              </TabsList>
              
              <TabsContent value="drinks" className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  {inventoryItems
                    .filter(item => item.category === 'Drinks')
                    .map(item => (
                      <Button 
                        key={item.id} 
                        variant="outline" 
                        className="justify-between h-auto py-3"
                        onClick={() => handleAddOrderItem(item.id)}
                      >
                        <span>{item.name}</span>
                        <Badge variant="secondary">${item.price.toFixed(2)}</Badge>
                      </Button>
                    ))
                  }
                </div>
              </TabsContent>
              
              <TabsContent value="food" className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  {inventoryItems
                    .filter(item => item.category === 'Snacks')
                    .map(item => (
                      <Button 
                        key={item.id} 
                        variant="outline" 
                        className="justify-between h-auto py-3"
                        onClick={() => handleAddOrderItem(item.id)}
                      >
                        <span>{item.name}</span>
                        <Badge variant="secondary">${item.price.toFixed(2)}</Badge>
                      </Button>
                    ))
                  }
                </div>
              </TabsContent>
              
              <TabsContent value="other" className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  {inventoryItems
                    .filter(item => item.category === 'Pool Accessories')
                    .map(item => (
                      <Button 
                        key={item.id} 
                        variant="outline" 
                        className="justify-between h-auto py-3"
                        onClick={() => handleAddOrderItem(item.id)}
                      >
                        <span>{item.name}</span>
                        <Badge variant="secondary">${item.price.toFixed(2)}</Badge>
                      </Button>
                    ))
                  }
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setAddServiceDialogOpen(false)}>Close</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
