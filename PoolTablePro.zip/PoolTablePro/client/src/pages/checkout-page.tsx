import { useState, useEffect } from 'react';
import { useLocation, useRoute, Link } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import type { TableUsage, TableSessionCustomer, MembershipTier } from '@shared/schema';
// Import Table entity from schema with a different name to avoid collision
import type { Table as PoolTable } from '@shared/schema';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
// Import table UI components with explicit names to avoid collision
import * as TableUI from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import {
  ArrowLeft,
  CreditCard,
  Users,
  Receipt,
  Clock,
  User,
  UserPlus,
  Mail,
  Phone,
  Save,
  CheckCircle,
} from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';

export default function CheckoutPage() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute<{ tableUsageId: string }>('/tables/:tableUsageId/checkout');
  
  // Get the tableUsageId from the route parameter (preferred) or query string (fallback)
  const getTableUsageId = () => {
    // First try to get from route params
    if (params?.tableUsageId) {
      console.log("Found tableUsageId in route params:", params.tableUsageId);
      return params.tableUsageId;
    }
    
    // Fallback to query string
    const location = window.location;
    const searchParams = new URLSearchParams(location.search);
    const queryTableUsageId = searchParams.get('tableUsageId');
    
    if (queryTableUsageId) {
      console.log("Found tableUsageId in query string:", queryTableUsageId);
      return queryTableUsageId;
    }
    
    console.log("No tableUsageId found in URL");
    return null;
  };
  
  const tableUsageId = getTableUsageId();
  
  const { toast } = useToast();
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [isMembershipDialogOpen, setIsMembershipDialogOpen] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('cash');
  const [savePaymentInfo, setSavePaymentInfo] = useState(false);
  const [selectedMembershipTier, setSelectedMembershipTier] = useState<number | null>(null);
  
  // Get table usage details
  const { data: tableUsageData, isLoading: isLoadingTableUsage, error: tableUsageError } = useQuery({
    queryKey: ['/api/table-usage', tableUsageId],
    queryFn: async () => {
      if (!tableUsageId) return null;
      try {
        const response = await fetch(`/api/table-usage/${tableUsageId}`);
        if (!response.ok) {
          console.error(`Failed to fetch table usage data: ${response.status} ${response.statusText}`);
          if (response.status === 404) {
            return null; // Handle 404 elegantly
          }
          throw new Error('Failed to fetch table usage data');
        }
        return response.json();
      } catch (error) {
        console.error('Error fetching table usage:', error);
        return null; // Return null to prevent cascade failures
      }
    },
    enabled: !!tableUsageId,
    retry: 1, // Only retry once to avoid hammering the server
  });
  
  // Get table details
  const { data: tableData, isLoading: isLoadingTable, error: tableError } = useQuery({
    queryKey: ['/api/tables', tableUsageData?.tableId],
    queryFn: async () => {
      if (!tableUsageData?.tableId) return null;
      try {
        const response = await fetch(`/api/tables/${tableUsageData.tableId}`);
        if (!response.ok) {
          console.error(`Failed to fetch table data: ${response.status} ${response.statusText}`);
          if (response.status === 404) {
            return null; // Handle 404 elegantly
          }
          throw new Error('Failed to fetch table data');
        }
        return response.json();
      } catch (error) {
        console.error('Error fetching table data:', error);
        return null; // Return null to prevent cascade failures
      }
    },
    enabled: !!tableUsageData?.tableId,
    retry: 1, // Only retry once to avoid hammering the server
  });
  
  // Get customers assigned to this table usage
  const { data: tableCustomers = [], isLoading: isLoadingCustomers, error: customersError } = useQuery({
    queryKey: ['/api/table-session-customers', tableUsageId],
    queryFn: async () => {
      if (!tableUsageId) return [];
      try {
        const response = await fetch(`/api/table-session-customers?tableUsageId=${tableUsageId}`);
        if (!response.ok) {
          console.error(`Failed to fetch table customers: ${response.status} ${response.statusText}`);
          if (response.status === 404) {
            return []; // Handle 404 elegantly
          }
          throw new Error('Failed to fetch table customers');
        }
        return response.json();
      } catch (error) {
        console.error('Error fetching table customers:', error);
        return []; // Return empty array to prevent cascade failures
      }
    },
    enabled: !!tableUsageId,
    retry: 1, // Only retry once to avoid hammering the server
  });
  
  // Get order items for this table usage
  const { data: orderItems = [], isLoading: isLoadingOrders, error: ordersError } = useQuery({
    queryKey: ['/api/pos/orders/table', tableUsageId],
    queryFn: async () => {
      if (!tableUsageId) return [];
      try {
        console.log(`[DEBUG-CHECKOUT] Fetching orders for table usage ID: ${tableUsageId}`);
        const response = await fetch(`/api/pos/orders/table/${tableUsageId}`);
        console.log(`[DEBUG-CHECKOUT] Orders API response status: ${response.status}`);
        
        if (!response.ok) {
          console.error(`[DEBUG-CHECKOUT] Failed to fetch order data: ${response.status} ${response.statusText}`);
          // If 404, just return empty array (no orders yet)
          if (response.status === 404) return [];
          throw new Error('Failed to fetch order data');
        }
        
        const data = await response.json();
        console.log(`[DEBUG-CHECKOUT] Fetched ${data.length} orders with items:`, data);
        
        // Add direct manual check for specific fields in the response
        if (data && data.length > 0) {
          data.forEach((order: any, index: number) => {
            console.log(`[DEBUG-CHECKOUT] Order ${index}, ID: ${order.id}, Items count: ${order.items?.length || 'none'}`);
            if (order.items && order.items.length > 0) {
              order.items.forEach((item: any, itemIndex: number) => {
                console.log(`[DEBUG-CHECKOUT] Item ${itemIndex} in order ${index}: ID=${item.id}, inventoryItemId=${item.inventoryItemId}, name=${item.name || 'missing'}, price=${item.unitPrice || item.price || 'missing'}`);
              });
            }
          });
        } else {
          console.log(`[DEBUG-CHECKOUT] No orders found for table usage ${tableUsageId}`);
        }
        
        return data;
      } catch (error) {
        console.error('[DEBUG-CHECKOUT] Error fetching order data:', error);
        return []; // Return empty array to prevent cascade failures
      }
    },
    enabled: !!tableUsageId,
    retry: 1, // Only retry once to avoid hammering the server
    staleTime: 0, // Always refetch to get the latest orders
    refetchInterval: 5000, // Refetch every 5 seconds to ensure we have the latest data
  });
  
  // Get membership tiers
  const { data: membershipTiers = [], isLoading: isLoadingTiers, error: tiersError } = useQuery<MembershipTier[]>({
    queryKey: ['/api/members/tiers'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/members/tiers');
        if (!response.ok) {
          console.error(`Failed to fetch membership tiers: ${response.status} ${response.statusText}`);
          if (response.status === 404) {
            return []; // Handle 404 elegantly
          }
          throw new Error('Failed to fetch membership tiers');
        }
        return response.json();
      } catch (error) {
        console.error('Error fetching membership tiers:', error);
        return []; // Return empty array to prevent cascade failures
      }
    },
    retry: 1, // Only retry once to avoid hammering the server
  });
  
  // Mutation to complete the checkout
  const checkoutMutation = useMutation({
    mutationFn: async (data: any) => {
      if (!tableUsageId) {
        throw new Error('No table usage ID provided');
      }
      
      // Calculate the values needed for checkout
      const timeCharge = calculateTimeCharge();
      const orderTotal = calculateItemsTotal();
      const totalAmount = calculateTotal();
      const actualPaymentAmount = data.paymentAmount || totalAmount;
      
      // Log the checkout details to help with debugging
      console.log(`[CHECKOUT] Starting checkout for table usage ID: ${tableUsageId}`);
      console.log(`[CHECKOUT] Payment method: ${data.paymentMethod}`);
      console.log(`[CHECKOUT] Time charge: ${timeCharge}`);
      console.log(`[CHECKOUT] Order total: ${orderTotal}`);
      console.log(`[CHECKOUT] Total amount: ${totalAmount}`);
      console.log(`[CHECKOUT] Actual payment amount: ${actualPaymentAmount}`);
      
      // Use the more reliable general checkout endpoint
      const requestBody = {
        tableUsageId: tableUsageId,
        paymentMethod: data.paymentMethod,
        timeCharge,
        orderTotal,
        totalAmount,
        actualPaymentAmount,
        customerId: data.savePaymentInfo ? tableUsageData?.primaryUserId : undefined
      };
      
      console.log(`[CHECKOUT] Checkout request body:`, requestBody);
      const response = await apiRequest('POST', `/api/checkout`, requestBody);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error(`[CHECKOUT] Checkout error:`, errorData);
        throw new Error(errorData.message || 'Checkout failed');
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      // Close the payment dialog first
      setIsPaymentDialogOpen(false);
      
      // Check if the session was already completed
      if (data.alreadyCompleted) {
        toast({
          title: 'Already Checked Out',
          description: data.message || 'This table session has already been checked out.',
        });
        
        // Redirect back to tables page
        setTimeout(() => {
          setLocation('/tables');
        }, 1500);
        return;
      }
      
      toast({
        title: 'Checkout Complete',
        description: 'Table session has been checked out successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tables'] });
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/table-usage'] });
      queryClient.invalidateQueries({ queryKey: ['/api/table-usage/active'] });
      
      // Delay the redirect to give the user a chance to see the success message
      setTimeout(() => {
        setLocation('/tables');
      }, 1500);
    },
    onError: (error: any) => {
      toast({
        title: 'Checkout Failed',
        description: `Failed to check out: ${error.message}`,
        variant: 'destructive',
      });
    },
  });
  
  // Mutation to convert customer to member
  const convertToMemberMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/members/convert', data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Membership Created',
        description: 'Customer has been converted to a member successfully.',
      });
      setIsMembershipDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Conversion Failed',
        description: `Failed to convert customer: ${error.message}`,
        variant: 'destructive',
      });
    },
  });
  
  // Calculate time charge
  const calculateTimeCharge = () => {
    if (!tableUsageData || !tableData) return 0;
    
    const start = new Date(tableUsageData.startTime);
    const end = tableUsageData.endTime ? new Date(tableUsageData.endTime) : new Date();
    const diffMs = end.getTime() - start.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);
    
    return diffHours * Number(tableData.hourlyRate);
  };
  
  // Calculate items total
  const calculateItemsTotal = () => {
    console.log("[DEBUG-Total] Calculating items total with:", orderItems);
    
    return orderItems.reduce((sum: number, order: any) => {
      // Check if this order has items array (from our enhanced API endpoint)
      if (order.items && Array.isArray(order.items)) {
        // Sum up all items in this order
        const orderTotal = order.items.reduce((orderSum: number, item: any) => {
          // Try different price fields (unitPrice from DB or price added by API)
          const itemPrice = Number(item.unitPrice || item.price || 0);
          // Use totalPrice directly if available, otherwise calculate
          const itemTotal = item.totalPrice ? Number(item.totalPrice) : (itemPrice * item.quantity);
          
          console.log(`[DEBUG-Total] Item ${item.name || item.inventoryItemId}: price=${itemPrice}, qty=${item.quantity}, total=${itemTotal}`);
          return orderSum + itemTotal;
        }, 0);
        
        console.log(`[DEBUG-Total] Order ${order.id} total: ${orderTotal}`);
        return sum + orderTotal;
      }
      
      // Fallback for orders without items array
      if (order.price || order.unitPrice) {
        const price = Number(order.unitPrice || order.price || 0);
        const qty = order.quantity || 1;
        const total = order.totalPrice ? Number(order.totalPrice) : (price * qty);
        
        console.log(`[DEBUG-Total] Direct order ${order.id || 'unknown'}: price=${price}, qty=${qty}, total=${total}`);
        return sum + total;
      }
      
      return sum;
    }, 0);
  };
  
  // Calculate grand total
  const calculateTotal = () => {
    return calculateTimeCharge() + calculateItemsTotal();
  };
  
  // Format time duration
  const formatDuration = () => {
    if (!tableUsageData) return '0 mins';
    
    const start = new Date(tableUsageData.startTime);
    const end = tableUsageData.endTime ? new Date(tableUsageData.endTime) : new Date();
    const diffMs = end.getTime() - start.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) {
      return `${diffMins} min${diffMins !== 1 ? 's' : ''}`;
    } else {
      const hours = Math.floor(diffMins / 60);
      const mins = diffMins % 60;
      return `${hours} hr${hours !== 1 ? 's' : ''} ${mins} min${mins !== 1 ? 's' : ''}`;
    }
  };
  
  // Handle payment selection
  const handlePaymentMethodChange = (method: string) => {
    setSelectedPaymentMethod(method);
  };
  
  // Handle membership tier selection
  const handleMembershipTierChange = (tierId: number) => {
    setSelectedMembershipTier(tierId);
  };
  
  // Handle complete checkout
  const handleCompleteCheckout = () => {
    // Calculate payment amount (use calculated total for now, could add custom amount field later)
    const paymentAmount = calculateTotal();
    
    checkoutMutation.mutate({
      paymentMethod: selectedPaymentMethod,
      savePaymentInfo: savePaymentInfo,
      paymentAmount: paymentAmount
    });
  };
  
  // Handle convert to member
  const handleConvertToMember = (customerId: number, formData: FormData) => {
    const customerName = formData.get('customerName') as string;
    const email = formData.get('email') as string;
    const phone = formData.get('phone') as string;
    
    // Validate form
    if (!customerName || !email) {
      toast({
        title: 'Missing Information',
        description: 'Please provide name and email.',
        variant: 'destructive',
      });
      return;
    }
    
    convertToMemberMutation.mutate({
      customerId,
      membershipTierId: selectedMembershipTier,
      fullName: customerName,
      email,
      phoneNumber: phone,
      startDate: new Date().toISOString()
    });
  };
  
  if (isLoadingTableUsage || isLoadingTable) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
          <div className="text-center">
            <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full mb-4 mx-auto"></div>
            <p className="text-muted-foreground">Loading checkout information...</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!tableUsageData || !tableData) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto my-8 px-4">
          <div className="text-center p-8 border rounded-lg bg-red-50">
            <h2 className="text-xl font-bold mb-4 text-red-600">Table session not found</h2>
            <p className="mb-4">The requested table session does not exist or has already been checked out.</p>
            <Button onClick={() => setLocation('/tables')}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Return to Tables
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }
  
  const timeCharge = calculateTimeCharge();
  const itemsTotal = calculateItemsTotal();
  const grandTotal = calculateTotal();
  
  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto my-8 px-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Checkout</h1>
          <Button variant="outline" onClick={() => setLocation('/tables')}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Tables
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left Column - Session Details */}
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="mr-2 h-5 w-5 text-muted-foreground" />
                  Session Details
                </CardTitle>
                <CardDescription>
                  {tableData.name} ({tableData.type})
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Started</p>
                    <p className="font-medium">{format(new Date(tableUsageData.startTime), 'MMM d, h:mm a')}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="font-medium">{formatDuration()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Rate</p>
                    <p className="font-medium">${Number(tableData.hourlyRate).toFixed(2)}/hr</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <p className="font-medium capitalize">{tableUsageData.status}</p>
                  </div>
                </div>
                
                {/* Customers */}
                <div className="mt-4">
                  <h3 className="text-sm font-medium mb-2">Customers</h3>
                  {tableCustomers.length > 0 ? (
                    <div className="space-y-2">
                      {tableCustomers.map((customer: any) => (
                        <div key={customer.id} className="flex justify-between items-center border rounded-md p-2">
                          <div className="flex items-center">
                            {customer.isWalkIn ? (
                              <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                            ) : (
                              <User className="h-4 w-4 mr-2 text-muted-foreground" />
                            )}
                            <span>{customer.customerName || 'Walk-in Customer'}</span>
                          </div>
                          
                          {customer.isWalkIn && (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => setIsMembershipDialogOpen(true)}
                            >
                              <UserPlus className="h-4 w-4 mr-1" />
                              Convert to Member
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No customers assigned.</p>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Order Items */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Receipt className="mr-2 h-5 w-5 text-muted-foreground" />
                  Order Items
                </CardTitle>
              </CardHeader>
              <CardContent>
                {orderItems.length > 0 ? (
                  <TableUI.Table>
                    <TableUI.TableHeader>
                      <TableUI.TableRow>
                        <TableUI.TableHead>Item</TableUI.TableHead>
                        <TableUI.TableHead className="text-right">Qty</TableUI.TableHead>
                        <TableUI.TableHead className="text-right">Price</TableUI.TableHead>
                        <TableUI.TableHead className="text-right">Total</TableUI.TableHead>
                      </TableUI.TableRow>
                    </TableUI.TableHeader>
                    <TableUI.TableBody>
                      {/* Add debug logging */}
                      {console.log('[DEBUG] Order items in render:', orderItems)}
                      
                      {orderItems.flatMap((order: any, orderIndex: number) => {
                        console.log(`[DEBUG] Processing order ${orderIndex}:`, order);
                        
                        // Check if this order has items array
                        if (order.items && Array.isArray(order.items)) {
                          console.log(`[DEBUG] Order ${orderIndex} has ${order.items.length} items:`, order.items);
                          
                          return order.items.map((item: any, itemIndex: number) => {
                            console.log(`[DEBUG] Item ${itemIndex} in order ${orderIndex}:`, item);
                            
                            return (
                              <TableUI.TableRow key={`${orderIndex}-${itemIndex}`}>
                                <TableUI.TableCell>{item.name || `Item #${item.inventoryItemId}`}</TableUI.TableCell>
                                <TableUI.TableCell className="text-right">{item.quantity}</TableUI.TableCell>
                                <TableUI.TableCell className="text-right">${Number(item.unitPrice || item.price).toFixed(2)}</TableUI.TableCell>
                                <TableUI.TableCell className="text-right">${Number(item.totalPrice || (Number(item.unitPrice || item.price) * item.quantity)).toFixed(2)}</TableUI.TableCell>
                              </TableUI.TableRow>
                            );
                          });
                        }
                        
                        // Fallback for direct item objects
                        console.log(`[DEBUG] Order ${orderIndex} has no items array, treating as direct item:`, order);
                        return (
                          <TableUI.TableRow key={orderIndex}>
                            <TableUI.TableCell>{order.name || `Order #${order.id}`}</TableUI.TableCell>
                            <TableUI.TableCell className="text-right">{order.quantity || 1}</TableUI.TableCell>
                            <TableUI.TableCell className="text-right">${Number(order.unitPrice || order.price || 0).toFixed(2)}</TableUI.TableCell>
                            <TableUI.TableCell className="text-right">${Number(order.totalPrice || (Number(order.unitPrice || order.price || 0) * (order.quantity || 1))).toFixed(2)}</TableUI.TableCell>
                          </TableUI.TableRow>
                        );
                      })}
                    </TableUI.TableBody>
                  </TableUI.Table>
                ) : (
                  <p className="text-sm text-muted-foreground">No items ordered.</p>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Right Column - Payment Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Payment Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Time ({formatDuration()})</span>
                  <span>${timeCharge.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">
                    Items ({orderItems.reduce((count, order) => {
                      // Count items in nested structure
                      if (order.items && Array.isArray(order.items)) {
                        return count + order.items.length;
                      }
                      // Count direct items
                      return count + 1;
                    }, 0)})
                  </span>
                  <span>${itemsTotal.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center font-medium text-lg">
                  <span>Total</span>
                  <span>${grandTotal.toFixed(2)}</span>
                </div>
                
                <div className="pt-4 space-y-2">
                  <Button
                    className="w-full"
                    onClick={() => setIsPaymentDialogOpen(true)}
                  >
                    <CreditCard className="mr-2 h-4 w-4" />
                    Process Payment
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {/* Payment Dialog */}
        <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Payment</DialogTitle>
              <DialogDescription>
                Select a payment method to complete checkout.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="cash"
                    name="paymentMethod"
                    value="cash"
                    checked={selectedPaymentMethod === 'cash'}
                    onChange={() => handlePaymentMethodChange('cash')}
                    className="h-4 w-4 border-gray-300"
                  />
                  <Label htmlFor="cash">Cash</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="card"
                    name="paymentMethod"
                    value="card"
                    checked={selectedPaymentMethod === 'card'}
                    onChange={() => handlePaymentMethodChange('card')}
                    className="h-4 w-4 border-gray-300"
                  />
                  <Label htmlFor="card">Credit/Debit Card</Label>
                </div>
                
                {selectedPaymentMethod === 'card' && (
                  <div className="mt-4 space-y-4 pl-6">
                    {/* This is where Stripe components would go in a real implementation */}
                    <div className="space-y-2">
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input id="cardNumber" placeholder="4242 4242 4242 4242" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="expiry">Expiry Date</Label>
                        <Input id="expiry" placeholder="MM/YY" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cvc">CVC</Label>
                        <Input id="cvc" placeholder="123" />
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="saveCard" 
                        checked={savePaymentInfo} 
                        onCheckedChange={(checked) => setSavePaymentInfo(checked === true)} 
                      />
                      <Label htmlFor="saveCard">Save payment info for future visits</Label>
                    </div>
                  </div>
                )}
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <div className="font-medium">Order Summary</div>
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${grandTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>${grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            <DialogFooter className="sm:justify-end">
              <Button
                variant="outline"
                onClick={() => setIsPaymentDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleCompleteCheckout}
                disabled={checkoutMutation.isPending}
              >
                {checkoutMutation.isPending ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full mr-2"></div>
                    Processing...
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Complete Payment
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        {/* Convert to Member Dialog */}
        <Dialog open={isMembershipDialogOpen} onOpenChange={setIsMembershipDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Convert to Member</DialogTitle>
              <DialogDescription>
                Create a membership account for this customer.
              </DialogDescription>
            </DialogHeader>
            
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (tableCustomers.length > 0) {
                  // Get the walk-in customer
                  const walkInCustomer = tableCustomers.find((c: any) => c.isWalkIn);
                  if (walkInCustomer) {
                    handleConvertToMember(walkInCustomer.id, new FormData(e.target as HTMLFormElement));
                  }
                }
              }}
            >
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="customerName">Customer Name</Label>
                  <Input
                    id="customerName"
                    name="customerName"
                    defaultValue={tableCustomers.find((c: any) => c.isWalkIn)?.customerName || ''}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Membership Tier</Label>
                  <div className="grid gap-2">
                    {membershipTiers.map((tier: MembershipTier) => (
                      <div key={tier.id} className="flex items-center space-x-2 border rounded-md p-3">
                        <input
                          type="radio"
                          id={`tier-${tier.id}`}
                          name="membershipTier"
                          value={tier.id}
                          checked={selectedMembershipTier === tier.id}
                          onChange={() => handleMembershipTierChange(tier.id)}
                          className="h-4 w-4 border-gray-300"
                        />
                        <div className="flex-1">
                          <Label htmlFor={`tier-${tier.id}`} className="font-medium">{tier.name}</Label>
                          <p className="text-sm text-muted-foreground">{tier.description}</p>
                          <p className="text-sm mt-1">${Number(tier.monthlyPrice).toFixed(2)}/month</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              <DialogFooter className="sm:justify-end">
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setIsMembershipDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={convertToMemberMutation.isPending || !selectedMembershipTier}
                >
                  {convertToMemberMutation.isPending ? (
                    <>
                      <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Create Membership
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </MainLayout>
  );
}