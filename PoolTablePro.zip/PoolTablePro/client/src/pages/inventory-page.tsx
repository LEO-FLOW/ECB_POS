import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { InventoryItem, InventoryCategory, InsertInventoryItem, InsertInventoryCategory } from '@shared/schema';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  Search,
  Plus,
  Edit,
  Trash2,
  Box,
  Coffee,
  Tag,
  Home,
  ChevronLeft
} from 'lucide-react';

export default function InventoryPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<InventoryCategory | null>(null);
  const { toast } = useToast();

  // Item form state
  const [itemName, setItemName] = useState('');
  const [itemCategoryId, setItemCategoryId] = useState<number | ''>('');
  const [itemPrice, setItemPrice] = useState('');
  const [itemCost, setItemCost] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [itemSku, setItemSku] = useState('');
  const [itemBarcode, setItemBarcode] = useState('');
  const [itemCurrentStock, setItemCurrentStock] = useState('0');
  const [itemMinStockLevel, setItemMinStockLevel] = useState('0');
  const [itemIsActive, setItemIsActive] = useState(true);

  // Category form state
  const [categoryName, setCategoryName] = useState('');
  const [categoryDescription, setCategoryDescription] = useState('');

  // Fetch inventory items and categories
  const { data: items = [], isLoading: isLoadingItems } = useQuery<any[]>({
    queryKey: ['/api/inventory/items'],
    queryFn: async () => {
      const response = await fetch('/api/inventory/items');
      const data = await response.json();
      console.log('[INVENTORY-PAGE] Fetched items:', data);
      return data;
    },
  });

  const { data: categories = [], isLoading: isLoadingCategories } = useQuery<any[]>({
    queryKey: ['/api/inventory/categories'],
    queryFn: async () => {
      const response = await fetch('/api/inventory/categories');
      const data = await response.json();
      console.log('[INVENTORY-PAGE] Fetched categories:', data);
      return data;
    },
    // Force refetch anytime we return to inventory page to prevent stale data
    refetchOnWindowFocus: true,
    staleTime: 0,
  });

  // Create/Update item mutation
  const itemMutation = useMutation({
    mutationFn: async (data: { item: Partial<InsertInventoryItem>, id?: number }) => {
      if (data.id) {
        // Update existing item
        const response = await apiRequest('PATCH', `/api/inventory/items/${data.id}`, data.item);
        return response.json();
      } else {
        // Create new item
        const response = await apiRequest('POST', '/api/inventory/items', data.item);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/items'] });
      setIsItemModalOpen(false);
      resetItemForm();
      toast({
        title: selectedItem ? "Item Updated" : "Item Created",
        description: `${itemName} has been ${selectedItem ? "updated" : "added"} to inventory.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `Failed to ${selectedItem ? "update" : "create"} item: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Create/Update category mutation
  const categoryMutation = useMutation({
    mutationFn: async (data: { category: Partial<InsertInventoryCategory>, id?: number }) => {
      if (data.id) {
        // Update existing category
        const response = await apiRequest('PATCH', `/api/inventory/categories/${data.id}`, data.category);
        return response.json();
      } else {
        // Create new category
        const response = await apiRequest('POST', '/api/inventory/categories', data.category);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/categories'] });
      setIsCategoryModalOpen(false);
      resetCategoryForm();
      toast({
        title: selectedCategory ? "Category Updated" : "Category Created",
        description: `${categoryName} has been ${selectedCategory ? "updated" : "added"}.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `Failed to ${selectedCategory ? "update" : "create"} category: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Delete item mutation
  const deleteItemMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/inventory/items/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/items'] });
      toast({
        title: "Item Deleted",
        description: "The item has been removed from inventory.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `Failed to delete item: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Delete category mutation
  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/inventory/categories/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/categories'] });
      toast({
        title: "Category Deleted",
        description: "The category has been removed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `Failed to delete category: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Form handlers
  const handleItemSubmit = () => {
    if (!itemName || !itemCategoryId || !itemPrice || !itemCost) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const item: Partial<InsertInventoryItem> = {
      name: itemName,
      categoryId: Number(itemCategoryId),
      price: itemPrice,
      cost: itemCost,
      description: itemDescription || null,
      sku: itemSku || null,
      barcode: itemBarcode || null,
      currentStock: Number(itemCurrentStock),
      minStockLevel: Number(itemMinStockLevel),
      isActive: itemIsActive,
    };

    itemMutation.mutate({
      item,
      id: selectedItem?.id,
    });
  };

  const handleCategorySubmit = () => {
    if (!categoryName) {
      toast({
        title: "Missing Information",
        description: "Please enter a category name.",
        variant: "destructive",
      });
      return;
    }

    const category: Partial<InsertInventoryCategory> = {
      name: categoryName,
      description: categoryDescription || null,
    };

    categoryMutation.mutate({
      category,
      id: selectedCategory?.id,
    });
  };

  const handleEditItem = (item: InventoryItem) => {
    console.log('[INVENTORY-PAGE] Editing item:', item);
    
    if (!item.categoryId) {
      console.log('[INVENTORY-PAGE] Invalid category ID:', item.categoryId);
    }
    
    setSelectedItem(item);
    setItemName(item.name);
    setItemCategoryId(item.categoryId || 1); // Default to category 1 if missing
    
    // Handle price and cost safely
    try {
      setItemPrice(item.price ? (typeof item.price === 'string' ? item.price : item.price.toString()) : '0');
      setItemCost(item.cost ? (typeof item.cost === 'string' ? item.cost : item.cost.toString()) : '0');
    } catch (error) {
      console.error('[INVENTORY-PAGE] Error parsing price/cost:', error);
      setItemPrice('0');
      setItemCost('0');
    }
    
    setItemDescription(item.description || '');
    setItemSku(item.sku || '');
    setItemBarcode(item.barcode || '');
    setItemCurrentStock(item.currentStock?.toString() || '0');
    setItemMinStockLevel(item.minStockLevel?.toString() || '0');
    setItemIsActive(item.isActive ?? true); // Use nullish coalescing
    setIsItemModalOpen(true);
  };

  const handleEditCategory = (category: InventoryCategory) => {
    setSelectedCategory(category);
    setCategoryName(category.name);
    setCategoryDescription(category.description || '');
    setIsCategoryModalOpen(true);
  };

  const resetItemForm = () => {
    setSelectedItem(null);
    setItemName('');
    setItemCategoryId('');
    setItemPrice('');
    setItemCost('');
    setItemDescription('');
    setItemSku('');
    setItemBarcode('');
    setItemCurrentStock('0');
    setItemMinStockLevel('0');
    setItemIsActive(true);
  };

  const resetCategoryForm = () => {
    setSelectedCategory(null);
    setCategoryName('');
    setCategoryDescription('');
  };

  // Filter items by search term
  const filteredItems = items.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (item.description && item.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (item.sku && item.sku.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Get category name by ID
  const getCategoryName = (categoryId: number) => {
    // Check if the item has a direct categoryName property (from the API)
    // This is how we fixed the first issue, by leveraging the categoryName property
    const foundItem = items.find(item => item.id === selectedItem?.id);
    if (foundItem && foundItem.categoryName) {
      return foundItem.categoryName;
    }
    
    // Make sure categoryId is a number
    const catId = Number(categoryId);
    if (isNaN(catId)) {
      console.log(`[INVENTORY-PAGE] Invalid category ID: ${categoryId}`);
      return 'Unknown';
    }
    
    // If categories aren't loaded yet
    if (!categories || categories.length === 0) {
      console.log(`[INVENTORY-PAGE] No categories available yet`);
      return 'Loading...';
    }
    
    // Create a simple mapping of category IDs to names for quick lookup
    const categoryMap: Record<number, string> = {};
    categories.forEach(c => {
      categoryMap[Number(c.id)] = c.name;
    });
    
    // Look up the category in our map
    if (categoryMap[catId]) {
      return categoryMap[catId];
    }
    
    // If all else fails, try to find the category directly
    const category = categories.find(c => Number(c.id) === catId);
    if (category) {
      return category.name;
    }
    
    // Log the issue and return Unknown as a last resort
    console.log(`[INVENTORY-PAGE] Could not find category ${catId}. Available categories:`, categories);
    return 'Unknown';
  };

  return (
    <div className="container mx-auto py-6">
      <div className="mb-4">
        <Link href="/">
          <Button variant="outline" className="flex items-center gap-1">
            <ChevronLeft className="h-4 w-4" />
            <Home className="h-4 w-4 mr-1" />
            Back to Dashboard
          </Button>
        </Link>
      </div>
      
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Inventory Management</h1>
        <div className="flex space-x-2">
          <Button onClick={() => setIsCategoryModalOpen(true)}>
            <Tag className="mr-2 h-4 w-4" />
            Add Category
          </Button>
          <Button onClick={() => { resetItemForm(); setIsItemModalOpen(true); }}>
            <Plus className="mr-2 h-4 w-4" />
            Add Item
          </Button>
        </div>
      </div>

      <Tabs defaultValue="items">
        <TabsList className="mb-4">
          <TabsTrigger value="items">
            <Box className="mr-2 h-4 w-4" />
            Inventory Items
          </TabsTrigger>
          <TabsTrigger value="categories">
            <Tag className="mr-2 h-4 w-4" />
            Categories
          </TabsTrigger>
        </TabsList>

        <TabsContent value="items">
          <div className="bg-card rounded-md shadow-sm p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">All Items</h2>
              <div className="relative w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search items..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>

            {isLoadingItems ? (
              <div className="text-center py-8">Loading inventory items...</div>
            ) : filteredItems.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No items found. Add some inventory items to get started.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Cost</TableHead>
                    <TableHead>Stock</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{getCategoryName(item.categoryId)}</TableCell>
                      <TableCell>${parseFloat(item.price).toFixed(2)}</TableCell>
                      <TableCell>${parseFloat(item.cost).toFixed(2)}</TableCell>
                      <TableCell>
                        {item.currentStock !== null && item.minStockLevel !== null && item.currentStock <= item.minStockLevel ? (
                          <Badge variant="destructive">{item.currentStock} (Low)</Badge>
                        ) : (
                          item.currentStock
                        )}
                      </TableCell>
                      <TableCell>
                        {item.isActive ? (
                          <Badge className="bg-green-500 hover:bg-green-600">Active</Badge>
                        ) : (
                          <Badge variant="secondary">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEditItem(item)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (confirm(`Are you sure you want to delete ${item.name}?`)) {
                              deleteItemMutation.mutate(item.id);
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>

        <TabsContent value="categories">
          <div className="bg-card rounded-md shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Categories</h2>

            {isLoadingCategories ? (
              <div className="text-center py-8">Loading categories...</div>
            ) : categories.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No categories found. Add some categories to organize your inventory.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Items Count</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {categories.map((category) => (
                    <TableRow key={category.id}>
                      <TableCell className="font-medium">{category.name}</TableCell>
                      <TableCell>{category.description || '-'}</TableCell>
                      <TableCell>
                        {items.filter(item => item.categoryId === category.id).length}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEditCategory(category)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            // Check if category has items
                            const hasItems = items.some(item => item.categoryId === category.id);
                            if (hasItems) {
                              toast({
                                title: "Cannot Delete",
                                description: "This category has items associated with it. Remove the items first.",
                                variant: "destructive",
                              });
                              return;
                            }

                            if (confirm(`Are you sure you want to delete ${category.name}?`)) {
                              deleteCategoryMutation.mutate(category.id);
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Add/Edit Item Dialog */}
      <Dialog open={isItemModalOpen} onOpenChange={setIsItemModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{selectedItem ? "Edit Item" : "Add New Item"}</DialogTitle>
            <DialogDescription>
              {selectedItem 
                ? "Update the item details in your inventory."
                : "Add a new item to your inventory."}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name" className="required">Name</Label>
              <Input
                id="name"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                placeholder="e.g. Pool Cue Chalk"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="category" className="required">Category</Label>
              <Select
                value={itemCategoryId ? itemCategoryId.toString() : '1'} 
                onValueChange={(value) => setItemCategoryId(parseInt(value))}
                defaultValue="1"
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id.toString()}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="price" className="required">Price ($)</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                value={itemPrice}
                onChange={(e) => setItemPrice(e.target.value)}
                placeholder="5.99"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="cost" className="required">Cost ($)</Label>
              <Input
                id="cost"
                type="number"
                step="0.01"
                value={itemCost}
                onChange={(e) => setItemCost(e.target.value)}
                placeholder="3.50"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="sku">SKU</Label>
              <Input
                id="sku"
                value={itemSku}
                onChange={(e) => setItemSku(e.target.value)}
                placeholder="ABC123"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="barcode">Barcode</Label>
              <Input
                id="barcode"
                value={itemBarcode}
                onChange={(e) => setItemBarcode(e.target.value)}
                placeholder="123456789012"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="currentStock">Current Stock</Label>
              <Input
                id="currentStock"
                type="number"
                value={itemCurrentStock}
                onChange={(e) => setItemCurrentStock(e.target.value)}
                placeholder="10"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="minStockLevel">Min Stock Level</Label>
              <Input
                id="minStockLevel"
                type="number"
                value={itemMinStockLevel}
                onChange={(e) => setItemMinStockLevel(e.target.value)}
                placeholder="5"
              />
            </div>

            <div className="col-span-2 grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                value={itemDescription}
                onChange={(e) => setItemDescription(e.target.value)}
                placeholder="Description of the item"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="isActive"
                checked={itemIsActive}
                onCheckedChange={(checked) => setItemIsActive(checked as boolean)}
              />
              <Label htmlFor="isActive">Active</Label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsItemModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleItemSubmit} disabled={itemMutation.isPending}>
              {itemMutation.isPending ? "Saving..." : (selectedItem ? "Save Changes" : "Add Item")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Category Dialog */}
      <Dialog open={isCategoryModalOpen} onOpenChange={setIsCategoryModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedCategory ? "Edit Category" : "Add New Category"}</DialogTitle>
            <DialogDescription>
              {selectedCategory 
                ? "Update the category details for your inventory."
                : "Add a new category to organize your inventory."}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="categoryName" className="required">Name</Label>
              <Input
                id="categoryName"
                value={categoryName}
                onChange={(e) => setCategoryName(e.target.value)}
                placeholder="e.g. Food, Drinks, Equipment"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="categoryDescription">Description</Label>
              <Input
                id="categoryDescription"
                value={categoryDescription}
                onChange={(e) => setCategoryDescription(e.target.value)}
                placeholder="Description of the category"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCategoryModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCategorySubmit} disabled={categoryMutation.isPending}>
              {categoryMutation.isPending ? "Saving..." : (selectedCategory ? "Save Changes" : "Add Category")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}