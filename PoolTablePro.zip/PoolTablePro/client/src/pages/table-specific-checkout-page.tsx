import { useState, useEffect } from "react";
import { Link, useRoute, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ChevronLeft, Home, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function TableSpecificCheckoutPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [paymentMethod, setPaymentMethod] = useState<string>("cash");
  const [paymentAmount, setPaymentAmount] = useState<string>("0.00");
  const [customerId, setCustomerId] = useState<string>("none");
  
  // Get tableUsageId from URL params
  const [match, params] = useRoute<{ tableUsageId: string }>('/tables/:tableUsageId/checkout');
  const tableUsageId = params?.tableUsageId;
  
  // Fetch all tables to display names
  const { data: tables = [] } = useQuery({
    queryKey: ["/api/tables"],
    queryFn: async () => {
      const response = await fetch("/api/tables");
      const data = await response.json();
      console.log("[TABLE-CHECKOUT] Tables data:", data);
      return data;
    },
  });

  // Fetch all available payment methods
  const { data: paymentMethods = [] } = useQuery({
    queryKey: ["/api/payment-methods"],
    queryFn: async () => {
      const response = await fetch("/api/payment-methods");
      return response.json();
    },
  });

  // Get specific table usage details
  const { data: tableUsage, isLoading: isLoadingTableUsage, error: tableUsageError } = useQuery({
    queryKey: ["/api/table-usage", tableUsageId],
    queryFn: async () => {
      if (!tableUsageId) return null;
      
      try {
        console.log("[TABLE-CHECKOUT] Fetching table usage with ID:", tableUsageId);
        const response = await fetch(`/api/table-usage/${tableUsageId}`);
        console.log("[TABLE-CHECKOUT] Table usage response status:", response.status);
        
        if (!response.ok) {
          if (response.status === 404) {
            return null; // Handle 404 gracefully
          }
          throw new Error("Failed to fetch table usage data");
        }
        
        const data = await response.json();
        console.log("[TABLE-CHECKOUT] Table usage data:", data);
        return data;
      } catch (error) {
        console.error("[TABLE-CHECKOUT] Error fetching table usage:", error);
        throw error;
      }
    },
    enabled: !!tableUsageId,
  });

  // Get orders for the table usage
  const { data: orders = [] } = useQuery({
    queryKey: ["/api/pos/orders/table", tableUsageId],
    queryFn: async () => {
      if (!tableUsageId) return [];
      
      console.log("[TABLE-CHECKOUT] Fetching orders for table usage ID:", tableUsageId);
      const response = await fetch(`/api/pos/orders/table/${tableUsageId}`);
      console.log("[TABLE-CHECKOUT] Orders API response status:", response.status);
      
      if (!response.ok) {
        if (response.status === 404) {
          return []; // Handle 404 gracefully
        }
        throw new Error("Failed to fetch orders");
      }
      
      const data = await response.json();
      console.log("[TABLE-CHECKOUT] Fetched", data.length, "orders with items:", data);
      
      // Log each order and its items for debugging
      data.forEach((order: any, idx: number) => {
        console.log(`[TABLE-CHECKOUT] Order ${idx}, ID: ${order.id}, Items count: ${order.items?.length || 0}`);
        if (order.items) {
          order.items.forEach((item: any, itemIdx: number) => {
            console.log(`[TABLE-CHECKOUT] Item ${itemIdx} in order ${idx}: ID=${item.id}, inventoryItemId=${item.inventoryItemId}, name=${item.name}, price=${item.price}`);
          });
        }
      });
      
      return data;
    },
    enabled: !!tableUsageId,
  });

  // Get customers for the table usage
  const { data: customers = [] } = useQuery({
    queryKey: ["/api/table-session-customers", tableUsageId],
    queryFn: async () => {
      if (!tableUsageId) return [];
      
      console.log("[TABLE-CHECKOUT] Fetching customers for table usage ID:", tableUsageId);
      const response = await fetch(`/api/table-session-customers?tableUsageId=${tableUsageId}`);
      console.log("[TABLE-CHECKOUT] Customers API response status:", response.status);
      
      if (!response.ok) {
        if (response.status === 404) {
          return []; // Handle 404 gracefully
        }
        throw new Error("Failed to fetch customers");
      }
      
      const data = await response.json();
      console.log("[TABLE-CHECKOUT] Table session customers:", data);
      return data;
    },
    enabled: !!tableUsageId,
  });
  
  // Find the table name
  const getTableName = (tableId: number) => {
    const table = tables.find((t: any) => t.id === tableId);
    return table ? table.name : `Table ${tableId}`;
  };

  // Calculate time spent and cost
  const calculateTimeUsage = (startTime: string) => {
    if (!startTime) return { hours: 0, minutes: 0, seconds: 0 };
    
    const start = new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);
    
    return { hours, minutes, seconds };
  };

  // Calculate hourly rate cost
  const calculateHourlyCharge = (startTime: string, hourlyRate: number) => {
    if (!startTime || !hourlyRate) return 0;
    
    const start = new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    
    // Convert to hours (including fractions)
    const hours = diffMs / (1000 * 60 * 60);
    
    // Calculate the cost and round to 2 decimal places
    return Math.round(hours * hourlyRate * 100) / 100;
  };

  // Calculate order total
  const calculateOrderTotal = () => {
    return orders.reduce((total: number, order: any) => {
      return total + parseFloat(order.totalAmount || 0);
    }, 0);
  };

  // Get hourly rate for the table
  const getHourlyRate = (tableId: number) => {
    const table = tables.find((t: any) => t.id === tableId);
    return table ? parseFloat(table.hourlyRate || 10) : 10; // Default to $10/hr
  };

  // Calculate the grand total
  const calculateGrandTotal = () => {
    if (!tableUsage) return 0;
    
    const hourlyRate = getHourlyRate(tableUsage.tableId);
    const timeCharge = calculateHourlyCharge(tableUsage.startTime, hourlyRate);
    const orderTotal = calculateOrderTotal();
    
    return timeCharge + orderTotal;
  };

  // Checkout mutation
  const checkoutMutation = useMutation({
    mutationFn: async () => {
      if (!tableUsageId || !tableUsage) {
        throw new Error("No table usage selected");
      }

      console.log("[TABLE-CHECKOUT] Starting checkout process for table usage ID:", tableUsageId);
      console.log("[TABLE-CHECKOUT] Payment method:", paymentMethod);
      console.log("[TABLE-CHECKOUT] Payment amount:", paymentAmount);
      
      // Get the hourly rate from the table
      const tableId = tableUsage.tableId;
      const hourlyRate = getHourlyRate(tableId);
      
      // Calculate the time charge
      const timeCharge = calculateHourlyCharge(tableUsage.startTime, hourlyRate);
      
      // Calculate the order total
      const orderTotal = calculateOrderTotal();
      
      // Calculate the grand total
      const grandTotal = calculateGrandTotal();
      
      // Only send the payment amount if it's different from calculated total
      const paymentAmountValue = parseFloat(paymentAmount);
      const actualPaymentAmount = isNaN(paymentAmountValue) || paymentAmountValue === 0 
        ? grandTotal 
        : paymentAmountValue;
      
      console.log("[TABLE-CHECKOUT] Time charge:", timeCharge);
      console.log("[TABLE-CHECKOUT] Order total:", orderTotal);
      console.log("[TABLE-CHECKOUT] Grand total:", grandTotal);
      console.log("[TABLE-CHECKOUT] Actual payment amount:", actualPaymentAmount);
      
      const requestBody = {
        tableUsageId,
        paymentMethod,
        timeCharge,
        orderTotal,
        totalAmount: grandTotal,
        actualPaymentAmount,
        customerId: customerId && customerId !== "none" ? parseInt(customerId) : undefined
      };

      console.log("[TABLE-CHECKOUT] Checkout request body:", requestBody);
      
      const response = await apiRequest("POST", "/api/checkout", requestBody);
      console.log("[TABLE-CHECKOUT] Checkout response status:", response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error("[TABLE-CHECKOUT] Checkout error:", errorData);
        throw new Error(errorData.message || "Checkout failed");
      }
      
      const data = await response.json();
      console.log("[TABLE-CHECKOUT] Checkout successful, response:", data);
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Checkout Successful",
        description: "The table has been checked out successfully.",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/table-usage/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      
      // Redirect to the tables page
      setLocation('/tables');
    },
    onError: (error: Error) => {
      console.error("[TABLE-CHECKOUT] Checkout error:", error);
      toast({
        title: "Checkout Failed",
        description: error.message || "An error occurred during checkout.",
        variant: "destructive",
      });
    },
  });

  // Set initial payment amount when grand total changes
  useEffect(() => {
    const grandTotal = calculateGrandTotal();
    setPaymentAmount(grandTotal.toFixed(2));
  }, [tableUsageId, orders]);

  // Format a date string as MM/DD/YYYY, HH:MM AM/PM
  const formatDateTime = (dateString: string) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      return format(date, 'MM/dd/yyyy, h:mm a');
    } catch (e) {
      return 'Invalid Date';
    }
  };

  // Check if the table session was found
  const tableSessionNotFound = !isLoadingTableUsage && !tableUsage;

  return (
    <div className="container mx-auto py-6">
      <div className="mb-4">
        <Link href="/tables">
          <Button variant="outline" className="flex items-center gap-1">
            <ChevronLeft className="h-4 w-4" />
            Back to Tables
          </Button>
        </Link>
      </div>
      
      <h1 className="text-3xl font-bold mb-6">Checkout</h1>
      
      {tableSessionNotFound ? (
        <Card className="mb-6 bg-red-50 border-red-200">
          <CardContent className="pt-6">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Table session not found</AlertTitle>
              <AlertDescription>
                The requested table session does not exist or has already been checked out.
              </AlertDescription>
            </Alert>
            <div className="mt-6 text-center">
              <Button onClick={() => setLocation('/tables')}>
                Return to Tables
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : isLoadingTableUsage ? (
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex justify-center p-6">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
            <p className="text-center text-muted-foreground">Loading table session...</p>
          </CardContent>
        </Card>
      ) : tableUsage ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Table Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">Table Name:</span>
                    <span>{getTableName(tableUsage.tableId)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Started:</span>
                    <span>{formatDateTime(tableUsage.startTime)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Status:</span>
                    <span className="capitalize">{tableUsage.status}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Customers:</span>
                    <span>{tableUsage.customerCount || customers.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Session ID:</span>
                    <span className="text-xs">{tableUsage.sessionId}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Time Usage</CardTitle>
              </CardHeader>
              <CardContent>
                {tableUsage.startTime && (
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Time Spent:</span>
                      <span>
                        {(() => {
                          const { hours, minutes, seconds } = calculateTimeUsage(tableUsage.startTime);
                          return `${hours}h ${minutes}m ${seconds}s`;
                        })()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Hourly Rate:</span>
                      <span>${getHourlyRate(tableUsage.tableId).toFixed(2)}/hr</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Time Charge:</span>
                      <span>
                        ${calculateHourlyCharge(
                          tableUsage.startTime,
                          getHourlyRate(tableUsage.tableId)
                        ).toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Payment Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">Time Charge:</span>
                    <span>
                      ${calculateHourlyCharge(
                        tableUsage.startTime,
                        getHourlyRate(tableUsage.tableId)
                      ).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Food & Drinks:</span>
                    <span>${calculateOrderTotal().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Total Due:</span>
                    <span>${calculateGrandTotal().toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Customers</CardTitle>
              </CardHeader>
              <CardContent>
                {customers.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No customers found for this session</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Added</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {customers.map((customer: any) => (
                        <TableRow key={customer.id}>
                          <TableCell className="font-medium">{customer.customerName || 'Walk-in Customer'}</TableCell>
                          <TableCell>{customer.isWalkIn ? 'Walk-in' : customer.userId ? 'Member' : 'Guest'}</TableCell>
                          <TableCell>{formatDateTime(customer.addedAt)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Order Items</CardTitle>
              </CardHeader>
              <CardContent>
                {orders.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No orders found for this session</p>
                ) : (
                  <Tabs defaultValue="summary">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="summary">Summary</TabsTrigger>
                      <TabsTrigger value="details">Details</TabsTrigger>
                    </TabsList>
                    <TabsContent value="summary">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Order #</TableHead>
                            <TableHead>Items</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {orders.map((order: any) => (
                            <TableRow key={order.id}>
                              <TableCell className="font-medium">{order.orderNumber || `#${order.id}`}</TableCell>
                              <TableCell>{order.items?.length || 0} items</TableCell>
                              <TableCell className="text-right">${Number(order.totalAmount).toFixed(2)}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TabsContent>
                    <TabsContent value="details">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Item</TableHead>
                            <TableHead>Qty</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {orders.flatMap((order: any) =>
                            order.items?.map((item: any) => (
                              <TableRow key={`${order.id}-${item.id}`}>
                                <TableCell className="font-medium">{item.name}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>${Number(item.unitPrice).toFixed(2)}</TableCell>
                                <TableCell className="text-right">${Number(item.totalPrice).toFixed(2)}</TableCell>
                              </TableRow>
                            )) || []
                          )}
                        </TableBody>
                      </Table>
                    </TabsContent>
                  </Tabs>
                )}
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Checkout</CardTitle>
              <CardDescription>
                Complete the checkout process for this table
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="paymentMethod">Payment Method</Label>
                  <Select
                    value={paymentMethod}
                    onValueChange={setPaymentMethod}
                  >
                    <SelectTrigger id="paymentMethod">
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      {paymentMethods.length === 0 ? (
                        <>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="credit">Credit Card</SelectItem>
                          <SelectItem value="venmo">Venmo</SelectItem>
                        </>
                      ) : (
                        paymentMethods.map((method: any) => (
                          <SelectItem key={method.id} value={method.code}>
                            {method.name}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="paymentAmount">Payment Amount</Label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">$</span>
                    <Input
                      id="paymentAmount"
                      type="number"
                      min="0"
                      step="0.01"
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(e.target.value)}
                      className="pl-7"
                    />
                  </div>
                </div>
                
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="customerId">Member ID (for Membership)</Label>
                  <Select
                    value={customerId}
                    onValueChange={setCustomerId}
                  >
                    <SelectTrigger id="customerId">
                      <SelectValue placeholder="Select member" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Member (Walk-in Checkout)</SelectItem>
                      {/* We would add member options here if available */}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <div className="w-full rounded-md bg-gray-50 p-4">
                <div className="flex justify-between font-bold text-lg">
                  <span>Total Due:</span>
                  <span>${calculateGrandTotal().toFixed(2)}</span>
                </div>
              </div>
              <Button
                className="w-full"
                size="lg"
                onClick={() => checkoutMutation.mutate()}
                disabled={checkoutMutation.isPending}
              >
                {checkoutMutation.isPending ? (
                  <div className="flex items-center">
                    <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                    Processing...
                  </div>
                ) : (
                  `Complete Checkout - $${calculateGrandTotal().toFixed(2)}`
                )}
              </Button>
            </CardFooter>
          </Card>
        </>
      ) : null}
    </div>
  );
}