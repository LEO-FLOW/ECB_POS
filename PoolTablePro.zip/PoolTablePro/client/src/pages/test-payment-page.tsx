import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import StripeCheckout from '@/components/pos/checkout';

export default function TestPaymentPage() {
  const [amount, setAmount] = useState('25.99');
  const [description, setDescription] = useState('Test payment');
  const [showCheckout, setShowCheckout] = useState(false);
  const { toast } = useToast();

  const handlePaymentSuccess = () => {
    toast({
      title: 'Payment Complete',
      description: 'Your test payment was processed successfully!',
    });
    setShowCheckout(false);
  };

  const handleCancel = () => {
    setShowCheckout(false);
  };

  if (showCheckout) {
    return (
      <div className="container max-w-4xl mx-auto py-10">
        <StripeCheckout
          orderData={{
            amount: Number(amount),
            description: description,
          }}
          orderDetails={{
            subtotal: amount,
            total: amount,
            orderItems: [
              {
                name: 'Test Item',
                quantity: 1,
                price: amount,
              },
            ],
          }}
          onSuccess={handlePaymentSuccess}
          onCancel={handleCancel}
        />
      </div>
    );
  }

  return (
    <div className="container max-w-xl mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Test Payment</CardTitle>
          <CardDescription>
            Test the payment integration with various amounts and descriptions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                placeholder="Enter description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
            <Button
              className="w-full"
              onClick={() => setShowCheckout(true)}
            >
              Proceed to Checkout
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}