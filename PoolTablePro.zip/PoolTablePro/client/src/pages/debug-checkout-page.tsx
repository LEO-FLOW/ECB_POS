import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ChevronLeft, Home } from "lucide-react";
import { format } from "date-fns";

export default function DebugCheckoutPage() {
  const { toast } = useToast();
  const [selectedTableUsageId, setSelectedTableUsageId] = useState<string>("");
  const [paymentMethod, setPaymentMethod] = useState<string>("cash");
  const [paymentAmount, setPaymentAmount] = useState<string>("0.00");
  const [customerId, setCustomerId] = useState<string>("none");
  
  // Fetch all active table usages
  const { data: tableUsages = [] } = useQuery({
    queryKey: ["/api/table-usage/active"],
    queryFn: async () => {
      console.log("[DEBUG-CHECKOUT] Fetching active table usages");
      const response = await fetch("/api/table-usage/active");
      console.log("[DEBUG-CHECKOUT] Table usages response status:", response.status);
      const data = await response.json();
      console.log("[DEBUG-CHECKOUT] Active table usages:", data);
      return data;
    },
  });

  // Fetch all tables to display names
  const { data: tables = [] } = useQuery({
    queryKey: ["/api/tables"],
    queryFn: async () => {
      const response = await fetch("/api/tables");
      const data = await response.json();
      console.log("[DEBUG-CHECKOUT] Tables data:", data);
      return data;
    },
  });

  // Fetch all available payment methods
  const { data: paymentMethods = [] } = useQuery({
    queryKey: ["/api/payment-methods"],
    queryFn: async () => {
      const response = await fetch("/api/payment-methods");
      return response.json();
    },
  });

  // Get orders for the selected table usage
  const { data: orders = [], refetch: refetchOrders } = useQuery({
    queryKey: ["/api/pos/orders/table", selectedTableUsageId],
    queryFn: async () => {
      if (!selectedTableUsageId) return [];
      console.log("[DEBUG-CHECKOUT] Fetching orders for table usage ID:", selectedTableUsageId);
      const response = await fetch(`/api/pos/orders/table/${selectedTableUsageId}`);
      console.log("[DEBUG-CHECKOUT] Orders API response status:", response.status);
      const data = await response.json();
      console.log("[DEBUG-CHECKOUT] Fetched", data.length, "orders with items:", data);
      
      // Log each order and its items for debugging
      data.forEach((order: any, idx: number) => {
        console.log(`[DEBUG-CHECKOUT] Order ${idx}, ID: ${order.id}, Items count: ${order.items?.length || 0}`);
        if (order.items) {
          order.items.forEach((item: any, itemIdx: number) => {
            console.log(`[DEBUG-CHECKOUT] Item ${itemIdx} in order ${idx}: ID=${item.id}, inventoryItemId=${item.inventoryItemId}, name=${item.name}, price=${item.price}`);
          });
        }
      });
      
      return data;
    },
    enabled: !!selectedTableUsageId,
  });

  // Get customers for the selected table usage
  const { data: customers = [] } = useQuery({
    queryKey: ["/api/table-session-customers", selectedTableUsageId],
    queryFn: async () => {
      if (!selectedTableUsageId) return [];
      console.log("[DEBUG-CHECKOUT] Fetching customers for table usage ID:", selectedTableUsageId);
      const response = await fetch(`/api/table-session-customers/${selectedTableUsageId}`);
      console.log("[DEBUG-CHECKOUT] Customers API response status:", response.status);
      const data = await response.json();
      console.log("[DEBUG-CHECKOUT] Table session customers:", data);
      return data;
    },
    enabled: !!selectedTableUsageId,
  });

  // Find the selected table usage
  const selectedTableUsage = tableUsages.find((usage: any) => usage.id.toString() === selectedTableUsageId);
  
  // Find the table name
  const getTableName = (tableId: number) => {
    const table = tables.find((t: any) => t.id === tableId);
    return table ? table.name : `Table ${tableId}`;
  };

  // Calculate time spent and cost
  const calculateTimeUsage = (startTime: string) => {
    if (!startTime) return { hours: 0, minutes: 0, seconds: 0 };
    
    const start = new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);
    
    return { hours, minutes, seconds };
  };

  // Calculate hourly rate cost
  const calculateHourlyCharge = (startTime: string, hourlyRate: number) => {
    if (!startTime || !hourlyRate) return 0;
    
    const start = new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    
    // Convert to hours (including fractions)
    const hours = diffMs / (1000 * 60 * 60);
    
    // Calculate the cost and round to 2 decimal places
    return Math.round(hours * hourlyRate * 100) / 100;
  };

  // Calculate order total
  const calculateOrderTotal = () => {
    return orders.reduce((total, order: any) => {
      return total + parseFloat(order.totalAmount || 0);
    }, 0);
  };

  // Get hourly rate for the table
  const getHourlyRate = (tableId: number) => {
    const table = tables.find((t: any) => t.id === tableId);
    return table ? parseFloat(table.hourlyRate || 10) : 10; // Default to $10/hr
  };

  // Calculate the grand total
  const calculateGrandTotal = () => {
    if (!selectedTableUsage) return 0;
    
    const hourlyRate = getHourlyRate(selectedTableUsage.tableId);
    const timeCharge = calculateHourlyCharge(selectedTableUsage.startTime, hourlyRate);
    const orderTotal = calculateOrderTotal();
    
    return timeCharge + orderTotal;
  };

  // Checkout mutation
  const checkoutMutation = useMutation({
    mutationFn: async () => {
      if (!selectedTableUsageId) {
        throw new Error("No table usage selected");
      }

      console.log("[DEBUG-CHECKOUT] Starting checkout process for table usage ID:", selectedTableUsageId);
      console.log("[DEBUG-CHECKOUT] Payment method:", paymentMethod);
      console.log("[DEBUG-CHECKOUT] Payment amount:", paymentAmount);
      
      // Get the hourly rate from the table
      const tableId = selectedTableUsage?.tableId;
      const hourlyRate = getHourlyRate(tableId);
      
      // Calculate the time charge
      const timeCharge = calculateHourlyCharge(selectedTableUsage?.startTime, hourlyRate);
      
      // Calculate the order total
      const orderTotal = calculateOrderTotal();
      
      // Calculate the grand total
      const grandTotal = calculateGrandTotal();
      
      // Only send the payment amount if it's different from calculated total
      const paymentAmountValue = parseFloat(paymentAmount);
      const actualPaymentAmount = isNaN(paymentAmountValue) || paymentAmountValue === 0 
        ? grandTotal 
        : paymentAmountValue;
      
      console.log("[DEBUG-CHECKOUT] Time charge:", timeCharge);
      console.log("[DEBUG-CHECKOUT] Order total:", orderTotal);
      console.log("[DEBUG-CHECKOUT] Grand total:", grandTotal);
      console.log("[DEBUG-CHECKOUT] Actual payment amount:", actualPaymentAmount);
      
      const requestBody = {
        tableUsageId: selectedTableUsageId,
        paymentMethod,
        timeCharge,
        orderTotal,
        totalAmount: grandTotal,
        actualPaymentAmount,
        customerId: customerId && customerId !== "none" ? parseInt(customerId) : undefined
      };

      console.log("[DEBUG-CHECKOUT] Checkout request body:", requestBody);
      
      const response = await apiRequest("POST", "/api/checkout", requestBody);
      console.log("[DEBUG-CHECKOUT] Checkout response status:", response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error("[DEBUG-CHECKOUT] Checkout error:", errorData);
        throw new Error(errorData.message || "Checkout failed");
      }
      
      const data = await response.json();
      console.log("[DEBUG-CHECKOUT] Checkout successful, response:", data);
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Checkout Successful",
        description: "The table has been checked out successfully.",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/table-usage/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      
      // Reset form
      setSelectedTableUsageId("");
      setPaymentMethod("cash");
      setPaymentAmount("0.00");
    },
    onError: (error: Error) => {
      console.error("[DEBUG-CHECKOUT] Checkout error:", error);
      toast({
        title: "Checkout Failed",
        description: error.message || "An error occurred during checkout.",
        variant: "destructive",
      });
    },
  });

  // Set initial payment amount when grand total changes
  useEffect(() => {
    const grandTotal = calculateGrandTotal();
    setPaymentAmount(grandTotal.toFixed(2));
  }, [selectedTableUsageId, orders]);

  // Format seconds as HH:MM:SS
  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Format a date string as MM/DD/YYYY, HH:MM AM/PM
  const formatDateTime = (dateString: string) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      return format(date, 'MM/dd/yyyy, h:mm a');
    } catch (e) {
      return 'Invalid Date';
    }
  };

  return (
    <div className="container mx-auto py-6">
      <div className="mb-4">
        <Link href="/">
          <Button variant="outline" className="flex items-center gap-1">
            <ChevronLeft className="h-4 w-4" />
            <Home className="h-4 w-4 mr-1" />
            Back to Dashboard
          </Button>
        </Link>
      </div>
      
      <h1 className="text-3xl font-bold mb-6">Debug Checkout</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Select Table Session</CardTitle>
          <CardDescription>
            Choose an active table session to debug checkout functionality
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label htmlFor="tableUsage">Table Session</Label>
              <Select
                value={selectedTableUsageId}
                onValueChange={setSelectedTableUsageId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select table session to checkout" />
                </SelectTrigger>
                <SelectContent>
                  {tableUsages.length === 0 ? (
                    <SelectItem value="none" disabled>
                      No active table sessions
                    </SelectItem>
                  ) : (
                    tableUsages.map((usage: any) => (
                      <SelectItem key={usage.id} value={usage.id.toString()}>
                        {getTableName(usage.tableId)} - {formatDateTime(usage.startTime)} 
                        ({usage.customerCount || 0} customers)
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {selectedTableUsage && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Table Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">Table Name:</span>
                    <span>{getTableName(selectedTableUsage.tableId)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Started:</span>
                    <span>{formatDateTime(selectedTableUsage.startTime)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Status:</span>
                    <span className="capitalize">{selectedTableUsage.status}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Customers:</span>
                    <span>{selectedTableUsage.customerCount || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Session ID:</span>
                    <span className="text-xs">{selectedTableUsage.sessionId}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Time Usage</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedTableUsage.startTime && (
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Time Spent:</span>
                      <span>
                        {(() => {
                          const { hours, minutes, seconds } = calculateTimeUsage(selectedTableUsage.startTime);
                          return `${hours}h ${minutes}m ${seconds}s`;
                        })()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Hourly Rate:</span>
                      <span>${getHourlyRate(selectedTableUsage.tableId).toFixed(2)}/hr</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Time Charge:</span>
                      <span>
                        ${calculateHourlyCharge(
                          selectedTableUsage.startTime,
                          getHourlyRate(selectedTableUsage.tableId)
                        ).toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">Orders:</span>
                    <span>{orders.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Order Items:</span>
                    <span>
                      {orders.reduce((total, order: any) => {
                        return total + (order.items?.length || 0);
                      }, 0)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Order Total:</span>
                    <span>${calculateOrderTotal().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Grand Total:</span>
                    <span>${calculateGrandTotal().toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="orderDetails" className="mb-6">
            <TabsList>
              <TabsTrigger value="orderDetails">Order Details</TabsTrigger>
              <TabsTrigger value="customers">Customers</TabsTrigger>
              <TabsTrigger value="debug">Debug Info</TabsTrigger>
            </TabsList>
            
            <TabsContent value="orderDetails">
              <Card>
                <CardHeader>
                  <CardTitle>Order Details</CardTitle>
                </CardHeader>
                <CardContent>
                  {orders.length === 0 ? (
                    <p>No orders found for this table session.</p>
                  ) : (
                    orders.map((order: any, index: number) => (
                      <div key={order.id} className="mb-6 last:mb-0">
                        <h3 className="text-lg font-semibold mb-2">
                          Order #{order.orderNumber || order.id} ({formatDateTime(order.createdAt)})
                        </h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead className="text-right">Quantity</TableHead>
                              <TableHead className="text-right">Price</TableHead>
                              <TableHead className="text-right">Total</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {order.items && order.items.length > 0 ? (
                              order.items.map((item: any) => (
                                <TableRow key={item.id}>
                                  <TableCell>{item.name}</TableCell>
                                  <TableCell className="text-right">{item.quantity}</TableCell>
                                  <TableCell className="text-right">${parseFloat(item.unitPrice).toFixed(2)}</TableCell>
                                  <TableCell className="text-right">${parseFloat(item.totalPrice).toFixed(2)}</TableCell>
                                </TableRow>
                              ))
                            ) : (
                              <TableRow>
                                <TableCell colSpan={4} className="text-center">No items in this order</TableCell>
                              </TableRow>
                            )}
                            <TableRow className="font-medium">
                              <TableCell colSpan={3} className="text-right">Order Total:</TableCell>
                              <TableCell className="text-right">${parseFloat(order.totalAmount || "0").toFixed(2)}</TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="customers">
              <Card>
                <CardHeader>
                  <CardTitle>Customers</CardTitle>
                </CardHeader>
                <CardContent>
                  {customers.length === 0 ? (
                    <p>No customers assigned to this table session.</p>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Member ID</TableHead>
                          <TableHead>Joined At</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {customers.map((customer: any) => (
                          <TableRow key={customer.id}>
                            <TableCell>{customer.id}</TableCell>
                            <TableCell>{customer.isMember ? "Member" : "Guest"}</TableCell>
                            <TableCell>{customer.name}</TableCell>
                            <TableCell>{customer.userId || "N/A"}</TableCell>
                            <TableCell>{formatDateTime(customer.createdAt)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="debug">
              <Card>
                <CardHeader>
                  <CardTitle>Debug Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <h3 className="text-lg font-semibold mb-2">Table Usage Object</h3>
                    <pre className="bg-muted p-4 rounded-md overflow-auto text-xs">
                      {JSON.stringify(selectedTableUsage, null, 2)}
                    </pre>
                  </div>
                  
                  <div className="mb-4">
                    <h3 className="text-lg font-semibold mb-2">Orders</h3>
                    <pre className="bg-muted p-4 rounded-md overflow-auto text-xs">
                      {JSON.stringify(orders, null, 2)}
                    </pre>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Customers</h3>
                    <pre className="bg-muted p-4 rounded-md overflow-auto text-xs">
                      {JSON.stringify(customers, null, 2)}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          <Card>
            <CardHeader>
              <CardTitle>Checkout</CardTitle>
              <CardDescription>Complete the checkout process</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="paymentMethod">Payment Method</Label>
                  <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      {paymentMethods.length > 0 ? (
                        paymentMethods.map((method: any) => (
                          <SelectItem key={method.id} value={method.code}>
                            {method.name}
                          </SelectItem>
                        ))
                      ) : (
                        <>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="credit_card">Credit Card</SelectItem>
                          <SelectItem value="debit_card">Debit Card</SelectItem>
                          <SelectItem value="gift_card">Gift Card</SelectItem>
                          <SelectItem value="mobile_payment">Mobile Payment</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="paymentAmount">Payment Amount</Label>
                  <Input
                    id="paymentAmount"
                    type="number"
                    step="0.01"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="customer">Primary Customer (Optional)</Label>
                  <Select 
                    value={customerId} 
                    onValueChange={setCustomerId}
                    defaultValue="none"
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Assign to customer" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {customers.map((customer: any) => (
                        <SelectItem 
                          key={customer.id} 
                          value={customer.userId?.toString() || `guest-${customer.id}`}
                        >
                          {customer.name} {customer.userId ? `(Member #${customer.userId})` : "(Guest)"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setSelectedTableUsageId("")}>
                Cancel
              </Button>
              <Button 
                onClick={() => checkoutMutation.mutate()} 
                disabled={checkoutMutation.isPending || !selectedTableUsageId}
              >
                {checkoutMutation.isPending ? "Processing..." : "Complete Checkout"}
              </Button>
            </CardFooter>
          </Card>
        </>
      )}
    </div>
  );
}