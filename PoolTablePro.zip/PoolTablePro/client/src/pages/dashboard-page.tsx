import { MainLayout } from "@/components/layout/main-layout";
import { PoolTableGrid } from "@/components/dashboard/pool-table-grid";
import { StatusSummary } from "@/components/dashboard/status-summary";
import { UpcomingReservations } from "@/components/dashboard/upcoming-reservations";
import { RecentTransactions } from "@/components/dashboard/recent-transactions";
import { MembershipSummary } from "@/components/dashboard/membership-summary";
import { Button } from "@/components/ui/button";
import { PlusIcon, CreditCard, BugIcon } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ReservationForm } from "@/components/reservations/reservation-form";
import { TransactionForm } from "@/components/transactions/transaction-form";
import { format } from "date-fns";

export default function DashboardPage() {
  const [reservationDialogOpen, setReservationDialogOpen] = useState(false);
  const [transactionDialogOpen, setTransactionDialogOpen] = useState(false);
  
  const { data: tables } = useQuery({
    queryKey: ["/api/tables"],
  });
  
  const { data: reservations } = useQuery({
    queryKey: ["/api/reservations/upcoming"],
  });
  
  const { data: transactions } = useQuery({
    queryKey: ["/api/transactions/recent"],
  });
  
  const { data: membershipStats } = useQuery({
    queryKey: ["/api/members/stats"],
  });
  
  const { data: membershipTiers } = useQuery({
    queryKey: ["/api/members/tiers"],
  });

  const currentDate = new Date();
  const formattedDate = format(currentDate, "EEEE, MMMM d, yyyy");
  
  return (
    <MainLayout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-heading font-bold text-gray-900">Pool Hall Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">{formattedDate} • Open 12:00 PM - 2:00 AM</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Button 
            onClick={() => setReservationDialogOpen(true)}
            className="bg-gray-700 hover:bg-gray-800 text-white shadow-md"
          >
            <PlusIcon className="h-5 w-5 mr-2 text-white" />
            New Reservation
          </Button>
          <Button 
            onClick={() => setTransactionDialogOpen(true)}
            className="bg-primary hover:bg-primary/80 text-white shadow-md"
          >
            <CreditCard className="h-5 w-5 mr-2 text-white" />
            New Transaction
          </Button>
          <Button 
            onClick={() => window.location.href = "/debug-checkout"}
            className="bg-amber-600 hover:bg-amber-700 text-white shadow-md"
          >
            <BugIcon className="h-5 w-5 mr-2 text-white" />
            Debug Checkout
          </Button>
        </div>
      </div>

      <StatusSummary tables={tables} members={membershipStats} />
      <PoolTableGrid tables={tables} />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <UpcomingReservations reservations={reservations} />
        <RecentTransactions transactions={transactions} />
      </div>
      
      <MembershipSummary stats={membershipStats} tiers={membershipTiers} />

      <Dialog open={reservationDialogOpen} onOpenChange={setReservationDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogTitle>Create New Reservation</DialogTitle>
          <ReservationForm onSuccess={() => setReservationDialogOpen(false)} />
        </DialogContent>
      </Dialog>
      
      <Dialog open={transactionDialogOpen} onOpenChange={setTransactionDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogTitle>Create New Transaction</DialogTitle>
          <TransactionForm onSuccess={() => setTransactionDialogOpen(false)} />
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
