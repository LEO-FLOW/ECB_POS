import { MainLayout } from "@/components/layout/main-layout";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { PlusIcon, Search, UserPlus } from "lucide-react";
import { Dialog, DialogContent, DialogTitle, DialogHeader } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { MemberCard } from "@/components/members/member-card";
import { WalkInCustomersListFixed } from "@/components/customers/walk-in-customers-list-fixed";
import { MemberForm } from "@/components/members/member-form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function MembersPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [addMemberDialogOpen, setAddMemberDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: members, isLoading } = useQuery<User[]>({
    queryKey: ["/api/members"],
  });

  const filteredMembers = members?.filter(member => 
    member.fullName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.email?.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];
  
  const handleSuccess = (user: User) => {
    toast({
      title: "Member added",
      description: "New member has been added successfully",
    });
    setAddMemberDialogOpen(false);
  };

  return (
    <MainLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-heading font-bold text-gray-900 mb-4 sm:mb-0">Members</h1>
        <Button 
          onClick={() => setAddMemberDialogOpen(true)}
          className="bg-secondary hover:bg-secondary-light"
        >
          <UserPlus className="h-5 w-5 mr-2" />
          Add New Member
        </Button>
      </div>

      <Tabs defaultValue="members" className="mb-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="members">Members</TabsTrigger>
          <TabsTrigger value="walk-ins">Walk-in Customers</TabsTrigger>
        </TabsList>
        
        <TabsContent value="members">
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search members..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow p-6 h-40 animate-pulse">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="rounded-full bg-gray-200 h-12 w-12"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-24"></div>
                      <div className="h-3 bg-gray-200 rounded w-16"></div>
                    </div>
                  </div>
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-3"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          ) : (
            <>
              {filteredMembers.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500">No members found</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredMembers.map((member) => (
                    <MemberCard key={member.id} member={member} />
                  ))}
                </div>
              )}
            </>
          )}
        </TabsContent>
        
        <TabsContent value="walk-ins">
          <WalkInCustomersListFixed />
        </TabsContent>
      </Tabs>

      <Dialog open={addMemberDialogOpen} onOpenChange={setAddMemberDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add New Member</DialogTitle>
          </DialogHeader>
          
          <MemberForm 
            onSuccess={handleSuccess}
            onCancel={() => setAddMemberDialogOpen(false)}
            includeMembershipControls={true}
            includeStaffControls={true}
            mode="member"
            autoFocus={true}
          />
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
