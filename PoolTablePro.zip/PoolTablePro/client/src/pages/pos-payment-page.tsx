import { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Redirect } from 'wouter';
import Checkout from '@/components/pos/checkout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard } from 'lucide-react';

export default function PosPaymentPage() {
  const { user } = useAuth();
  const [amount, setAmount] = useState<number>(25);
  const [showCheckout, setShowCheckout] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);

  // Redirect if not logged in
  if (!user) {
    return <Redirect to="/auth" />;
  }

  if (paymentComplete) {
    return (
      <div className="container max-w-4xl mx-auto p-4 py-10">
        <Card className="w-full max-w-md mx-auto">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <div className="h-20 w-20 rounded-full bg-green-100 flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-10 w-10 text-green-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
            </div>
            <CardTitle className="text-center">Payment Successful!</CardTitle>
            <CardDescription className="text-center">
              Thank you for your payment. Your transaction was completed successfully.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="mb-4">Amount paid: <strong>${amount.toFixed(2)}</strong></p>
            <Button 
              onClick={() => {
                setPaymentComplete(false);
                setShowCheckout(false);
              }}
            >
              Make Another Payment
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto p-4 py-10">
      <h1 className="text-2xl font-bold mb-6">Point of Sale Payment</h1>
      
      {showCheckout ? (
        <Checkout 
          amount={amount}
          title="Complete Your Payment"
          description="Enter your card details to complete this transaction"
          onPaymentSuccess={() => setPaymentComplete(true)}
          onCancel={() => setShowCheckout(false)}
        />
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Payment Details</CardTitle>
            <CardDescription>
              Enter the payment amount to proceed with the transaction
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="amount">Amount ($)</Label>
                <Input
                  id="amount"
                  type="number"
                  min="1"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                />
              </div>
              
              <Button 
                className="w-full" 
                onClick={() => setShowCheckout(true)}
                disabled={amount <= 0}
              >
                <CreditCard className="mr-2 h-4 w-4" />
                Proceed to Payment
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}