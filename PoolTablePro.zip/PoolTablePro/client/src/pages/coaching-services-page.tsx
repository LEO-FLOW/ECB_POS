import { MainLayout } from "@/components/layout/main-layout";
import { CalendarIntegration } from "@/components/calendar/calendar-integration";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Briefcase, 
  CalendarClock, 
  UserCog, 
  Users, 
  Trophy, 
  Calendar, 
  Clock, 
  DollarSign 
} from 'lucide-react';

export default function CoachingServicesPage() {
  const { data: activeSessions, isLoading: isSessionsLoading } = useQuery({
    queryKey: ["/api/coaching/active"],
    queryFn: async () => {
      // In a production app, this would fetch real data
      return [
        {
          id: 1,
          type: "coaching",
          customer: "John Doe",
          date: "2025-04-05T14:00:00Z",
          coach: "Michael Smith",
          duration: 60
        },
        {
          id: 2,
          type: "instruction",
          customer: "Jane Wilson",
          date: "2025-04-06T11:00:00Z",
          coach: "Michael Smith",
          duration: 90
        }
      ];
    }
  });

  const mockServiceTypes = [
    {
      id: 1,
      name: "Coaching Session",
      icon: <UserCog className="h-5 w-5" />,
      description: "One-on-one coaching with a professional player",
      price: 60,
      duration: 60,
    },
    {
      id: 2,
      name: "Billiards Instruction",
      icon: <Briefcase className="h-5 w-5" />,
      description: "Learn fundamental techniques and strategies",
      price: 45,
      duration: 60,
    },
    {
      id: 3,
      name: "Tournament Prep",
      icon: <Trophy className="h-5 w-5" />,
      description: "Prepare for competitive play and tournaments",
      price: 75,
      duration: 90,
    },
    {
      id: 4,
      name: "Private Party",
      icon: <Users className="h-5 w-5" />,
      description: "Book a private space for your group or event",
      price: 200,
      duration: 180,
    }
  ];

  return (
    <MainLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-heading font-bold text-gray-900 mb-4 sm:mb-0">Coaching & Services</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Tabs defaultValue="calendar">
            <TabsList className="mb-4">
              <TabsTrigger value="calendar">
                <Calendar className="h-4 w-4 mr-1" />
                Calendar
              </TabsTrigger>
              <TabsTrigger value="services">
                <Briefcase className="h-4 w-4 mr-1" />
                Services
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="calendar" className="space-y-4">
              <CalendarIntegration />
            </TabsContent>
            
            <TabsContent value="services" className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {mockServiceTypes.map((service) => (
                  <Card key={service.id}>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        {service.icon}
                        {service.name}
                      </CardTitle>
                      <CardDescription>{service.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="h-4 w-4 text-gray-500" />
                          <span>{service.duration} minutes</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <DollarSign className="h-4 w-4 text-gray-500" />
                          <span>${service.price} per session</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarClock className="h-5 w-5" />
                Upcoming Sessions
              </CardTitle>
              <CardDescription>
                Your scheduled coaching sessions and services
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isSessionsLoading ? (
                <div className="animate-pulse space-y-3">
                  <div className="h-12 bg-gray-200 rounded"></div>
                  <div className="h-12 bg-gray-200 rounded"></div>
                </div>
              ) : activeSessions && activeSessions.length > 0 ? (
                <div className="space-y-3">
                  {activeSessions.map((session) => (
                    <div key={session.id} className="border rounded-md p-3">
                      <div className="font-medium">{session.customer}</div>
                      <div className="text-sm text-gray-500 flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        {new Date(session.date).toLocaleDateString(undefined, {
                          weekday: 'short',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </div>
                      <div className="text-sm text-gray-500 flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        {new Date(session.date).toLocaleTimeString(undefined, {
                          hour: '2-digit',
                          minute: '2-digit',
                        })} - {session.duration} min
                      </div>
                      <div className="text-xs mt-1 inline-block bg-gray-100 px-2 py-0.5 rounded-full">
                        {session.type.charAt(0).toUpperCase() + session.type.slice(1)}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-sm py-6 text-center">
                  No upcoming sessions scheduled
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tips for Coaches</CardTitle>
              <CardDescription>Making the most of your coaching sessions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p>• Plan your sessions in advance to maximize time</p>
              <p>• Set clear goals for each session with your students</p>
              <p>• Provide clear visual demonstrations of techniques</p>
              <p>• Give personalized feedback and track progress</p>
              <p>• Leave time for questions at the end of each session</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}