import { MainLayout } from "@/components/layout/main-layout";
import { useQuery } from "@tanstack/react-query";
import { Reservation } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { PlusIcon, Search, Calendar } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ReservationForm } from "@/components/reservations/reservation-form";
import { useState } from "react";
import { format, parseISO, isToday, isTomorrow, addDays } from "date-fns";
import { Input } from "@/components/ui/input";
import { DatePicker } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ReservationsPage() {
  const [reservationDialogOpen, setReservationDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [datePickerOpen, setDatePickerOpen] = useState(false);

  const { data: reservations, isLoading } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
  });

  const filteredReservations = reservations?.filter(reservation => {
    const reservationDate = new Date(reservation.date);
    const nameMatch = reservation.customerName?.toLowerCase().includes(searchQuery.toLowerCase());
    const dateMatch = selectedDate ? 
      reservationDate.toDateString() === selectedDate.toDateString() : 
      true;
    
    return nameMatch && dateMatch;
  }) || [];

  const todayReservations = filteredReservations.filter(
    res => isToday(new Date(res.date))
  );
  
  const tomorrowReservations = filteredReservations.filter(
    res => isTomorrow(new Date(res.date))
  );
  
  const upcomingReservations = filteredReservations.filter(
    res => {
      const resDate = new Date(res.date);
      const dayAfterTomorrow = addDays(new Date(), 2);
      return resDate >= dayAfterTomorrow;
    }
  );

  const formatReservationDate = (dateString: string) => {
    const date = new Date(dateString);
    if (isToday(date)) return "Today";
    if (isTomorrow(date)) return "Tomorrow";
    return format(date, "MMM d, yyyy");
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      case "completed": return "bg-blue-100 text-blue-800";
      case "no-show": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const ReservationItem = ({ reservation }: { reservation: Reservation }) => (
    <Card className="mb-4">
      <CardContent className="py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="h-10 w-10 rounded-full bg-primary-light flex items-center justify-center text-white font-semibold">
              {reservation.customerName?.split(" ").map(n => n[0]).join("") || "?"}
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-900">{reservation.customerName}</p>
              <p className="text-sm text-gray-500">
                Table {reservation.tableId} • {format(parseISO(reservation.startTime.toString()), "h:mm a")} - {format(parseISO(reservation.endTime.toString()), "h:mm a")}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge className={getStatusColor(reservation.status)}>
              {reservation.status.charAt(0).toUpperCase() + reservation.status.slice(1)}
            </Badge>
            <Badge variant="outline">
              {formatReservationDate(reservation.date.toString())}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <MainLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-heading font-bold text-gray-900 mb-4 sm:mb-0">Reservations</h1>
        <Button 
          onClick={() => setReservationDialogOpen(true)}
          className="bg-gray-700 hover:bg-gray-800 text-white shadow-md"
        >
          <PlusIcon className="h-5 w-5 mr-2 text-white" />
          New Reservation
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search reservations..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              {selectedDate ? format(selectedDate, "MMM d, yyyy") : "Pick a date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <DatePicker
              mode="single"
              selected={selectedDate}
              onSelect={(date) => {
                setSelectedDate(date);
                setDatePickerOpen(false);
              }}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="h-20 flex items-center">
                <div className="h-10 w-10 bg-gray-200 rounded-full"></div>
                <div className="ml-4 space-y-2 flex-1">
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
                <div className="flex space-x-2">
                  <div className="h-6 w-20 bg-gray-200 rounded-full"></div>
                  <div className="h-6 w-16 bg-gray-200 rounded-full"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Tabs defaultValue="today">
          <TabsList className="mb-4">
            <TabsTrigger value="today">Today ({todayReservations.length})</TabsTrigger>
            <TabsTrigger value="tomorrow">Tomorrow ({tomorrowReservations.length})</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming ({upcomingReservations.length})</TabsTrigger>
            <TabsTrigger value="all">All ({filteredReservations.length})</TabsTrigger>
          </TabsList>
          
          <TabsContent value="today" className="space-y-2">
            {todayReservations.length > 0 ? (
              todayReservations.map(reservation => (
                <ReservationItem key={reservation.id} reservation={reservation} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No reservations for today</p>
            )}
          </TabsContent>
          
          <TabsContent value="tomorrow" className="space-y-2">
            {tomorrowReservations.length > 0 ? (
              tomorrowReservations.map(reservation => (
                <ReservationItem key={reservation.id} reservation={reservation} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No reservations for tomorrow</p>
            )}
          </TabsContent>
          
          <TabsContent value="upcoming" className="space-y-2">
            {upcomingReservations.length > 0 ? (
              upcomingReservations.map(reservation => (
                <ReservationItem key={reservation.id} reservation={reservation} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No upcoming reservations</p>
            )}
          </TabsContent>
          
          <TabsContent value="all" className="space-y-2">
            {filteredReservations.length > 0 ? (
              filteredReservations.map(reservation => (
                <ReservationItem key={reservation.id} reservation={reservation} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No reservations found</p>
            )}
          </TabsContent>
        </Tabs>
      )}

      <Dialog open={reservationDialogOpen} onOpenChange={setReservationDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogTitle>Create New Reservation</DialogTitle>
          <ReservationForm onSuccess={() => setReservationDialogOpen(false)} />
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
