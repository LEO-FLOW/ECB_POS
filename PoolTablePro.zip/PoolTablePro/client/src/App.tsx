import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

import NotFound from "@/pages/not-found";
import DashboardPage from "@/pages/dashboard-page";
import TablesPage from "@/pages/tables-page";
import ReservationsPage from "@/pages/reservations-page";
import MembersPage from "@/pages/members-page";
import TransactionsPage from "@/pages/transactions-page";
import AuthPage from "@/pages/auth-page";
import PublicBookingPage from "@/pages/public-booking-page";
import PosPaymentPage from "@/pages/pos-payment-page";
import TestPaymentPage from "@/pages/test-payment-page";
import CoachingServicesPage from "@/pages/coaching-services-page";
import InventoryPage from "@/pages/inventory-page";
import CheckoutPage from "@/pages/checkout-page";
import DebugCheckoutPage from "@/pages/debug-checkout-page";
import TableSpecificCheckoutPage from "@/pages/table-specific-checkout-page";

function Router() {
  return (
    <Switch>
      <Route path="/book" component={PublicBookingPage} />
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/tables" component={TablesPage} />
      <ProtectedRoute path="/reservations" component={ReservationsPage} />
      <ProtectedRoute path="/members" component={MembersPage} />
      <ProtectedRoute path="/transactions" component={TransactionsPage} />
      <ProtectedRoute path="/coaching" component={CoachingServicesPage} />
      <ProtectedRoute path="/inventory" component={InventoryPage} />
      <ProtectedRoute path="/pos/payment" component={PosPaymentPage} />
      <ProtectedRoute path="/checkout" component={CheckoutPage} />
      <ProtectedRoute path="/tables/:tableUsageId/checkout" component={TableSpecificCheckoutPage} />
      <ProtectedRoute path="/debug-checkout" component={DebugCheckoutPage} />
      <Route path="/test-payment" component={TestPaymentPage} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
