// Inventory management methods to implement in MemStorage class

// Add these methods to the MemStorage class in storage.ts
/*
  async getInventoryItems(): Promise<InventoryItem[]> {
    return Array.from(this.inventoryItems.values());
  }

  async getInventoryItem(id: number): Promise<InventoryItem | null> {
    return this.inventoryItems.get(id) || null;
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const id = this.inventoryItemCurrentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    
    const newItem: InventoryItem = { 
      ...item, 
      id, 
      createdAt: createdAt,
      updatedAt: updatedAt,
      sku: item.sku || null,
      barcode: item.barcode || null,
      currentStock: item.currentStock || null,
      minStockLevel: item.minStockLevel || null,
      imageUrl: item.imageUrl || null,
      description: item.description || null,
      isActive: item.isActive === undefined ? true : item.isActive
    };
    
    this.inventoryItems.set(id, newItem);
    return newItem;
  }

  async updateInventoryItem(id: number, data: Partial<InsertInventoryItem>): Promise<InventoryItem> {
    const item = this.inventoryItems.get(id);
    if (!item) {
      throw new Error("Inventory item not found");
    }
    
    const updatedAt = new Date();
    const updatedItem: InventoryItem = { 
      ...item,
      ...data,
      updatedAt: updatedAt
    };
    
    this.inventoryItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<void> {
    if (!this.inventoryItems.has(id)) {
      throw new Error("Inventory item not found");
    }
    
    this.inventoryItems.delete(id);
  }

  async getInventoryCategories(): Promise<InventoryCategory[]> {
    return Array.from(this.inventoryCategories.values());
  }

  async getInventoryCategory(id: number): Promise<InventoryCategory | null> {
    return this.inventoryCategories.get(id) || null;
  }

  async createInventoryCategory(category: InsertInventoryCategory): Promise<InventoryCategory> {
    const id = this.inventoryCategoryCurrentId++;
    
    const newCategory: InventoryCategory = { 
      ...category, 
      id,
      description: category.description || null
    };
    
    this.inventoryCategories.set(id, newCategory);
    return newCategory;
  }

  async updateInventoryCategory(id: number, data: Partial<InsertInventoryCategory>): Promise<InventoryCategory> {
    const category = this.inventoryCategories.get(id);
    if (!category) {
      throw new Error("Inventory category not found");
    }
    
    const updatedCategory: InventoryCategory = { 
      ...category,
      ...data,
      description: data.description !== undefined ? data.description : category.description
    };
    
    this.inventoryCategories.set(id, updatedCategory);
    return updatedCategory;
  }

  async deleteInventoryCategory(id: number): Promise<void> {
    if (!this.inventoryCategories.has(id)) {
      throw new Error("Inventory category not found");
    }
    
    // Check if any items use this category
    const hasItems = Array.from(this.inventoryItems.values()).some(
      item => item.categoryId === id
    );
    
    if (hasItems) {
      throw new Error("Cannot delete category that has items assigned to it");
    }
    
    this.inventoryCategories.delete(id);
  }
*/