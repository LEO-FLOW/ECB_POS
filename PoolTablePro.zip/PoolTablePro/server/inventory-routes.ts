import { Router } from 'express';
import { storage } from './storage';
import { 
  insertInventoryItemSchema, 
  insertInventoryCategorySchema 
} from '@shared/schema';
import { eq } from 'drizzle-orm';
import { db } from './db';
import { inventoryCategories } from '@shared/schema';

const router = Router();

// Get all inventory items
router.get('/items', async (req, res) => {
  try {
    // Get all items first
    const items = await storage.getAllInventoryItems();
    
    // Fetch all categories to use for mapping
    const categories = await storage.getAllInventoryCategories();
    console.log("[INVENTORY-API] Categories:", categories.map(c => ({id: c.id, name: c.name})));
    
    // Map categories to a lookup object for faster access
    const categoryMap: Record<number, string> = {};
    categories.forEach(category => {
      categoryMap[category.id] = category.name;
    });
    
    console.log("[INVENTORY-API] Category map:", categoryMap);
    
    // Transform data to include categoryName explicitly for clients
    const transformedItems = items.map(item => {
      // Try to get category name from our map
      let categoryName = 'Unknown';
      
      if (item.categoryId && categoryMap[item.categoryId]) {
        categoryName = categoryMap[item.categoryId];
      }
      
      console.log(`[INVENTORY-API] Item ${item.id} (${item.name}) has categoryId=${item.categoryId}, mapped to name: ${categoryName}`);
      
      return {
        ...item,
        categoryName
      };
    });
    
    res.json(transformedItems);
  } catch (error: any) {
    console.error('Error fetching inventory items:', error);
    res.status(500).json({ message: error.message });
  }
});

// Get all inventory categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await storage.getAllInventoryCategories();
    res.json(categories);
  } catch (error: any) {
    console.error('Error fetching inventory categories:', error);
    res.status(500).json({ message: error.message });
  }
});

// Get a single inventory item
router.get('/items/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const item = await storage.getInventoryItem(id);
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }
    
    // Get category information separately
    let categoryName = 'Unknown';
    if (item.categoryId) {
      const category = await storage.getInventoryCategory(item.categoryId);
      if (category) {
        categoryName = category.name;
      }
    }
    
    console.log(`[INVENTORY-API] Item ${item.id} (${item.name}) has categoryId=${item.categoryId}, mapped to name: ${categoryName}`);
    
    // Transform to include categoryName explicitly for clients
    const transformedItem = {
      ...item,
      categoryName
    };
    
    res.json(transformedItem);
  } catch (error: any) {
    console.error('Error fetching inventory item:', error);
    res.status(500).json({ message: error.message });
  }
});

// Get a single category
router.get('/categories/:id', async (req, res) => {
  try {
    const category = await storage.getInventoryCategory(parseInt(req.params.id));
    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }
    res.json(category);
  } catch (error: any) {
    console.error('Error fetching inventory category:', error);
    res.status(500).json({ message: error.message });
  }
});

// Get items by category
router.get('/items/category/:categoryId', async (req, res) => {
  try {
    const categoryId = parseInt(req.params.categoryId);
    
    // Validate that the category exists
    const category = await storage.getInventoryCategory(categoryId);
    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }
    
    console.log(`[INVENTORY-API] Valid category found: ${category.name} (ID: ${categoryId})`);
    
    // Get items for this category
    const items = await storage.getInventoryItemsByCategory(categoryId);
    
    // If we got no items, log this out - could be a potential issue
    if (items.length === 0) {
      console.log(`[INVENTORY-API] No items found for category ${category.name} (ID: ${categoryId})`);
    } else {
      console.log(`[INVENTORY-API] Found ${items.length} items for category ${category.name} (ID: ${categoryId})`);
    }
    
    // Transform data to include categoryName explicitly for clients
    const transformedItems = items.map(item => ({
      ...item,
      categoryName: category.name // We already have the category name from above
    }));
    
    res.json(transformedItems);
  } catch (error: any) {
    console.error(`[INVENTORY-API] Error fetching items for category ${req.params.categoryId}:`, error);
    res.status(500).json({ message: error.message });
  }
});

// Create new inventory item
router.post('/items', async (req, res) => {
  try {
    const parsedData = insertInventoryItemSchema.parse(req.body);
    console.log('[INVENTORY-API] Creating new item:', parsedData);

    // Validate category ID
    if (parsedData.categoryId) {
      const category = await storage.getInventoryCategory(parsedData.categoryId);
      if (!category) {
        console.error(`[INVENTORY-API] Invalid categoryId provided: ${parsedData.categoryId}`);
        return res.status(400).json({ message: `Invalid category ID: ${parsedData.categoryId}` });
      }
      console.log(`[INVENTORY-API] Validated category: ${category.name} (ID: ${category.id})`);
    } else {
      console.log('[INVENTORY-API] No category ID provided, item will be uncategorized');
    }
    
    const newItem = await storage.createInventoryItem(parsedData);
    
    // Get category name to include in response
    let categoryName = 'Unknown';
    if (newItem.categoryId) {
      const category = await storage.getInventoryCategory(newItem.categoryId);
      if (category) {
        categoryName = category.name;
      }
    }
    
    // Return item with category name
    const responseItem = {
      ...newItem,
      categoryName
    };
    
    console.log('[INVENTORY-API] Created new item successfully:', responseItem);
    res.status(201).json(responseItem);
  } catch (error: any) {
    console.error('[INVENTORY-API] Error creating inventory item:', error);
    res.status(400).json({ message: error.message });
  }
});

// Create new inventory category
router.post('/categories', async (req, res) => {
  try {
    const parsedData = insertInventoryCategorySchema.parse(req.body);
    const newCategory = await storage.createInventoryCategory(parsedData);
    res.status(201).json(newCategory);
  } catch (error: any) {
    console.error('Error creating inventory category:', error);
    res.status(400).json({ message: error.message });
  }
});

// Update inventory item
router.patch('/items/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const existingItem = await storage.getInventoryItem(id);
    
    if (!existingItem) {
      return res.status(404).json({ message: 'Item not found' });
    }
    
    console.log(`[INVENTORY-API] Updating item ${id} (${existingItem.name})`, req.body);
    
    // Parse data first
    const parsedData = insertInventoryItemSchema.partial().parse(req.body);
    
    // Get all categories to properly map them
    const categories = await storage.getAllInventoryCategories();
    const validCategoryIds = categories.map(c => c.id);
    const categoryMap: Record<number, string> = {};
    categories.forEach(cat => {
      categoryMap[cat.id] = cat.name;
    });
    
    // Check if we need to assign a valid category (if current is missing or invalid)
    const needsCategory = !existingItem.categoryId || 
                          !validCategoryIds.includes(existingItem.categoryId);
                          
    // If we need to fix the category and no new category is specified in the update
    if (needsCategory && !parsedData.categoryId) {
      console.log(`[INVENTORY-API] Item ${existingItem.name} has invalid category ID: ${existingItem.categoryId}`);
      
      if (existingItem.name === "Water Bottle" || existingItem.name === "Cola" || existingItem.name === "Soda") {
        // Find Drinks category
        const drinksCategory = categories.find(c => c.name === "Drinks");
        if (drinksCategory) {
          console.log(`[INVENTORY-API] Assigning ${existingItem.name} to Drinks category (${drinksCategory.id})`);
          parsedData.categoryId = drinksCategory.id;
        }
      } else if (existingItem.name === "Chips" || existingItem.name === "Chocolate Bar") {
        // Find Snacks category
        const snacksCategory = categories.find(c => c.name === "Snacks");
        if (snacksCategory) {
          console.log(`[INVENTORY-API] Assigning ${existingItem.name} to Snacks category (${snacksCategory.id})`);
          parsedData.categoryId = snacksCategory.id;
        }
      } else if (existingItem.name === "Pool Chalk" || existingItem.name === "Cue Rental" || existingItem.name === "Cue Tip") {
        // Find Pool Accessories category
        const accessoriesCategory = categories.find(c => c.name === "Pool Accessories");
        if (accessoriesCategory) {
          console.log(`[INVENTORY-API] Assigning ${existingItem.name} to Pool Accessories category (${accessoriesCategory.id})`);
          parsedData.categoryId = accessoriesCategory.id;
        }
      }
    }
    
    // Validate new category ID if provided
    if (parsedData.categoryId && !validCategoryIds.includes(parsedData.categoryId)) {
      console.error(`[INVENTORY-API] Invalid categoryId in update: ${parsedData.categoryId}`);
      return res.status(400).json({ message: `Invalid category ID: ${parsedData.categoryId}` });
    }
    
    const updatedItem = await storage.updateInventoryItem(id, parsedData);
    
    // Get category name for the response
    let categoryName = 'Unknown';
    if (updatedItem.categoryId && categoryMap[updatedItem.categoryId]) {
      categoryName = categoryMap[updatedItem.categoryId];
    }
    
    // Return the updated item with the category name
    const responseItem = {
      ...updatedItem,
      categoryName
    };
    
    console.log(`[INVENTORY-API] Successfully updated item ${id}:`, responseItem);
    res.json(responseItem);
  } catch (error: any) {
    console.error('[INVENTORY-API] Error updating inventory item:', error);
    res.status(400).json({ message: error.message });
  }
});

// Update inventory category
router.patch('/categories/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const existingCategory = await storage.getInventoryCategory(id);
    
    if (!existingCategory) {
      return res.status(404).json({ message: 'Category not found' });
    }

    const parsedData = insertInventoryCategorySchema.partial().parse(req.body);
    const updatedCategory = await storage.updateInventoryCategory(id, parsedData);
    res.json(updatedCategory);
  } catch (error: any) {
    console.error('Error updating inventory category:', error);
    res.status(400).json({ message: error.message });
  }
});

// Delete inventory item
router.delete('/items/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const existingItem = await storage.getInventoryItem(id);
    
    if (!existingItem) {
      return res.status(404).json({ message: 'Item not found' });
    }

    await storage.deleteInventoryItem(id);
    res.status(200).json({ message: 'Item deleted successfully' });
  } catch (error: any) {
    console.error('Error deleting inventory item:', error);
    res.status(500).json({ message: error.message });
  }
});

// Delete inventory category
router.delete('/categories/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const existingCategory = await storage.getInventoryCategory(id);
    
    if (!existingCategory) {
      return res.status(404).json({ message: 'Category not found' });
    }

    // Check if category has items
    const items = await storage.getAllInventoryItems();
    const hasItems = items.some(item => item.categoryId === id);
    
    if (hasItems) {
      return res.status(400).json({ message: 'Cannot delete category with associated items' });
    }

    await storage.deleteInventoryCategory(id);
    res.status(200).json({ message: 'Category deleted successfully' });
  } catch (error: any) {
    console.error('Error deleting inventory category:', error);
    res.status(500).json({ message: error.message });
  }
});

export default router;