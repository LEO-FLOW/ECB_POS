import { 
  users, type User, type InsertUser,
  tables, type Table, type InsertTable,
  tableUsage, type TableUsage, type InsertTableUsage,
  tableSessionCustomers, type TableSessionCustomer, type InsertTableSessionCustomer,
  reservations, type Reservation, type InsertReservation,
  transactions, type Transaction, type InsertTransaction,
  membershipTiers, type MembershipTier, type InsertMembershipTier,
  specialRates, type SpecialRate, type InsertSpecialRate,
  // POS System imports
  inventoryCategories, type InventoryCategory, type InsertInventoryCategory,
  inventoryItems, type InventoryItem, type InsertInventoryItem,
  posOrders, type PosOrder, type InsertPosOrder,
  posOrderItems, type PosOrderItem, type InsertPosOrderItem,
  shiftRecords, type ShiftRecord, type InsertShiftRecord,
  paymentMethods, type PaymentMethod, type InsertPaymentMethod,
  // Room features import
  roomFeatures, type RoomFeature, type InsertRoomFeature,
  // Layout configuration
  layoutConfig, type LayoutConfig, type InsertLayoutConfig
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Session store property for authentication
  sessionStore: session.Store;
  
  // User/Member methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllMembers(): Promise<User[]>;
  
  // Table methods
  getTable(id: number): Promise<Table | undefined>;
  getAllTables(): Promise<any[]>; // With current usage and reservation info
  createTable(table: InsertTable): Promise<Table>;
  updateTable(id: number, tableData: Partial<Table>): Promise<Table>;
  updateTableStatus(id: number, status: string): Promise<Table>;
  
  // Table Usage methods
  getTableUsage(id: number): Promise<TableUsage | undefined>;
  getAllTableUsages(): Promise<TableUsage[]>; // Get all table usages
  getActiveTableUsages(): Promise<any[]>; // With user and table info
  createTableUsage(usage: InsertTableUsage): Promise<TableUsage>;
  updateTableUsage(id: number, data: Partial<TableUsage>): Promise<TableUsage>;
  
  // Table Session Customer methods
  getTableSessionCustomer(id: number): Promise<TableSessionCustomer | undefined>;
  getAllTableSessionCustomers(): Promise<TableSessionCustomer[]>;
  getTableSessionCustomersByTableUsage(tableUsageId: number): Promise<TableSessionCustomer[]>;
  addTableSessionCustomer(customer: InsertTableSessionCustomer): Promise<TableSessionCustomer>;
  removeTableSessionCustomer(id: number): Promise<void>;
  
  // Reservation methods
  getReservation(id: number): Promise<Reservation | undefined>;
  getAllReservations(): Promise<Reservation[]>;
  getUpcomingReservations(): Promise<Reservation[]>;
  createReservation(reservation: InsertReservation): Promise<Reservation>;
  updateReservationStatus(id: number, status: string): Promise<Reservation>;
  checkReservationConflict(tableId: number, startTime: Date, endTime: Date): Promise<Reservation[]>;
  
  // Transaction methods
  getAllTransactions(): Promise<Transaction[]>;
  getRecentTransactions(): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Membership Tier methods
  getAllMembershipTiers(): Promise<MembershipTier[]>;
  createMembershipTier(tier: InsertMembershipTier): Promise<MembershipTier>;
  
  // Special Rate methods
  getSpecialRate(id: number): Promise<SpecialRate | undefined>;
  getAllSpecialRates(): Promise<SpecialRate[]>;
  getActiveSpecialRates(): Promise<SpecialRate[]>;
  createSpecialRate(rate: InsertSpecialRate): Promise<SpecialRate>;
  updateSpecialRate(id: number, data: Partial<SpecialRate>): Promise<SpecialRate>;
  getApplicableSpecialRate(time: Date): Promise<SpecialRate | undefined>;
  
  // POS System methods - Inventory Categories
  getInventoryCategory(id: number): Promise<InventoryCategory | null>;
  getAllInventoryCategories(): Promise<InventoryCategory[]>;
  createInventoryCategory(category: InsertInventoryCategory): Promise<InventoryCategory>;
  updateInventoryCategory(id: number, data: Partial<InventoryCategory>): Promise<InventoryCategory>;
  getInventoryCategories(): Promise<InventoryCategory[]>; // Alias for getAllInventoryCategories
  deleteInventoryCategory(id: number): Promise<void>;
  
  // POS System methods - Inventory Items
  getInventoryItem(id: number): Promise<InventoryItem | null>;
  getAllInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItemsByCategory(categoryId: number): Promise<InventoryItem[]>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, data: Partial<InventoryItem>): Promise<InventoryItem>;
  updateInventoryStock(id: number, quantityChange: number): Promise<InventoryItem>;
  searchInventoryItems(query: string): Promise<InventoryItem[]>;
  deleteInventoryItem(id: number): Promise<void>;
  getInventoryItems(): Promise<InventoryItem[]>; // Alias for getAllInventoryItems
  
  // POS System methods - Orders
  getPosOrder(id: number): Promise<PosOrder | undefined>;
  getOrdersByUser(userId: number): Promise<PosOrder[]>;
  getOrdersByTableUsage(tableUsageId: number): Promise<PosOrder[]>;
  getRecentOrders(limit?: number): Promise<PosOrder[]>;
  createPosOrder(order: InsertPosOrder): Promise<PosOrder>;
  updatePosOrderStatus(id: number, status: string): Promise<PosOrder>;
  
  // POS System methods - Order Items
  getOrderItems(orderId: number): Promise<PosOrderItem[]>;
  addOrderItem(item: InsertPosOrderItem): Promise<PosOrderItem>;
  removeOrderItem(id: number): Promise<void>;
  updateOrderItemQuantity(id: number, quantity: number): Promise<PosOrderItem>;
  
  // POS System methods - Shift Records
  getCurrentShift(userId: number): Promise<ShiftRecord | undefined>;
  startShift(shift: InsertShiftRecord): Promise<ShiftRecord>;
  endShift(id: number, endAmount: number): Promise<ShiftRecord>;
  getShiftHistory(userId?: number): Promise<ShiftRecord[]>;
  
  // POS System methods - Payment Methods
  getAllPaymentMethods(): Promise<PaymentMethod[]>;
  getActivePaymentMethods(): Promise<PaymentMethod[]>;
  createPaymentMethod(method: InsertPaymentMethod): Promise<PaymentMethod>;
  updatePaymentMethod(id: number, data: Partial<PaymentMethod>): Promise<PaymentMethod>;
  
  // No additional helper methods needed - they are already defined above
  
  // Room features methods
  getRoomFeature(id: number): Promise<RoomFeature | undefined>;
  getAllRoomFeatures(): Promise<RoomFeature[]>;
  createRoomFeature(feature: InsertRoomFeature): Promise<RoomFeature>;
  updateRoomFeature(id: number, data: Partial<RoomFeature>): Promise<RoomFeature>;
  deleteRoomFeature(id: number): Promise<void>;
  
  // Layout configuration methods
  getLayoutConfig(id?: number): Promise<LayoutConfig | undefined>;
  getDefaultLayoutConfig(): Promise<LayoutConfig | undefined>;
  createLayoutConfig(config: InsertLayoutConfig): Promise<LayoutConfig>;
  updateLayoutConfig(id: number, data: Partial<LayoutConfig>): Promise<LayoutConfig>;
  deleteLayoutConfig(id: number): Promise<void>;
  
  // No duplicate session storage declaration needed
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tables: Map<number, Table>;
  private tableUsages: Map<number, TableUsage>;
  private tableSessionCustomers: Map<number, TableSessionCustomer>;
  private reservations: Map<number, Reservation>;
  private transactions: Map<number, Transaction>;
  private membershipTiers: Map<number, MembershipTier>;
  private specialRates: Map<number, SpecialRate>;
  
  // POS System storage
  private inventoryCategories: Map<number, InventoryCategory>;
  private inventoryItems: Map<number, InventoryItem>;
  private posOrders: Map<number, PosOrder>;
  private posOrderItems: Map<number, PosOrderItem>;
  private shiftRecords: Map<number, ShiftRecord>;
  private paymentMethods: Map<number, PaymentMethod>;
  private roomFeatures: Map<number, RoomFeature>;
  private roomFeatureCurrentId: number = 1;
  private layoutConfigs: Map<number, LayoutConfig>;
  private layoutConfigCurrentId: number = 1;
  
  sessionStore: session.Store;
  userCurrentId: number;
  tableCurrentId: number;
  tableUsageCurrentId: number;
  tableSessionCustomerCurrentId: number;
  reservationCurrentId: number;
  transactionCurrentId: number;
  membershipTierCurrentId: number;
  specialRateCurrentId: number;
  
  // POS System IDs
  inventoryCategoryCurrentId: number;
  inventoryItemCurrentId: number;
  posOrderCurrentId: number;
  posOrderItemCurrentId: number;
  shiftRecordCurrentId: number;
  paymentMethodCurrentId: number;

  constructor() {
    // Initialize base maps
    this.users = new Map();
    this.tables = new Map();
    this.tableUsages = new Map();
    this.tableSessionCustomers = new Map();
    this.reservations = new Map();
    this.transactions = new Map();
    this.membershipTiers = new Map();
    this.specialRates = new Map();
    
    // Initialize POS system maps
    this.inventoryCategories = new Map();
    this.inventoryItems = new Map();
    this.posOrders = new Map();
    this.posOrderItems = new Map();
    this.shiftRecords = new Map();
    this.paymentMethods = new Map();
    
    // Initialize room features map
    this.roomFeatures = new Map();
    
    // Initialize layout config map
    this.layoutConfigs = new Map();
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Initialize IDs for base entities
    this.userCurrentId = 1;
    this.tableCurrentId = 1;
    this.tableUsageCurrentId = 1;
    this.tableSessionCustomerCurrentId = 1;
    this.reservationCurrentId = 1;
    this.transactionCurrentId = 1;
    this.membershipTierCurrentId = 1;
    this.specialRateCurrentId = 1;
    
    // Initialize IDs for POS system entities
    this.inventoryCategoryCurrentId = 1;
    this.inventoryItemCurrentId = 1;
    this.posOrderCurrentId = 1;
    this.posOrderItemCurrentId = 1;
    this.shiftRecordCurrentId = 1;
    this.paymentMethodCurrentId = 1;
    
    // Initialize room feature ID
    this.roomFeatureCurrentId = 1;
    
    // Initialize layout config ID
    this.layoutConfigCurrentId = 1;
    
    // Initialize with default data
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default membership tiers
    this.createMembershipTier({
      name: "bronze",
      monthlyPrice: 19.99,
      tableRateDiscount: 0.05,
      foodDrinkDiscount: 0,
      guestPasses: 1,
      advanceReservationDays: 7,
      description: "Basic membership with standard pricing"
    });
    
    this.createMembershipTier({
      name: "silver",
      monthlyPrice: 34.99,
      tableRateDiscount: 0.15,
      foodDrinkDiscount: 0.1,
      guestPasses: 3,
      advanceReservationDays: 14,
      description: "Enhanced benefits for regular players"
    });
    
    this.createMembershipTier({
      name: "gold",
      monthlyPrice: 49.99,
      tableRateDiscount: 0.25,
      foodDrinkDiscount: 0.2,
      guestPasses: 5,
      advanceReservationDays: 30,
      description: "Premium experience for dedicated players"
    });
    
    // Create default special rates
    this.createSpecialRate({
      name: "Afternoon Special",
      description: "Discounted rates during afternoon hours",
      startTime: "12:00",
      endTime: "17:00",
      discountPercent: 15,
      isActive: true
    });
    
    this.createSpecialRate({
      name: "Happy Hour",
      description: "Special pricing on weekday evenings",
      startTime: "17:00",
      endTime: "19:00",
      dayOfWeek: "friday",
      discountPercent: 20,
      isActive: true
    });
    
    this.createSpecialRate({
      name: "Weekend Morning Rate",
      description: "Special flat rate for weekend mornings",
      startTime: "09:00",
      endTime: "12:00",
      dayOfWeek: "saturday",
      flatRate: 8,
      isActive: true
    });
    
    // Create default admin user
    this.createUser({
      username: "admin",
      password: "password123", // Will be hashed in auth.ts
      fullName: "System Admin",
      email: "admin@cueballmanager.com",
      isStaff: true
    });
    
    // Create some default tables
    this.createTable({
      name: "Table 1",
      type: "8ft Standard",
      status: "available",
      hourlyRate: 12
    });
    
    this.createTable({
      name: "Table 2",
      type: "9ft Tournament",
      status: "available",
      hourlyRate: 15
    });
    
    this.createTable({
      name: "Table 3",
      type: "7ft Bar",
      status: "available",
      hourlyRate: 10
    });
    
    // Create default payment methods
    this.createPaymentMethod({
      name: "Cash",
      isActive: true,
      requiresProcessing: false,
      processingFeePercent: 0
    });
    
    this.createPaymentMethod({
      name: "Credit Card",
      isActive: true,
      requiresProcessing: true,
      processingFeePercent: 2.9
    });
    
    this.createPaymentMethod({
      name: "Debit Card",
      isActive: true,
      requiresProcessing: true,
      processingFeePercent: 1.5
    });
    
    this.createPaymentMethod({
      name: "Stripe",
      isActive: true,
      requiresProcessing: true,
      processingFeePercent: 2.9
    });
    
    // Create default inventory categories
    const drinksCategory = this.createInventoryCategory({
      name: "Drinks",
      description: "Beverages including soft drinks, energy drinks, and water"
    });
    
    const snacksCategory = this.createInventoryCategory({
      name: "Snacks",
      description: "Quick bites and packaged foods"
    });
    
    const poolAccessoriesCategory = this.createInventoryCategory({
      name: "Pool Accessories",
      description: "Cues, chalk, gloves, and other pool accessories"
    });
    
    // Create default inventory items
    this.createInventoryItem({
      name: "Water Bottle",
      categoryId: drinksCategory.id,
      price: 2.49,
      cost: 0.79,
      sku: "DRK-001",
      currentStock: 50,
      minStockLevel: 20,
      description: "500ml bottled water"
    });
    
    this.createInventoryItem({
      name: "Soda",
      categoryId: drinksCategory.id,
      price: 2.99,
      cost: 0.99,
      sku: "DRK-002",
      currentStock: 40,
      minStockLevel: 15,
      description: "350ml canned soda, various flavors"
    });
    
    this.createInventoryItem({
      name: "Chips",
      categoryId: snacksCategory.id,
      price: 3.49,
      cost: 1.29,
      sku: "SNK-001",
      currentStock: 30,
      minStockLevel: 10,
      description: "Small bag of chips, various flavors"
    });
    
    this.createInventoryItem({
      name: "Chocolate Bar",
      categoryId: snacksCategory.id,
      price: 2.49,
      cost: 0.89,
      sku: "SNK-002",
      currentStock: 35,
      minStockLevel: 15,
      description: "Assorted chocolate bars"
    });
    
    this.createInventoryItem({
      name: "Pool Chalk",
      categoryId: poolAccessoriesCategory.id,
      price: 3.99,
      cost: 1.49,
      sku: "ACC-001",
      currentStock: 25,
      minStockLevel: 10,
      description: "Premium blue chalk for cue tips"
    });
    
    this.createInventoryItem({
      name: "Cue Rental",
      categoryId: poolAccessoriesCategory.id,
      price: 5.99,
      cost: 0.99,
      sku: "ACC-002",
      currentStock: 20,
      minStockLevel: 5,
      description: "Hourly rental of standard cue"
    });
  }

  // ===== USER/MEMBER METHODS =====
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const createdAt = new Date();
    
    // Generate username if not provided (for walk-in members)
    if (!insertUser.username) {
      // Create username from fullName or use "member" if not available
      const baseName = insertUser.fullName 
        ? insertUser.fullName.toLowerCase().replace(/\s+/g, '.') 
        : 'member';
      
      // Add id to ensure uniqueness
      insertUser.username = `${baseName}.${id}`;
    }
    
    // Set isWalkIn flag if not explicitly set
    if (insertUser.isWalkIn === undefined) {
      insertUser.isWalkIn = !insertUser.password; // If no password, consider as walk-in
    }
    
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }
  
  async getAllMembers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // ===== TABLE METHODS =====
  async getTable(id: number): Promise<Table | undefined> {
    return this.tables.get(id);
  }
  
  async getAllTables(): Promise<any[]> {
    const tables = Array.from(this.tables.values());
    const result = [];
    
    for (const table of tables) {
      // Find active usage for this table
      const currentUsage = Array.from(this.tableUsages.values()).find(
        usage => usage.tableId === table.id && usage.status === "active"
      );
      
      // Find current reservation if the table is reserved
      const now = new Date();
      const currentReservation = Array.from(this.reservations.values()).find(
        res => 
          res.tableId === table.id && 
          res.status === "confirmed" &&
          new Date(res.startTime) <= now &&
          new Date(res.endTime) >= now
      );
      
      // Find upcoming reservation if none is current
      const upcomingReservation = !currentReservation ? 
        Array.from(this.reservations.values()).find(
          res => 
            res.tableId === table.id && 
            res.status === "confirmed" &&
            new Date(res.startTime) > now
        ) : null;
      
      // Build usage info
      let usage = null;
      if (currentUsage) {
        const user = currentUsage.userId ? await this.getUser(currentUsage.userId) : null;
        usage = {
          id: currentUsage.id,
          startTime: currentUsage.startTime,
          userId: currentUsage.userId,
          userName: user ? user.fullName : null
        };
      }
      
      // Build reservation info
      let reservation = null;
      if (table.status === "reserved" && (currentReservation || upcomingReservation)) {
        const res = currentReservation || upcomingReservation;
        reservation = {
          id: res.id,
          customerName: res.customerName,
          startTime: res.startTime,
          endTime: res.endTime
        };
      }
      
      result.push({
        ...table,
        currentUsage: usage,
        reservation: reservation
      });
    }
    
    return result;
  }
  
  async createTable(insertTable: InsertTable): Promise<Table> {
    const id = this.tableCurrentId++;
    const table: Table = { ...insertTable, id };
    this.tables.set(id, table);
    return table;
  }
  
  async updateTable(id: number, tableData: Partial<Table>): Promise<Table> {
    const table = this.tables.get(id);
    if (!table) {
      throw new Error("Table not found");
    }
    
    const updatedTable: Table = { ...table, ...tableData };
    this.tables.set(id, updatedTable);
    return updatedTable;
  }
  
  async updateTableStatus(id: number, status: string): Promise<Table> {
    return this.updateTable(id, { status });
  }

  // ===== TABLE USAGE METHODS =====
  async getTableUsage(id: number): Promise<TableUsage | undefined> {
    return this.tableUsages.get(id);
  }
  
  async getAllTableUsages(): Promise<TableUsage[]> {
    // Return all table usages regardless of status
    return Array.from(this.tableUsages.values());
  }
  
  async getActiveTableUsages(): Promise<any[]> {
    const activeUsages = Array.from(this.tableUsages.values())
      .filter(usage => usage.status === "active");
    
    const result = [];
    
    for (const usage of activeUsages) {
      const table = await this.getTable(usage.tableId);
      const user = usage.userId ? await this.getUser(usage.userId) : null;
      
      result.push({
        ...usage,
        tableName: table ? table.name : `Table ${usage.tableId}`,
        userName: user ? user.fullName : null
      });
    }
    
    return result;
  }
  
  async createTableUsage(insertUsage: InsertTableUsage): Promise<TableUsage> {
    const id = this.tableUsageCurrentId++;
    const tableUsage: TableUsage = { ...insertUsage, id };
    this.tableUsages.set(id, tableUsage);
    return tableUsage;
  }
  
  async updateTableUsage(id: number, data: Partial<TableUsage>): Promise<TableUsage> {
    const usage = this.tableUsages.get(id);
    if (!usage) {
      throw new Error("Table usage not found");
    }
    
    const updatedUsage: TableUsage = { ...usage, ...data };
    this.tableUsages.set(id, updatedUsage);
    return updatedUsage;
  }

  // ===== TABLE SESSION CUSTOMER METHODS =====
  async getTableSessionCustomer(id: number): Promise<TableSessionCustomer | undefined> {
    return this.tableSessionCustomers.get(id);
  }

  async getAllTableSessionCustomers(): Promise<TableSessionCustomer[]> {
    // Return all table session customers regardless of table usage
    return Array.from(this.tableSessionCustomers.values());
  }
  
  async getTableSessionCustomersByTableUsage(tableUsageId: number): Promise<TableSessionCustomer[]> {
    return Array.from(this.tableSessionCustomers.values())
      .filter(customer => customer.tableUsageId === tableUsageId);
  }

  async addTableSessionCustomer(customer: InsertTableSessionCustomer): Promise<TableSessionCustomer> {
    const id = this.tableSessionCustomerCurrentId++;
    const addedAt = new Date();
    const newCustomer: TableSessionCustomer = { ...customer, id, addedAt };
    this.tableSessionCustomers.set(id, newCustomer);
    return newCustomer;
  }

  async removeTableSessionCustomer(id: number): Promise<void> {
    if (!this.tableSessionCustomers.has(id)) {
      throw new Error("Table session customer not found");
    }
    this.tableSessionCustomers.delete(id);
  }

  // ===== RESERVATION METHODS =====
  async getReservation(id: number): Promise<Reservation | undefined> {
    return this.reservations.get(id);
  }
  
  async getAllReservations(): Promise<Reservation[]> {
    return Array.from(this.reservations.values());
  }
  
  async getUpcomingReservations(): Promise<Reservation[]> {
    const now = new Date();
    return Array.from(this.reservations.values())
      .filter(res => 
        res.status === "confirmed" && 
        new Date(res.startTime) > now
      )
      .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())
      .slice(0, 10); // Limit to 10 most recent
  }
  
  async createReservation(insertReservation: InsertReservation): Promise<Reservation> {
    const id = this.reservationCurrentId++;
    const createdAt = new Date();
    const reservation: Reservation = { ...insertReservation, id, createdAt };
    this.reservations.set(id, reservation);
    return reservation;
  }
  
  async updateReservationStatus(id: number, status: string): Promise<Reservation> {
    const reservation = this.reservations.get(id);
    if (!reservation) {
      throw new Error("Reservation not found");
    }
    
    const updatedReservation: Reservation = { ...reservation, status };
    this.reservations.set(id, updatedReservation);
    return updatedReservation;
  }
  
  async checkReservationConflict(tableId: number, startTime: Date, endTime: Date): Promise<Reservation[]> {
    return Array.from(this.reservations.values())
      .filter(res => 
        res.tableId === tableId &&
        res.status === "confirmed" &&
        ((new Date(res.startTime) <= new Date(endTime) && new Date(res.endTime) >= new Date(startTime)))
      );
  }

  // ===== TRANSACTION METHODS =====
  async getAllTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
  
  async getRecentTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10); // Limit to 10 most recent
  }
  
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionCurrentId++;
    const timestamp = new Date();
    const transaction: Transaction = { ...insertTransaction, id, timestamp };
    this.transactions.set(id, transaction);
    return transaction;
  }

  // ===== MEMBERSHIP TIER METHODS =====
  async getAllMembershipTiers(): Promise<MembershipTier[]> {
    return Array.from(this.membershipTiers.values());
  }
  
  async createMembershipTier(insertTier: InsertMembershipTier): Promise<MembershipTier> {
    const id = this.membershipTierCurrentId++;
    const tier: MembershipTier = { ...insertTier, id };
    this.membershipTiers.set(id, tier);
    return tier;
  }
  
  // ===== SPECIAL RATE METHODS =====
  async getSpecialRate(id: number): Promise<SpecialRate | undefined> {
    return this.specialRates.get(id);
  }
  
  async getAllSpecialRates(): Promise<SpecialRate[]> {
    return Array.from(this.specialRates.values());
  }
  
  async getActiveSpecialRates(): Promise<SpecialRate[]> {
    return Array.from(this.specialRates.values())
      .filter(rate => rate.isActive);
  }
  
  async createSpecialRate(rate: InsertSpecialRate): Promise<SpecialRate> {
    const id = this.specialRateCurrentId++;
    const createdAt = new Date();
    const newRate: SpecialRate = { ...rate, id, createdAt };
    this.specialRates.set(id, newRate);
    return newRate;
  }
  
  async updateSpecialRate(id: number, data: Partial<SpecialRate>): Promise<SpecialRate> {
    const rate = this.specialRates.get(id);
    if (!rate) {
      throw new Error("Special rate not found");
    }
    
    const updatedRate: SpecialRate = { ...rate, ...data };
    this.specialRates.set(id, updatedRate);
    return updatedRate;
  }
  
  async getApplicableSpecialRate(time: Date): Promise<SpecialRate | undefined> {
    const nowHours = time.getHours();
    const nowMinutes = time.getMinutes();
    const timeString = `${nowHours.toString().padStart(2, '0')}:${nowMinutes.toString().padStart(2, '0')}`;
    const dayOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][time.getDay()];
    
    // Also check the previous day for overnight rates
    const yesterdayIndex = (time.getDay() - 1 + 7) % 7; // Ensure it's always positive
    const yesterdayOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][yesterdayIndex];
    
    console.log(`Finding applicable rate for: ${time.toISOString()}`);
    console.log(`Day of week: ${dayOfWeek}, Yesterday: ${yesterdayOfWeek}`);
    console.log(`Current time: ${timeString}`);
    
    const applicableRates = Array.from(this.specialRates.values())
      .filter(rate => {
        console.log(`Checking rate: ${rate.name} (${rate.startTime}-${rate.endTime}, day: ${rate.dayOfWeek || 'any'})`);
        console.log(`Is rate active? ${rate.isActive}`);
        
        // Check if the rate is active
        if (!rate.isActive) return false;
        
        // For overnight rates (end time is less than start time)
        if (this.timeStringToMinutes(rate.endTime) < this.timeStringToMinutes(rate.startTime)) {
          console.log(`  This is an overnight rate`);
          
          // If current time is after midnight but before end time
          if (this.timeStringToMinutes(timeString) < this.timeStringToMinutes(rate.endTime)) {
            console.log(`  Current time ${timeString} is after midnight but before end time ${rate.endTime}`);
            
            // Check if yesterday's day matches the rate's day
            if (rate.dayOfWeek && rate.dayOfWeek.toLowerCase() !== yesterdayOfWeek) {
              console.log(`  Rate day ${rate.dayOfWeek} doesn't match yesterday ${yesterdayOfWeek}`);
              return false;
            }
            
            console.log(`  Rate APPLIES - early morning after ${rate.dayOfWeek || 'any day'}`);
            // Current time is in the early morning, before the end time
            return true;
          } 
          
          // If current time is after start time
          if (this.timeStringToMinutes(timeString) >= this.timeStringToMinutes(rate.startTime)) {
            console.log(`  Current time ${timeString} is after start time ${rate.startTime}`);
            
            // Check if today's day matches the rate's day
            if (rate.dayOfWeek && rate.dayOfWeek.toLowerCase() !== dayOfWeek) {
              console.log(`  Rate day ${rate.dayOfWeek} doesn't match today ${dayOfWeek}`);
              return false;
            }
            
            console.log(`  Rate APPLIES - evening of ${rate.dayOfWeek || 'any day'}`);
            return true;
          }
          
          console.log(`  Rate DOES NOT APPLY - current time not in range`);
          return false;
        } 
        
        // For regular rates (same day)
        if (rate.dayOfWeek && rate.dayOfWeek.toLowerCase() !== dayOfWeek) {
          console.log(`  Rate day ${rate.dayOfWeek} doesn't match today ${dayOfWeek}`);
          return false;
        }
        
        // Check time range for normal daytime rate
        const applies = this.isTimeInRange(timeString, rate.startTime, rate.endTime);
        console.log(`  Regular rate ${applies ? 'APPLIES' : 'DOES NOT APPLY'}`);
        return applies;
      })
      .sort((a, b) => {
        // Sort by specificity - rates with dayOfWeek specified take precedence
        if (a.dayOfWeek && !b.dayOfWeek) return -1;
        if (!a.dayOfWeek && b.dayOfWeek) return 1;
        
        // Then sort by discount percentage or flat rate in descending order
        // Higher discounts or lower flat rates come first
        if (a.flatRate && b.flatRate) {
          return Number(a.flatRate) - Number(b.flatRate);
        } else if (a.discountPercent && b.discountPercent) {
          return Number(b.discountPercent) - Number(a.discountPercent);
        } else if (a.flatRate) {
          return -1; // Flat rates take precedence
        } else {
          return 1;
        }
      });
      
      console.log(`Found ${applicableRates.length} applicable rates`);
      if (applicableRates.length > 0) {
        console.log(`Selected rate: ${applicableRates[0].name}`);
      }
      
      return applicableRates[0]; // Return the most favorable rate
  }
  
  private isTimeInRange(currentTime: string, startTime: string, endTime: string): boolean {
    // Convert to minutes since midnight for easy comparison
    const currentMinutes = this.timeStringToMinutes(currentTime);
    const startMinutes = this.timeStringToMinutes(startTime);
    let endMinutes = this.timeStringToMinutes(endTime);
    
    // Handle overnight ranges (e.g., 22:00 to 02:00)
    if (endMinutes < startMinutes) {
      endMinutes += 24 * 60; // Add 24 hours in minutes
      // Adjust current time if needed (after midnight)
      const adjustedCurrentMinutes = currentMinutes < startMinutes ? 
        currentMinutes + 24 * 60 : currentMinutes;
      
      return adjustedCurrentMinutes >= startMinutes && adjustedCurrentMinutes <= endMinutes;
    }
    
    // Normal daytime range
    return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
  }
  
  private timeStringToMinutes(timeString: string): number {
    const [hours, minutes] = timeString.split(':').map(Number);
    return hours * 60 + minutes;
  }

  // ===== POS SYSTEM - INVENTORY CATEGORY METHODS =====
  // Updated to match the interface type
  async getInventoryCategory(id: number): Promise<InventoryCategory | null> {
    const category = this.inventoryCategories.get(id);
    return category || null;
  }

  async getAllInventoryCategories(): Promise<InventoryCategory[]> {
    return Array.from(this.inventoryCategories.values());
  }

  // Method removed due to duplication with implementation at line 1247

  async updateInventoryCategory(id: number, data: Partial<InventoryCategory>): Promise<InventoryCategory> {
    const category = this.inventoryCategories.get(id);
    if (!category) {
      throw new Error("Inventory category not found");
    }
    
    const updatedCategory: InventoryCategory = { ...category, ...data };
    this.inventoryCategories.set(id, updatedCategory);
    return updatedCategory;
  }

  // ===== POS SYSTEM - INVENTORY ITEM METHODS =====
  async getAllInventoryItems(): Promise<InventoryItem[]> {
    const items = Array.from(this.inventoryItems.values());
    // Make sure categoryId is included for each item
    return items.map(item => ({
      ...item,
      categoryId: item.categoryId
    }));
  }

  async getInventoryItemsByCategory(categoryId: number): Promise<InventoryItem[]> {
    return Array.from(this.inventoryItems.values())
      .filter(item => item.categoryId === categoryId && item.isActive)
      .map(item => ({
        ...item,
        categoryId: item.categoryId  // Explicitly ensure categoryId is included
      }));
  }

  async updateInventoryItem(id: number, data: Partial<InventoryItem>): Promise<InventoryItem> {
    const item = this.inventoryItems.get(id);
    if (!item) {
      throw new Error("Inventory item not found");
    }
    
    const updatedAt = new Date();
    // Ensure categoryId is preserved
    const updatedItem: InventoryItem = { 
      ...item, 
      ...data, 
      categoryId: data.categoryId || item.categoryId, // Explicitly ensure categoryId is preserved
      updatedAt 
    };
    this.inventoryItems.set(id, updatedItem);
    return updatedItem;
  }

  async updateInventoryStock(id: number, quantityChange: number): Promise<InventoryItem> {
    const item = this.inventoryItems.get(id);
    if (!item) {
      throw new Error("Inventory item not found");
    }
    
    const newStock = (item.currentStock || 0) + quantityChange;
    if (newStock < 0) {
      throw new Error("Cannot reduce stock below zero");
    }
    
    return this.updateInventoryItem(id, { currentStock: newStock });
  }

  async searchInventoryItems(query: string): Promise<InventoryItem[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.inventoryItems.values())
      .filter(item => 
        item.name.toLowerCase().includes(lowerQuery) || 
        item.description?.toLowerCase().includes(lowerQuery) ||
        item.sku?.toLowerCase().includes(lowerQuery) ||
        item.barcode?.toLowerCase().includes(lowerQuery)
      )
      .map(item => ({
        ...item,
        categoryId: item.categoryId  // Explicitly ensure categoryId is included
      }));
  }

  // ===== POS SYSTEM - ORDER METHODS =====
  async getPosOrder(id: number): Promise<PosOrder | undefined> {
    return this.posOrders.get(id);
  }

  async getOrdersByUser(userId: number): Promise<PosOrder[]> {
    return Array.from(this.posOrders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getOrdersByTableUsage(tableUsageId: number): Promise<PosOrder[]> {
    return Array.from(this.posOrders.values())
      .filter(order => order.tableUsageId === tableUsageId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getRecentOrders(limit: number = 10): Promise<PosOrder[]> {
    return Array.from(this.posOrders.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  async createPosOrder(order: InsertPosOrder): Promise<PosOrder> {
    const id = this.posOrderCurrentId++;
    const createdAt = new Date();
    const orderNumber = `ORD-${Date.now().toString().slice(-6)}`;
    const newOrder: PosOrder = { ...order, id, createdAt, orderNumber };
    this.posOrders.set(id, newOrder);
    return newOrder;
  }

  async updatePosOrderStatus(id: number, status: string): Promise<PosOrder> {
    const order = this.posOrders.get(id);
    if (!order) {
      throw new Error("Order not found");
    }
    
    let completedAt = order.completedAt;
    if (status === "paid" && !completedAt) {
      completedAt = new Date();
    }
    
    const updatedOrder: PosOrder = { ...order, paymentStatus: status, completedAt };
    this.posOrders.set(id, updatedOrder);
    return updatedOrder;
  }

  // ===== POS SYSTEM - ORDER ITEMS METHODS =====
  async getOrderItems(orderId: number): Promise<PosOrderItem[]> {
    return Array.from(this.posOrderItems.values())
      .filter(item => item.orderId === orderId);
  }

  async addOrderItem(item: InsertPosOrderItem): Promise<PosOrderItem> {
    const id = this.posOrderItemCurrentId++;
    const newItem: PosOrderItem = { ...item, id };
    this.posOrderItems.set(id, newItem);
    
    // Update inventory stock if needed
    if (item.inventoryItemId) {
      try {
        await this.updateInventoryStock(item.inventoryItemId, -item.quantity);
      } catch (error) {
        // If stock update fails, continue anyway but log the error
        console.error(`Failed to update stock for item ${item.inventoryItemId}: ${error}`);
      }
    }
    
    return newItem;
  }

  async removeOrderItem(id: number): Promise<void> {
    const item = this.posOrderItems.get(id);
    if (!item) {
      throw new Error("Order item not found");
    }
    
    // Return stock to inventory if needed
    if (item.inventoryItemId) {
      try {
        await this.updateInventoryStock(item.inventoryItemId, item.quantity);
      } catch (error) {
        // If stock update fails, continue anyway but log the error
        console.error(`Failed to update stock for item ${item.inventoryItemId}: ${error}`);
      }
    }
    
    this.posOrderItems.delete(id);
  }

  async updateOrderItemQuantity(id: number, quantity: number): Promise<PosOrderItem> {
    const item = this.posOrderItems.get(id);
    if (!item) {
      throw new Error("Order item not found");
    }
    
    // Calculate stock change and update inventory if needed
    const quantityDifference = item.quantity - quantity;
    if (item.inventoryItemId && quantityDifference !== 0) {
      try {
        await this.updateInventoryStock(item.inventoryItemId, quantityDifference);
      } catch (error) {
        // If stock update fails, throw error to prevent the quantity update
        throw new Error(`Failed to update stock: ${error}`);
      }
    }
    
    // Update the order item with new quantity and calculate new total price
    const totalPrice = quantity * parseFloat(item.unitPrice.toString());
    const updatedItem: PosOrderItem = { ...item, quantity, totalPrice };
    this.posOrderItems.set(id, updatedItem);
    return updatedItem;
  }

  // ===== POS SYSTEM - SHIFT RECORD METHODS =====
  async getCurrentShift(userId: number): Promise<ShiftRecord | undefined> {
    return Array.from(this.shiftRecords.values())
      .find(shift => shift.userId === userId && shift.status === "active");
  }

  async startShift(shift: InsertShiftRecord): Promise<ShiftRecord> {
    // Check if there's already an active shift for this user
    const activeShift = await this.getCurrentShift(shift.userId);
    if (activeShift) {
      throw new Error("User already has an active shift");
    }
    
    const id = this.shiftRecordCurrentId++;
    const startTime = new Date();
    const newShift: ShiftRecord = { ...shift, id, startTime, status: "active" };
    this.shiftRecords.set(id, newShift);
    return newShift;
  }

  async endShift(id: number, endAmount: number): Promise<ShiftRecord> {
    const shift = this.shiftRecords.get(id);
    if (!shift) {
      throw new Error("Shift record not found");
    }
    
    if (shift.status !== "active") {
      throw new Error("Cannot end a shift that is not active");
    }
    
    const endTime = new Date();
    const updatedShift: ShiftRecord = { ...shift, endAmount, endTime, status: "closed" };
    this.shiftRecords.set(id, updatedShift);
    return updatedShift;
  }

  async getShiftHistory(userId?: number): Promise<ShiftRecord[]> {
    let shifts = Array.from(this.shiftRecords.values());
    
    if (userId) {
      shifts = shifts.filter(shift => shift.userId === userId);
    }
    
    return shifts.sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }

  // ===== POS SYSTEM - PAYMENT METHOD METHODS =====
  async getAllPaymentMethods(): Promise<PaymentMethod[]> {
    return Array.from(this.paymentMethods.values());
  }

  async getActivePaymentMethods(): Promise<PaymentMethod[]> {
    return Array.from(this.paymentMethods.values())
      .filter(method => method.isActive);
  }

  async createPaymentMethod(method: InsertPaymentMethod): Promise<PaymentMethod> {
    const id = this.paymentMethodCurrentId++;
    const newMethod: PaymentMethod = { ...method, id };
    this.paymentMethods.set(id, newMethod);
    return newMethod;
  }

  async updatePaymentMethod(id: number, data: Partial<PaymentMethod>): Promise<PaymentMethod> {
    const method = this.paymentMethods.get(id);
    if (!method) {
      throw new Error("Payment method not found");
    }
    
    const updatedMethod: PaymentMethod = { ...method, ...data };
    this.paymentMethods.set(id, updatedMethod);
    return updatedMethod;
  }
  
  // ===== INVENTORY MANAGEMENT METHODS =====
  // Inventory methods for compatibility - just use the main implementation
  async getInventoryItems(): Promise<InventoryItem[]> {
    return this.getAllInventoryItems();
  }

  async getInventoryItem(id: number): Promise<InventoryItem | null> {
    const item = this.inventoryItems.get(id);
    if (!item) return null;
    // Make sure categoryId is included
    return {
      ...item,
      categoryId: item.categoryId
    };
  }

  // Inventory categories method for compatibility - use the main implementation
  async getInventoryCategories(): Promise<InventoryCategory[]> {
    return this.getAllInventoryCategories();
  }
  
  // Implement deleteInventoryItem method
  async deleteInventoryItem(id: number): Promise<void> {
    if (!this.inventoryItems.has(id)) {
      throw new Error("Inventory item not found");
    }
    
    this.inventoryItems.delete(id);
  }
  
  // Restored for use in initialization code
  async createInventoryCategory(category: InsertInventoryCategory): Promise<InventoryCategory> {
    const id = this.inventoryCategoryCurrentId++;
    
    const newCategory: InventoryCategory = { 
      ...category, 
      id,
      description: category.description || null
    };
    
    this.inventoryCategories.set(id, newCategory);
    return newCategory;
  }
  
  // Restored for use in initialization code
  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const id = this.inventoryItemCurrentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    
    const newItem: InventoryItem = { 
      ...item, 
      id, 
      createdAt: createdAt,
      updatedAt: updatedAt,
      categoryId: item.categoryId || 1, // Default to category 1 (Drinks) if missing
      sku: item.sku || null,
      barcode: item.barcode || null,
      currentStock: item.currentStock || null,
      minStockLevel: item.minStockLevel || null,
      imageUrl: item.imageUrl || null,
      description: item.description || null,
      isActive: item.isActive === undefined ? true : item.isActive
    };
    
    this.inventoryItems.set(id, newItem);
    return newItem;
  }

  async deleteInventoryCategory(id: number): Promise<void> {
    if (!this.inventoryCategories.has(id)) {
      throw new Error("Inventory category not found");
    }
    
    // Check if any items use this category
    const hasItems = Array.from(this.inventoryItems.values()).some(
      item => item.categoryId === id
    );
    
    if (hasItems) {
      throw new Error("Cannot delete category that has items assigned to it");
    }
    
    this.inventoryCategories.delete(id);
  }
  
  // ===== ROOM FEATURE METHODS =====
  async getRoomFeature(id: number): Promise<RoomFeature | undefined> {
    return this.roomFeatures.get(id);
  }

  async getAllRoomFeatures(): Promise<RoomFeature[]> {
    return Array.from(this.roomFeatures.values());
  }

  async createRoomFeature(feature: InsertRoomFeature): Promise<RoomFeature> {
    const id = this.roomFeatureCurrentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const newFeature: RoomFeature = { ...feature, id, createdAt, updatedAt };
    this.roomFeatures.set(id, newFeature);
    return newFeature;
  }

  async updateRoomFeature(id: number, data: Partial<RoomFeature>): Promise<RoomFeature> {
    const feature = this.roomFeatures.get(id);
    if (!feature) {
      throw new Error("Room feature not found");
    }
    
    const updatedAt = new Date();
    const updatedFeature: RoomFeature = { ...feature, ...data, updatedAt };
    this.roomFeatures.set(id, updatedFeature);
    return updatedFeature;
  }

  async deleteRoomFeature(id: number): Promise<void> {
    if (!this.roomFeatures.has(id)) {
      throw new Error("Room feature not found");
    }
    this.roomFeatures.delete(id);
  }
  
  // ===== LAYOUT CONFIGURATION METHODS =====
  async getLayoutConfig(id?: number): Promise<LayoutConfig | undefined> {
    if (id) {
      return this.layoutConfigs.get(id);
    }
    // If no ID is provided, return the first (and usually only) layout config
    const configs = Array.from(this.layoutConfigs.values());
    return configs.length > 0 ? configs[0] : undefined;
  }
  
  async getDefaultLayoutConfig(): Promise<LayoutConfig | undefined> {
    // Find the layout config marked as default, or the first one if none are marked
    const configs = Array.from(this.layoutConfigs.values());
    const defaultConfig = configs.find(config => config.isDefault) || (configs.length > 0 ? configs[0] : undefined);
    return defaultConfig;
  }
  
  async createLayoutConfig(config: InsertLayoutConfig): Promise<LayoutConfig> {
    const id = this.layoutConfigCurrentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const newConfig: LayoutConfig = { ...config, id, createdAt, updatedAt };
    
    // If this is the first layout config, or isDefault is true, ensure it's the default
    const isFirstConfig = this.layoutConfigs.size === 0;
    if (isFirstConfig || config.isDefault) {
      // If making this config default, update any existing default to non-default
      if (!isFirstConfig) {
        for (const [configId, existingConfig] of this.layoutConfigs.entries()) {
          if (existingConfig.isDefault) {
            this.layoutConfigs.set(configId, { ...existingConfig, isDefault: false, updatedAt: new Date() });
          }
        }
      }
      // Ensure the new config is marked as default
      newConfig.isDefault = true;
    }
    
    this.layoutConfigs.set(id, newConfig);
    return newConfig;
  }
  
  async updateLayoutConfig(id: number, data: Partial<LayoutConfig>): Promise<LayoutConfig> {
    const config = this.layoutConfigs.get(id);
    if (!config) {
      throw new Error("Layout configuration not found");
    }
    
    const updatedAt = new Date();
    const updatedConfig: LayoutConfig = { ...config, ...data, updatedAt };
    
    // If updating to make this config the default, update other defaults
    if (data.isDefault === true) {
      for (const [configId, existingConfig] of this.layoutConfigs.entries()) {
        if (configId !== id && existingConfig.isDefault) {
          this.layoutConfigs.set(configId, { ...existingConfig, isDefault: false, updatedAt: new Date() });
        }
      }
    }
    
    this.layoutConfigs.set(id, updatedConfig);
    return updatedConfig;
  }
  
  async deleteLayoutConfig(id: number): Promise<void> {
    const config = this.layoutConfigs.get(id);
    if (!config) {
      throw new Error("Layout configuration not found");
    }
    
    // If deleting the default config, make another one default if possible
    if (config.isDefault && this.layoutConfigs.size > 1) {
      const otherConfigs = Array.from(this.layoutConfigs.entries())
        .filter(([configId]) => configId !== id);
      
      if (otherConfigs.length > 0) {
        const [firstConfigId, firstConfig] = otherConfigs[0];
        this.layoutConfigs.set(firstConfigId, { ...firstConfig, isDefault: true, updatedAt: new Date() });
      }
    }
    
    this.layoutConfigs.delete(id);
  }
}


// Create storage instance defaulting to MemStorage
let storageInstance: IStorage = new MemStorage();

// Function to set a different storage implementation
export function setStorage(newStorage: IStorage) {
  storageInstance = newStorage;
  console.log('Switched to new storage implementation');
}

// Export the storage instance
export const storage = storageInstance;
