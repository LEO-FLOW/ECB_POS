import { db } from './db';
import * as schema from '@shared/schema';
import { eq, and, gte, desc, lte, like } from 'drizzle-orm';
import { IStorage } from './storage';
import { 
  User, InsertUser, 
  Table, InsertTable, 
  TableUsage, InsertTableUsage,
  TableSessionCustomer, InsertTableSessionCustomer,
  Reservation, InsertReservation,
  Transaction, InsertTransaction,
  MembershipTier, InsertMembershipTier,
  SpecialRate, InsertSpecialRate,
  InventoryCategory, InsertInventoryCategory,
  InventoryItem, InsertInventoryItem,
  PosOrder, InsertPosOrder,
  PosOrderItem, InsertPosOrderItem,
  ShiftRecord, InsertShiftRecord,
  PaymentMethod, InsertPaymentMethod,
  RoomFeature, InsertRoomFeature,
  LayoutConfig, InsertLayoutConfig
} from '@shared/schema';
import connectPg from 'connect-pg-simple';
import session from 'express-session';

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    // Create PostgreSQL session store
    this.sessionStore = new PostgresSessionStore({
      conString: process.env.DATABASE_URL,
      createTableIfMissing: true
    });
  }
  
  // User/Member methods
  async getUser(id: number): Promise<User | undefined> {
    const users = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return users[0];
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return users[0];
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(schema.users).values(user).returning();
    return result[0];
  }
  
  async getAllMembers(): Promise<User[]> {
    return await db.select().from(schema.users).where(eq(schema.users.isWalkIn, false));
  }
  
  // Table methods
  async getTable(id: number): Promise<Table | undefined> {
    const tables = await db.select().from(schema.tables).where(eq(schema.tables.id, id));
    return tables[0];
  }
  
  async getAllTables(): Promise<any[]> {
    const tables = await db.select().from(schema.tables);
    const tableUsages = await db.select().from(schema.tableUsage)
      .where(eq(schema.tableUsage.status, 'active'));
    
    const reservations = await db.select().from(schema.reservations)
      .where(and(
        eq(schema.reservations.status, 'confirmed'),
        gte(schema.reservations.startTime, new Date())
      ));
    
    // Add current usage and upcoming reservation info to each table
    return tables.map(table => {
      const currentUsage = tableUsages.find(usage => usage.tableId === table.id);
      const nextReservation = reservations
        .filter(res => res.tableId === table.id)
        .sort((a, b) => a.startTime.getTime() - b.startTime.getTime())[0];
      
      return {
        ...table,
        currentUsage,
        nextReservation
      };
    });
  }
  
  async createTable(table: InsertTable): Promise<Table> {
    const result = await db.insert(schema.tables).values(table).returning();
    return result[0];
  }
  
  async updateTable(id: number, tableData: Partial<Table>): Promise<Table> {
    const result = await db.update(schema.tables)
      .set(tableData)
      .where(eq(schema.tables.id, id))
      .returning();
    return result[0];
  }
  
  async updateTableStatus(id: number, status: string): Promise<Table> {
    return this.updateTable(id, { status });
  }
  
  // Table Usage methods
  async getTableUsage(id: number): Promise<TableUsage | undefined> {
    const usages = await db.select().from(schema.tableUsage).where(eq(schema.tableUsage.id, id));
    return usages[0];
  }
  
  async getAllTableUsages(): Promise<TableUsage[]> {
    return await db.select().from(schema.tableUsage);
  }
  
  async getActiveTableUsages(): Promise<any[]> {
    const usages = await db.select().from(schema.tableUsage)
      .where(eq(schema.tableUsage.status, 'active'));
    
    const userIds = usages.map(usage => usage.primaryUserId).filter(id => id !== null) as number[];
    let users: User[] = [];
    
    if (userIds.length > 0) {
      // Fetch users in a single query
      users = await db.select().from(schema.users);
    }
    
    const tableIds = usages.map(usage => usage.tableId);
    const tables = await db.select().from(schema.tables)
      .where(tableIds.length > 0 ? schema.tables.id : undefined);
    
    return usages.map(usage => {
      const user = users.find(u => u.id === usage.primaryUserId);
      const table = tables.find(t => t.id === usage.tableId);
      
      return {
        ...usage,
        user,
        table
      };
    });
  }
  
  async createTableUsage(usage: InsertTableUsage): Promise<TableUsage> {
    const result = await db.insert(schema.tableUsage).values(usage).returning();
    
    // Also update the table status to in-use
    await db.update(schema.tables)
      .set({ status: 'in-use' })
      .where(eq(schema.tables.id, usage.tableId));
    
    return result[0];
  }
  
  async updateTableUsage(id: number, data: Partial<TableUsage>): Promise<TableUsage> {
    const result = await db.update(schema.tableUsage)
      .set(data)
      .where(eq(schema.tableUsage.id, id))
      .returning();
    
    // If the usage is being marked as completed, update the table status to available
    if (data.status === 'completed') {
      const usage = result[0];
      await db.update(schema.tables)
        .set({ status: 'available' })
        .where(eq(schema.tables.id, usage.tableId));
    }
    
    return result[0];
  }
  
  // Table Session Customer methods
  async getTableSessionCustomer(id: number): Promise<TableSessionCustomer | undefined> {
    const customers = await db.select().from(schema.tableSessionCustomers)
      .where(eq(schema.tableSessionCustomers.id, id));
    return customers[0];
  }
  
  async getAllTableSessionCustomers(): Promise<TableSessionCustomer[]> {
    return await db.select().from(schema.tableSessionCustomers);
  }
  
  async getTableSessionCustomersByTableUsage(tableUsageId: number): Promise<TableSessionCustomer[]> {
    return await db.select().from(schema.tableSessionCustomers)
      .where(eq(schema.tableSessionCustomers.tableUsageId, tableUsageId));
  }
  
  async addTableSessionCustomer(customer: InsertTableSessionCustomer): Promise<TableSessionCustomer> {
    const result = await db.insert(schema.tableSessionCustomers).values(customer).returning();
    return result[0];
  }
  
  async removeTableSessionCustomer(id: number): Promise<void> {
    await db.delete(schema.tableSessionCustomers)
      .where(eq(schema.tableSessionCustomers.id, id));
  }
  
  // Reservation methods
  async getReservation(id: number): Promise<Reservation | undefined> {
    const reservations = await db.select().from(schema.reservations)
      .where(eq(schema.reservations.id, id));
    return reservations[0];
  }
  
  async getAllReservations(): Promise<Reservation[]> {
    return await db.select().from(schema.reservations);
  }
  
  async getUpcomingReservations(): Promise<Reservation[]> {
    return await db.select().from(schema.reservations)
      .where(and(
        eq(schema.reservations.status, 'confirmed'),
        gte(schema.reservations.startTime, new Date())
      ))
      .orderBy(schema.reservations.startTime);
  }
  
  async createReservation(reservation: InsertReservation): Promise<Reservation> {
    const result = await db.insert(schema.reservations).values(reservation).returning();
    return result[0];
  }
  
  async updateReservationStatus(id: number, status: string): Promise<Reservation> {
    const result = await db.update(schema.reservations)
      .set({ status })
      .where(eq(schema.reservations.id, id))
      .returning();
    return result[0];
  }
  
  async checkReservationConflict(tableId: number, startTime: Date, endTime: Date): Promise<Reservation[]> {
    return await db.select().from(schema.reservations)
      .where(and(
        eq(schema.reservations.tableId, tableId),
        eq(schema.reservations.status, 'confirmed'),
        lte(schema.reservations.startTime, endTime),
        gte(schema.reservations.endTime, startTime)
      ));
  }
  
  // Transaction methods
  async getAllTransactions(): Promise<Transaction[]> {
    return await db.select().from(schema.transactions);
  }
  
  async getRecentTransactions(): Promise<Transaction[]> {
    return await db.select().from(schema.transactions)
      .orderBy(desc(schema.transactions.timestamp))
      .limit(50);
  }
  
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const result = await db.insert(schema.transactions).values(transaction).returning();
    return result[0];
  }
  
  // Membership Tier methods
  async getAllMembershipTiers(): Promise<MembershipTier[]> {
    return await db.select().from(schema.membershipTiers);
  }
  
  async createMembershipTier(tier: InsertMembershipTier): Promise<MembershipTier> {
    const result = await db.insert(schema.membershipTiers).values(tier).returning();
    return result[0];
  }
  
  // Special Rate methods
  async getSpecialRate(id: number): Promise<SpecialRate | undefined> {
    const rates = await db.select().from(schema.specialRates)
      .where(eq(schema.specialRates.id, id));
    return rates[0];
  }
  
  async getAllSpecialRates(): Promise<SpecialRate[]> {
    return await db.select().from(schema.specialRates);
  }
  
  async getActiveSpecialRates(): Promise<SpecialRate[]> {
    return await db.select().from(schema.specialRates)
      .where(eq(schema.specialRates.isActive, true));
  }
  
  async createSpecialRate(rate: InsertSpecialRate): Promise<SpecialRate> {
    const result = await db.insert(schema.specialRates).values(rate).returning();
    return result[0];
  }
  
  async updateSpecialRate(id: number, data: Partial<SpecialRate>): Promise<SpecialRate> {
    const result = await db.update(schema.specialRates)
      .set(data)
      .where(eq(schema.specialRates.id, id))
      .returning();
    return result[0];
  }
  
  async getApplicableSpecialRate(time: Date): Promise<SpecialRate | undefined> {
    const activeRates = await this.getActiveSpecialRates();
    
    // Convert time to HH:MM format
    const timeString = `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}`;
    
    // Get day of week
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayOfWeek = days[time.getDay()];
    
    // Find applicable rate
    for (const rate of activeRates) {
      // Check if the rate is for any day or the specific day
      const isDayMatch = !rate.dayOfWeek || rate.dayOfWeek === dayOfWeek;
      
      if (isDayMatch && this.isTimeInRange(timeString, rate.startTime, rate.endTime)) {
        return rate;
      }
    }
    
    return undefined;
  }
  
  private isTimeInRange(currentTime: string, startTime: string, endTime: string): boolean {
    const current = this.timeStringToMinutes(currentTime);
    const start = this.timeStringToMinutes(startTime);
    const end = this.timeStringToMinutes(endTime);
    
    if (start <= end) {
      // Normal time range (e.g., 10:00 to 18:00)
      return current >= start && current <= end;
    } else {
      // Overnight time range (e.g., 22:00 to 06:00)
      return current >= start || current <= end;
    }
  }
  
  private timeStringToMinutes(timeString: string): number {
    const [hours, minutes] = timeString.split(':').map(Number);
    return hours * 60 + minutes;
  }
  
  // POS System methods - Inventory Categories
  async getInventoryCategory(id: number): Promise<InventoryCategory | null> {
    const categories = await db.select().from(schema.inventoryCategories)
      .where(eq(schema.inventoryCategories.id, id));
    return categories[0] || null;
  }
  
  async getAllInventoryCategories(): Promise<InventoryCategory[]> {
    return await db.select().from(schema.inventoryCategories);
  }
  
  async createInventoryCategory(category: InsertInventoryCategory): Promise<InventoryCategory> {
    const result = await db.insert(schema.inventoryCategories).values(category).returning();
    return result[0];
  }
  
  async updateInventoryCategory(id: number, data: Partial<InventoryCategory>): Promise<InventoryCategory> {
    const result = await db.update(schema.inventoryCategories)
      .set(data)
      .where(eq(schema.inventoryCategories.id, id))
      .returning();
    return result[0];
  }
  
  // POS System methods - Inventory Items
  async getInventoryItem(id: number): Promise<(InventoryItem & { category?: InventoryCategory }) | null> {
    try {
      // Use the with: syntax to leverage the relations we defined
      const items = await db.query.inventoryItems.findMany({
        where: eq(schema.inventoryItems.id, id),
        with: {
          category: true
        },
      });
      
      if (items.length === 0) return null;
      return items[0];
    } catch (error) {
      console.error('Error fetching inventory item:', error);
      return null;
    }
  }
  
  async getAllInventoryItems(): Promise<(InventoryItem & { category?: InventoryCategory })[]> {
    try {
      // Use the with: syntax to leverage the relations we defined
      return await db.query.inventoryItems.findMany({
        with: {
          category: true
        },
        orderBy: schema.inventoryItems.name
      });
    } catch (error) {
      console.error('Error fetching all inventory items:', error);
      return [];
    }
  }
  
  async getInventoryItemsByCategory(categoryId: number): Promise<(InventoryItem & { category?: InventoryCategory })[]> {
    try {
      console.log(`Fetching items for category ID: ${categoryId}`);
      
      // Use the with: syntax to leverage the relations we defined
      const items = await db.query.inventoryItems.findMany({
        where: eq(schema.inventoryItems.categoryId, categoryId),
        with: {
          category: true
        },
        orderBy: schema.inventoryItems.name
      });
      
      console.log(`Found ${items.length} items for category ID: ${categoryId}`);
      return items;
    } catch (error) {
      console.error(`Error fetching items for category ${categoryId}:`, error);
      return [];
    }
  }
  
  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    // Ensure item has a categoryId
    if (!item.categoryId) {
      const categories = await this.getAllInventoryCategories();
      if (categories.length > 0) {
        item.categoryId = categories[0].id;
      } else {
        // Create a default category if none exists
        const defaultCategory = await this.createInventoryCategory({
          name: 'General',
          description: 'Default category'
        });
        item.categoryId = defaultCategory.id;
      }
    }
    
    const result = await db.insert(schema.inventoryItems).values(item).returning();
    return result[0];
  }
  
  async updateInventoryItem(id: number, data: Partial<InventoryItem>): Promise<InventoryItem> {
    const result = await db.update(schema.inventoryItems)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(schema.inventoryItems.id, id))
      .returning();
    return result[0];
  }
  
  async updateInventoryStock(id: number, quantityChange: number): Promise<InventoryItem> {
    const item = await this.getInventoryItem(id);
    if (!item) {
      throw new Error(`Inventory item with ID ${id} not found`);
    }
    
    const newStock = (item.currentStock || 0) + quantityChange;
    
    return await this.updateInventoryItem(id, {
      currentStock: newStock
    });
  }
  
  async searchInventoryItems(query: string): Promise<(InventoryItem & { category?: InventoryCategory })[]> {
    try {
      // Use the prepared query approach with the query builder
      return await db.query.inventoryItems.findMany({
        where: like(schema.inventoryItems.name, `%${query}%`),
        with: {
          category: true
        },
        orderBy: schema.inventoryItems.name
      });
    } catch (error) {
      console.error('Error searching inventory items:', error);
      return [];
    }
  }
  
  // POS System methods - Orders
  async getPosOrder(id: number): Promise<PosOrder | undefined> {
    const orders = await db.select().from(schema.posOrders)
      .where(eq(schema.posOrders.id, id));
    return orders[0];
  }
  
  async getOrdersByUser(userId: number): Promise<PosOrder[]> {
    return await db.select().from(schema.posOrders)
      .where(eq(schema.posOrders.userId, userId));
  }
  
  async getOrdersByTableUsage(tableUsageId: number): Promise<PosOrder[]> {
    // First, get orders directly linked to this tableUsageId
    const ordersByTableId = await db.select().from(schema.posOrders)
      .where(eq(schema.posOrders.tableUsageId, tableUsageId));
    
    // Then try to find the session ID for this table usage
    const tableUsage = await this.getTableUsage(tableUsageId);
    if (!tableUsage || !tableUsage.sessionId) {
      return ordersByTableId; // Return just the directly linked orders
    }
    
    // If we have a sessionId, get orders linked by sessionId
    const ordersBySessionId = await db.select().from(schema.posOrders)
      .where(eq(schema.posOrders.sessionId, tableUsage.sessionId));
    
    // Combine the results, ensuring no duplicates
    const allOrders = [...ordersByTableId];
    
    // Add orders found by sessionId if they're not already in the results
    for (const order of ordersBySessionId) {
      if (!allOrders.some(o => o.id === order.id)) {
        allOrders.push(order);
      }
    }
    
    return allOrders;
  }
  
  async getRecentOrders(limit: number = 10): Promise<PosOrder[]> {
    return await db.select().from(schema.posOrders)
      .orderBy(desc(schema.posOrders.createdAt))
      .limit(limit);
  }
  
  async createPosOrder(order: InsertPosOrder): Promise<PosOrder> {
    const result = await db.insert(schema.posOrders).values(order).returning();
    return result[0];
  }
  
  async updatePosOrderStatus(id: number, status: string): Promise<PosOrder> {
    const result = await db.update(schema.posOrders)
      .set({
        paymentStatus: status,
        completedAt: status === 'paid' ? new Date() : null
      })
      .where(eq(schema.posOrders.id, id))
      .returning();
    return result[0];
  }
  
  // POS System methods - Order Items
  async getOrderItems(orderId: number): Promise<PosOrderItem[]> {
    return await db.select().from(schema.posOrderItems)
      .where(eq(schema.posOrderItems.orderId, orderId));
  }
  
  async addOrderItem(item: InsertPosOrderItem): Promise<PosOrderItem> {
    const result = await db.insert(schema.posOrderItems).values(item).returning();
    return result[0];
  }
  
  async removeOrderItem(id: number): Promise<void> {
    await db.delete(schema.posOrderItems)
      .where(eq(schema.posOrderItems.id, id));
  }
  
  async updateOrderItemQuantity(id: number, quantity: number): Promise<PosOrderItem> {
    const item = await db.select().from(schema.posOrderItems)
      .where(eq(schema.posOrderItems.id, id));
    
    if (!item[0]) {
      throw new Error(`Order item with ID ${id} not found`);
    }
    
    const unitPrice = parseFloat(item[0].unitPrice);
    const totalPrice = (unitPrice * quantity).toFixed(2);
    
    const result = await db.update(schema.posOrderItems)
      .set({
        quantity,
        totalPrice
      })
      .where(eq(schema.posOrderItems.id, id))
      .returning();
    
    return result[0];
  }
  
  // POS System methods - Shift Records
  async getCurrentShift(userId: number): Promise<ShiftRecord | undefined> {
    const shifts = await db.select().from(schema.shiftRecords)
      .where(and(
        eq(schema.shiftRecords.userId, userId),
        eq(schema.shiftRecords.status, 'active')
      ));
    return shifts[0];
  }
  
  async startShift(shift: InsertShiftRecord): Promise<ShiftRecord> {
    const result = await db.insert(schema.shiftRecords).values(shift).returning();
    return result[0];
  }
  
  async endShift(id: number, endAmount: number): Promise<ShiftRecord> {
    const result = await db.update(schema.shiftRecords)
      .set({
        endAmount: endAmount.toString(),
        endTime: new Date(),
        status: 'closed'
      })
      .where(eq(schema.shiftRecords.id, id))
      .returning();
    return result[0];
  }
  
  async getShiftHistory(userId?: number): Promise<ShiftRecord[]> {
    if (userId) {
      return await db.select().from(schema.shiftRecords)
        .where(eq(schema.shiftRecords.userId, userId))
        .orderBy(desc(schema.shiftRecords.startTime));
    } else {
      return await db.select().from(schema.shiftRecords)
        .orderBy(desc(schema.shiftRecords.startTime));
    }
  }
  
  // POS System methods - Payment Methods
  async getAllPaymentMethods(): Promise<PaymentMethod[]> {
    return await db.select().from(schema.paymentMethods);
  }
  
  async getActivePaymentMethods(): Promise<PaymentMethod[]> {
    return await db.select().from(schema.paymentMethods)
      .where(eq(schema.paymentMethods.isActive, true));
  }
  
  async createPaymentMethod(method: InsertPaymentMethod): Promise<PaymentMethod> {
    const result = await db.insert(schema.paymentMethods).values(method).returning();
    return result[0];
  }
  
  async updatePaymentMethod(id: number, data: Partial<PaymentMethod>): Promise<PaymentMethod> {
    const result = await db.update(schema.paymentMethods)
      .set(data)
      .where(eq(schema.paymentMethods.id, id))
      .returning();
    return result[0];
  }
  
  // Note: These methods are no longer aliases but full implementations
  // for inventory management using the database
  async getInventoryItems(): Promise<InventoryItem[]> {
    // This is a convenience method that directly calls getAllInventoryItems
    // to ensure consistent implementation
    return this.getAllInventoryItems();
  }
  
  async getInventoryCategories(): Promise<InventoryCategory[]> {
    // This is a convenience method that directly calls getAllInventoryCategories
    // to ensure consistent implementation
    return this.getAllInventoryCategories();
  }
  
  async deleteInventoryItem(id: number): Promise<void> {
    // Delete an inventory item by ID
    await db.delete(schema.inventoryItems)
      .where(eq(schema.inventoryItems.id, id));
  }
  
  async deleteInventoryCategory(id: number): Promise<void> {
    // Delete a category (will fail if there are items in this category)
    await db.delete(schema.inventoryCategories)
      .where(eq(schema.inventoryCategories.id, id));
  }
  
  // Room features methods
  async getRoomFeature(id: number): Promise<RoomFeature | undefined> {
    const features = await db.select().from(schema.roomFeatures)
      .where(eq(schema.roomFeatures.id, id));
    return features[0];
  }
  
  async getAllRoomFeatures(): Promise<RoomFeature[]> {
    return await db.select().from(schema.roomFeatures);
  }
  
  async createRoomFeature(feature: InsertRoomFeature): Promise<RoomFeature> {
    const now = new Date();
    const result = await db.insert(schema.roomFeatures).values({
      ...feature,
      createdAt: now,
      updatedAt: now
    }).returning();
    return result[0];
  }
  
  async updateRoomFeature(id: number, data: Partial<RoomFeature>): Promise<RoomFeature> {
    const result = await db.update(schema.roomFeatures)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(schema.roomFeatures.id, id))
      .returning();
    return result[0];
  }
  
  async deleteRoomFeature(id: number): Promise<void> {
    await db.delete(schema.roomFeatures)
      .where(eq(schema.roomFeatures.id, id));
  }
  
  // Layout configuration methods
  async getLayoutConfig(id?: number): Promise<LayoutConfig | undefined> {
    if (id) {
      const configs = await db.select().from(schema.layoutConfig)
        .where(eq(schema.layoutConfig.id, id));
      return configs[0];
    } else {
      return this.getDefaultLayoutConfig();
    }
  }
  
  async getDefaultLayoutConfig(): Promise<LayoutConfig | undefined> {
    const configs = await db.select().from(schema.layoutConfig)
      .where(eq(schema.layoutConfig.isDefault, true));
    return configs[0];
  }
  
  async createLayoutConfig(config: InsertLayoutConfig): Promise<LayoutConfig> {
    const now = new Date();
    
    // If this is set as default, unset any other defaults
    if (config.isDefault) {
      await db.update(schema.layoutConfig)
        .set({ isDefault: false })
        .where(eq(schema.layoutConfig.isDefault, true));
    }
    
    const result = await db.insert(schema.layoutConfig).values({
      ...config,
      createdAt: now,
      updatedAt: now
    }).returning();
    
    return result[0];
  }
  
  async updateLayoutConfig(id: number, data: Partial<LayoutConfig>): Promise<LayoutConfig> {
    // If this is set as default, unset any other defaults
    if (data.isDefault) {
      await db.update(schema.layoutConfig)
        .set({ isDefault: false })
        .where(and(
          eq(schema.layoutConfig.isDefault, true),
          schema.layoutConfig.id !== id
        ));
    }
    
    const result = await db.update(schema.layoutConfig)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(schema.layoutConfig.id, id))
      .returning();
    
    return result[0];
  }
  
  async deleteLayoutConfig(id: number): Promise<void> {
    // Check if this is the default config
    const config = await this.getLayoutConfig(id);
    
    if (config?.isDefault) {
      // Don't allow deleting the default config without setting another as default
      const otherConfigs = await db.select().from(schema.layoutConfig)
        .where(schema.layoutConfig.id !== id);
      
      if (otherConfigs.length > 0) {
        // Set another config as default
        await this.updateLayoutConfig(otherConfigs[0].id, { isDefault: true });
      } else {
        throw new Error("Cannot delete the only layout configuration");
      }
    }
    
    await db.delete(schema.layoutConfig)
      .where(eq(schema.layoutConfig.id, id));
  }
}