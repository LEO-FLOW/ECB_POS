import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import pg from 'pg';
const { Pool } = pg;
import * as schema from '@shared/schema';

// Validate that we have a DATABASE_URL
if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is required');
}

// Create a PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

// Create a Drizzle client instance
export const db = drizzle(pool, { schema });

// Instead of running migrations, we'll use push-based schema updates
export async function runMigrations() {
  try {
    console.log('Initializing database schema...');
    // Instead of running migrations, we'll create the tables directly using schema
    // This avoids the need for migration files
    console.log('Schema setup completed successfully.');
    return true;
  } catch (error) {
    console.error('Schema setup failed:', error);
    throw error;
  }
}

// Initialize database with default data if needed
export async function initializeDefaultData() {
  try {
    // Check if we have any inventory categories
    const categories = await db.select().from(schema.inventoryCategories);
    
    if (categories.length === 0) {
      console.log('Initializing default inventory categories...');
      
      // Create default categories
      const defaultCategories = [
        { name: 'Drinks', description: 'Beverages and refreshments' },
        { name: 'Snacks', description: 'Quick bites and snacks' },
        { name: 'Pool Accessories', description: 'Cues, chalk, and other pool accessories' },
      ];
      
      for (const category of defaultCategories) {
        await db.insert(schema.inventoryCategories).values(category);
      }
      
      // Get the newly created categories
      const createdCategories = await db.select().from(schema.inventoryCategories);
      
      // Create default inventory items
      const drinksCategory = createdCategories.find(c => c.name === 'Drinks')?.id;
      const snacksCategory = createdCategories.find(c => c.name === 'Snacks')?.id;
      const accessoriesCategory = createdCategories.find(c => c.name === 'Pool Accessories')?.id;
      
      if (drinksCategory && snacksCategory && accessoriesCategory) {
        console.log('Initializing default inventory items...');
        
        const defaultItems = [
          {
            name: 'Water Bottle',
            categoryId: drinksCategory,
            price: '1.50',
            cost: '0.50',
            currentStock: 50,
            description: 'Still mineral water (500ml)'
          },
          {
            name: 'Cola',
            categoryId: drinksCategory,
            price: '2.00',
            cost: '0.75',
            currentStock: 48,
            description: 'Classic cola (330ml)'
          },
          {
            name: 'Chips',
            categoryId: snacksCategory,
            price: '1.75',
            cost: '0.80',
            currentStock: 30,
            description: 'Potato chips (40g)'
          },
          {
            name: 'Chocolate Bar',
            categoryId: snacksCategory,
            price: '1.50',
            cost: '0.65',
            currentStock: 25,
            description: 'Milk chocolate (50g)'
          },
          {
            name: 'Pool Chalk',
            categoryId: accessoriesCategory,
            price: '2.50',
            cost: '1.00',
            currentStock: 40,
            description: 'Premium blue chalk'
          },
          {
            name: 'Cue Tip',
            categoryId: accessoriesCategory,
            price: '3.50',
            cost: '1.50',
            currentStock: 20,
            description: 'Replacement cue tip'
          }
        ];
        
        for (const item of defaultItems) {
          await db.insert(schema.inventoryItems).values(item);
        }
      }
    }
    
    // Check if we have any payment methods
    const paymentMethods = await db.select().from(schema.paymentMethods);
    
    if (paymentMethods.length === 0) {
      console.log('Initializing default payment methods...');
      
      const defaultPaymentMethods = [
        { name: 'Cash', isActive: true, requiresProcessing: false, processingFeePercent: '0' },
        { name: 'Credit Card', isActive: true, requiresProcessing: true, processingFeePercent: '2.9' },
        { name: 'Debit Card', isActive: true, requiresProcessing: true, processingFeePercent: '1.5' },
        { name: 'Stripe', isActive: true, requiresProcessing: true, processingFeePercent: '2.9' }
      ];
      
      for (const method of defaultPaymentMethods) {
        await db.insert(schema.paymentMethods).values(method);
      }
    }
    
    // Check if we have any membership tiers
    const membershipTiers = await db.select().from(schema.membershipTiers);
    
    if (membershipTiers.length === 0) {
      console.log('Initializing default membership tiers...');
      
      const defaultMembershipTiers = [
        {
          name: 'Standard',
          monthlyPrice: '29.99',
          tableRateDiscount: '10',
          foodDrinkDiscount: '5',
          guestPasses: 2,
          advanceReservationDays: 7,
          description: 'Basic membership with discounts and 2 guest passes'
        },
        {
          name: 'Premium',
          monthlyPrice: '49.99',
          tableRateDiscount: '20',
          foodDrinkDiscount: '10',
          guestPasses: 4,
          advanceReservationDays: 14,
          description: 'Enhanced membership with larger discounts and 4 guest passes'
        },
        {
          name: 'Elite',
          monthlyPrice: '99.99',
          tableRateDiscount: '30',
          foodDrinkDiscount: '15',
          guestPasses: 10,
          advanceReservationDays: 30,
          description: 'Premium membership with maximum benefits and 10 guest passes'
        }
      ];
      
      for (const tier of defaultMembershipTiers) {
        await db.insert(schema.membershipTiers).values(tier);
      }
    }
    
    // Add initial tables
    const tables = await db.select().from(schema.tables);
    
    if (tables.length === 0) {
      console.log('Initializing default tables...');
      
      const defaultTables = [
        { name: 'Table 1', type: '8ft Standard', status: 'available', hourlyRate: '12.00', posX: 50, posY: 100 },
        { name: 'Table 2', type: '8ft Standard', status: 'available', hourlyRate: '12.00', posX: 175, posY: 100 },
        { name: 'Table 3', type: '9ft Tournament', status: 'available', hourlyRate: '15.00', posX: 300, posY: 100 },
        { name: 'Table 4', type: '7ft Bar', status: 'available', hourlyRate: '10.00', posX: 50, posY: 250 },
        { name: 'Table 5', type: '7ft Bar', status: 'available', hourlyRate: '10.00', posX: 175, posY: 250 },
        { name: 'Table 6', type: 'Snooker', status: 'available', hourlyRate: '18.00', posX: 300, posY: 250 }
      ];
      
      for (const table of defaultTables) {
        await db.insert(schema.tables).values(table);
      }
    }
    
    // Initialize default layout config
    const layoutConfigs = await db.select().from(schema.layoutConfig);
    
    if (layoutConfigs.length === 0) {
      console.log('Initializing default layout configuration...');
      
      await db.insert(schema.layoutConfig).values({
        name: 'Default Layout',
        tableSize: 65,
        canvasWidth: 800,
        enableMultiPage: false,
        currentPage: 0,
        isDefault: true
      });
    }
    
    console.log('Database initialization completed');
  } catch (error) {
    console.error('Error initializing default data:', error);
    throw error;
  }
}