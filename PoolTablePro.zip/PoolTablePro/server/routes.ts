import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { db } from "./db";
import * as schema from "../shared/schema";
import { eq, desc } from "drizzle-orm";
import Stripe from "stripe";
import inventoryRoutes from "./inventory-routes";
import { 
  insertTableSchema, 
  insertTableUsageSchema, 
  insertTableSessionCustomerSchema,
  insertReservationSchema, 
  insertTransactionSchema, 
  insertMembershipTierSchema,
  insertSpecialRateSchema,
  // POS schemas
  insertInventoryCategorySchema,
  insertInventoryItemSchema,
  insertPosOrderSchema,
  insertPosOrderItemSchema,
  insertShiftRecordSchema,
  insertPaymentMethodSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Stripe
  if (!process.env.STRIPE_SECRET_KEY) {
    console.error("Missing Stripe secret key - payments will not work");
  }
  
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
    apiVersion: "2023-10-16" as any,
  });
  
  // Setup authentication routes
  setupAuth(app);
  
  // Setup inventory routes
  app.use('/api/inventory', inventoryRoutes);

  // ===== TABLES =====
  // Get all tables with their current usage and reservation info
  app.get("/api/tables", async (req, res) => {
    try {
      const tables = await storage.getAllTables();
      res.json(tables);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new table
  app.post("/api/tables", async (req, res) => {
    try {
      const validatedData = insertTableSchema.parse(req.body);
      const table = await storage.createTable(validatedData);
      res.status(201).json(table);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update table status
  app.patch("/api/tables/:id/status", async (req, res) => {
    try {
      const tableId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!["available", "in-use", "reserved", "maintenance"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const table = await storage.updateTableStatus(tableId, status);
      res.json(table);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });
  
  // Update table position
  app.patch("/api/tables/:id/position", async (req, res) => {
    try {
      const tableId = parseInt(req.params.id);
      const { posX, posY } = req.body;
      
      // Get the current table
      const table = await storage.getTable(tableId);
      if (!table) {
        return res.status(404).json({ message: "Table not found" });
      }
      
      // Update with new position
      const updatedTable = await storage.updateTable(tableId, {
        ...table,
        posX,
        posY
      });
      
      res.json(updatedTable);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== TABLE USAGE =====
  // Start a new table session
  app.post("/api/table-usage", async (req, res) => {
    try {
      const { tableId, primaryUserId } = req.body;
      
      // Check if table exists and is available
      const table = await storage.getTable(tableId);
      if (!table) {
        return res.status(404).json({ message: "Table not found" });
      }
      
      if (table.status !== "available" && table.status !== "reserved") {
        return res.status(400).json({ message: "Table is not available" });
      }
      
      // Generate a unique session ID to maintain consistency across server restarts
      const sessionId = `table_${tableId}_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
      console.log(`[DEBUG-SESSION] Generated new session ID: ${sessionId}`);
      
      // Create new table usage entry with the session ID
      const tableUsage = await storage.createTableUsage({
        tableId,
        primaryUserId,
        sessionId, // Add the unique session ID
        startTime: new Date(),
        status: "active"
      });
      
      // Update table status to in-use
      await storage.updateTableStatus(tableId, "in-use");
      
      res.status(201).json(tableUsage);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update a table usage entry
  app.patch("/api/table-usage/:id", async (req, res) => {
    try {
      const usageId = parseInt(req.params.id);
      const updateData = req.body;
      
      // Get current usage
      const usage = await storage.getTableUsage(usageId);
      if (!usage) {
        return res.status(404).json({ message: "Table usage not found" });
      }
      
      // If we're ending a session
      if (updateData.status === "completed" && usage.status === "active") {
        const endTime = new Date(updateData.endTime || new Date());
        const durationInMs = endTime.getTime() - new Date(usage.startTime).getTime();
        const durationInHours = durationInMs / (1000 * 60 * 60);
        
        // Get table rate
        const table = await storage.getTable(usage.tableId);
        if (!table) {
          return res.status(404).json({ message: "Table not found" });
        }
        
        // Check for applicable special rates
        let amount = updateData.amount;
        let appliedRateDescription = "";
        
        if (!amount) {
          // Calculate the base amount using hourly rate
          const baseAmount = durationInHours * Number(table.hourlyRate);
          amount = baseAmount;
          
          // Special rates are currently disabled per user request
          // We will implement proper special rate configuration in the future
          
          // The code below is kept for reference but commented out
          /*
          try {
            // Check for special rates across the session duration
            // For simplicity, we'll check the rate at the end time
            const applicableRate = await storage.getApplicableSpecialRate(endTime);
            
            if (applicableRate) {
              if (applicableRate.flatRate) {
                // If it's a flat rate, use that directly
                amount = durationInHours * Number(applicableRate.flatRate);
                appliedRateDescription = `${applicableRate.name} (Flat rate: $${applicableRate.flatRate}/hr)`;
              } else if (applicableRate.discountPercent) {
                // If it's a percentage discount, apply it
                const discountMultiplier = 1 - (Number(applicableRate.discountPercent) / 100);
                amount = baseAmount * discountMultiplier;
                appliedRateDescription = `${applicableRate.name} (${applicableRate.discountPercent}% off)`;
              }
            }
          } catch (error) {
            console.error("Error checking for special rates:", error);
            // Continue with base amount if there's an error
          }
          */
        }
        
        // Update the usage record
        const updatedUsage = await storage.updateTableUsage(usageId, {
          endTime,
          duration: durationInHours.toString(), // Convert to string for decimal storage
          amount,
          status: "completed"
        });
        
        // Update table status to available
        await storage.updateTableStatus(usage.tableId, "available");
        
        // Create transaction record
        if (amount > 0) {
          await storage.createTransaction({
            userId: usage.primaryUserId,
            amount,
            type: "table-session",
            description: `${table.name} session (${durationInHours.toFixed(2)} hours)${appliedRateDescription ? ` - ${appliedRateDescription}` : ''}`,
            relatedTableUsageId: usageId
          });
        }
        
        res.json(updatedUsage);
      } else {
        // For other updates
        const updatedUsage = await storage.updateTableUsage(usageId, updateData);
        res.json(updatedUsage);
      }
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Get active table sessions
  app.get("/api/table-usage/active", async (req, res) => {
    try {
      console.log("[DEBUG-ACTIVE-USAGES] Fetching all active table usages");
      const activeSessions = await storage.getActiveTableUsages();
      
      console.log(`[DEBUG-ACTIVE-USAGES] Found ${activeSessions.length} active table usages`);
      for (const usage of activeSessions) {
        console.log(`[DEBUG-ACTIVE-USAGES] Table Usage ID: ${usage.id}, Table ID: ${usage.tableId}, Status: ${usage.status}, Started: ${usage.startTime}`);
        
        // Fetch the table for each usage to provide more context
        try {
          const table = await storage.getTable(usage.tableId);
          console.log(`[DEBUG-ACTIVE-USAGES] Table ID: ${usage.tableId}, Table Name: ${table ? table.name : 'Unknown'}`);
        } catch (tableError) {
          console.error(`[DEBUG-ACTIVE-USAGES] Error fetching table for usage ${usage.id}:`, tableError);
        }
        
        // Fetch customers for this table usage
        try {
          const customers = await storage.getTableSessionCustomersByTableUsage(usage.id);
          console.log(`[DEBUG-ACTIVE-USAGES] Table Usage ${usage.id} has ${customers.length} customers`);
          for (const customer of customers) {
            console.log(`[DEBUG-ACTIVE-USAGES] - Customer: ${customer.customerName}, WalkIn: ${customer.isWalkIn}, User ID: ${customer.userId || 'N/A'}`);
          }
        } catch (customerError) {
          console.error(`[DEBUG-ACTIVE-USAGES] Error fetching customers for usage ${usage.id}:`, customerError);
        }
      }
      
      res.json(activeSessions);
    } catch (error: any) {
      console.error("[DEBUG-ACTIVE-USAGES] Error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get specific table usage by ID
  app.get("/api/table-usage/:id", async (req, res) => {
    try {
      const tableUsageId = parseInt(req.params.id);
      const tableUsage = await storage.getTableUsage(tableUsageId);
      
      if (!tableUsage) {
        return res.status(404).json({ message: "Table usage not found" });
      }
      
      res.json(tableUsage);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Primary checkout endpoint - used by both the checkout and debug checkout pages
  // This is the more flexible and reliable checkout endpoint, prefer using this over
  // the older /api/table-usage/:id/checkout endpoint
  app.post("/api/checkout", async (req, res) => {
    try {
      console.log(`[CHECKOUT-API] Checkout initiated`);
      const { tableUsageId, paymentMethod, timeCharge, orderTotal, totalAmount, actualPaymentAmount, customerId } = req.body;
      console.log(`[CHECKOUT-API] Table Usage ID: ${tableUsageId}`);
      console.log(`[CHECKOUT-API] Payment Method: ${paymentMethod}`);
      console.log(`[CHECKOUT-API] Time Charge: ${timeCharge}`);
      console.log(`[CHECKOUT-API] Order Total: ${orderTotal}`);
      console.log(`[CHECKOUT-API] Total Amount: ${totalAmount}`);
      console.log(`[CHECKOUT-API] Actual Payment Amount: ${actualPaymentAmount}`);
      console.log(`[CHECKOUT-API] Customer ID: ${customerId}`);
      
      // Get the table usage
      const tableUsage = await storage.getTableUsage(parseInt(tableUsageId));
      console.log(`[CHECKOUT-API] Table usage found:`, tableUsage);
      
      if (!tableUsage) {
        console.log(`[CHECKOUT-API] Table usage not found for ID: ${tableUsageId}`);
        return res.status(404).json({ message: "Table usage not found" });
      }
      
      // Check if the table usage is already completed
      if (tableUsage.status === "completed") {
        console.log(`[CHECKOUT-API] Table usage ${tableUsageId} already completed`);
        return res.json({
          success: true,
          message: "This table session has already been checked out"
        });
      }
      
      // Get the table
      const table = await storage.getTable(tableUsage.tableId);
      console.log(`[CHECKOUT-API] Table found:`, table);
      
      if (!table) {
        console.log(`[CHECKOUT-API] Table not found for ID: ${tableUsage.tableId}`);
        return res.status(404).json({ message: "Table not found" });
      }
      
      // Get all orders for this table usage
      const orders = await storage.getOrdersByTableUsage(parseInt(tableUsageId));
      console.log(`[CHECKOUT-API] Found ${orders.length} orders for table usage ID: ${tableUsageId}`);
      
      // Calculate time duration
      const startTime = new Date(tableUsage.startTime);
      const endTime = new Date();
      const durationMs = endTime.getTime() - startTime.getTime();
      const durationHours = durationMs / (1000 * 60 * 60);
      
      // Calculate time charge
      const hourlyRate = parseFloat(table.hourlyRate || "10.00");
      const calculatedTimeCharge = parseFloat((durationHours * hourlyRate).toFixed(2));
      console.log(`[CHECKOUT-API] Duration: ${durationHours.toFixed(2)} hours, Rate: $${hourlyRate}/hr, Time charge: $${calculatedTimeCharge}`);
      
      // Calculate order total from all orders
      let calculatedOrderTotal = 0;
      for (const order of orders) {
        calculatedOrderTotal += parseFloat(order.totalAmount || "0");
      }
      console.log(`[CHECKOUT-API] Calculated order total: $${calculatedOrderTotal.toFixed(2)}`);
      
      // Create a transaction record
      const transactionData = {
        type: "checkout",
        amount: actualPaymentAmount || totalAmount || (calculatedTimeCharge + calculatedOrderTotal),
        description: `Checkout for ${table.name} - ${durationHours.toFixed(2)} hours, ${orders.length} orders`,
        tableId: table.id,
        tableUsageId: parseInt(tableUsageId),
        userId: customerId || null,
        paymentMethod: paymentMethod || "cash",
        timeCharge: timeCharge || calculatedTimeCharge,
        orderAmount: orderTotal || calculatedOrderTotal,
        status: "completed"
      };
      
      console.log(`[CHECKOUT-API] Creating transaction with data:`, transactionData);
      const transaction = await storage.createTransaction(transactionData);
      console.log(`[CHECKOUT-API] Transaction created:`, transaction);
      
      // Update order payment status
      for (const order of orders) {
        await storage.updatePosOrderStatus(order.id, "paid");
        console.log(`[CHECKOUT-API] Updated order ${order.id} status to paid`);
      }
      
      // Update table usage status
      const updatedTableUsage = await storage.updateTableUsage(parseInt(tableUsageId), {
        status: "completed",
        endTime: new Date(),
        paymentMethod: paymentMethod || "cash"
      });
      console.log(`[CHECKOUT-API] Updated table usage ${tableUsageId} to completed`);
      
      // Update table status
      await storage.updateTableStatus(table.id, "available");
      console.log(`[CHECKOUT-API] Updated table ${table.id} status to available`);
      
      res.json({
        success: true,
        transaction,
        tableUsage: updatedTableUsage
      });
    } catch (error: any) {
      console.error(`[CHECKOUT-API] Error:`, error);
      res.status(500).json({ message: error.message });
    }
  });

  // Standard Checkout a table session
  app.post("/api/table-usage/:id/checkout", async (req, res) => {
    try {
      console.log(`[DEBUG-CHECKOUT-API] Checkout requested for table usage ID: ${req.params.id}`);
      const tableUsageId = parseInt(req.params.id);
      const { paymentMethod, savePaymentInfo } = req.body;
      console.log(`[DEBUG-CHECKOUT-API] Payment method: ${paymentMethod}, Save payment info: ${savePaymentInfo}`);
      
      // Get the table usage
      const tableUsage = await storage.getTableUsage(tableUsageId);
      console.log(`[DEBUG-CHECKOUT-API] Table usage found:`, tableUsage);
      
      if (!tableUsage) {
        console.log(`[DEBUG-CHECKOUT-API] Table usage not found for ID: ${tableUsageId}`);
        return res.status(404).json({ message: "Table usage not found" });
      }
      
      // Check if the table usage is already completed
      if (tableUsage.status === "completed") {
        console.log(`[DEBUG-CHECKOUT-API] Table usage ${tableUsageId} already completed`);
        return res.json({
          success: true,
          alreadyCompleted: true,
          message: "This table session has already been checked out.",
          tableUsage: tableUsage
        });
      }
      
      // Get the table
      const table = await storage.getTable(tableUsage.tableId);
      if (!table) {
        return res.status(404).json({ message: "Table not found" });
      }
      
      // Calculate end time and duration
      const endTime = new Date();
      const startTime = new Date(tableUsage.startTime);
      const durationInMs = endTime.getTime() - startTime.getTime();
      const durationInHours = durationInMs / (1000 * 60 * 60);
      
      // Calculate the base amount using hourly rate
      const timeCharge = durationInHours * Number(table.hourlyRate);
      
      // Get order items for this table usage to include in the final amount
      let orderTotal = 0;
      try {
        const orders = await storage.getOrdersByTableUsage(tableUsageId);
        console.log(`[DEBUG-CHECKOUT-API] Found ${orders.length} orders for table usage ${tableUsageId}`, orders);
        
        if (orders && orders.length > 0) {
          // Calculate the total from all orders
          for (const order of orders) {
            // The field is called totalAmount in the schema, not amount
            if (order.totalAmount) {
              console.log(`[DEBUG-CHECKOUT-API] Processing order ${order.id}, totalAmount:`, order.totalAmount);
              
              // Parse the decimal string to a number
              const orderAmount = Number(order.totalAmount);
              console.log(`[DEBUG-CHECKOUT-API] Order ${order.id} amount parsed to number:`, orderAmount);
              
              if (!isNaN(orderAmount)) {
                orderTotal += orderAmount;
                console.log(`[DEBUG-CHECKOUT-API] Running order total: ${orderTotal}`);
              } else {
                console.error(`[DEBUG-CHECKOUT-API] Invalid order amount: ${order.totalAmount}`);
              }
            } else {
              console.error(`[DEBUG-CHECKOUT-API] Order ${order.id} has no totalAmount field`);
            }
          }
        }
      } catch (error) {
        console.error("Error fetching order data:", error);
        // Continue with checkout even if orders can't be fetched
      }
      
      console.log(`[DEBUG-CHECKOUT-API] Final order total: ${orderTotal}, Time charge: ${timeCharge}`);
      
      // Total amount to charge
      const totalAmount = timeCharge + orderTotal;
      
      // Update the table usage record
      const updatedUsage = await storage.updateTableUsage(tableUsageId, {
        endTime,
        duration: durationInHours.toString(),
        amount: totalAmount.toString(), // Convert to string as expected by schema
        status: "completed",
        paymentMethod
      });
      
      // Update table status to available
      await storage.updateTableStatus(tableUsage.tableId, "available");
      
      // Create a transaction record for the table session
      if (timeCharge > 0) {
        await storage.createTransaction({
          userId: tableUsage.primaryUserId,
          amount: timeCharge.toString(), // Convert to string as expected by schema
          type: "table-session",
          description: `${table.name} session (${durationInHours.toFixed(2)} hours)`,
          relatedTableUsageId: tableUsageId,
          paymentMethod
        });
      }
      
      // If we have order items, create a transaction for those too
      if (orderTotal > 0) {
        await storage.createTransaction({
          userId: tableUsage.primaryUserId,
          amount: orderTotal.toString(), // Convert to string as expected by schema
          type: "food-drink",
          description: `Food & Drink (${table.name})`,
          relatedTableUsageId: tableUsageId,
          paymentMethod
        });
      }
      
      res.json({
        success: true,
        tableUsage: updatedUsage,
        timeCharge,
        orderTotal,
        totalAmount
      });
    } catch (error: any) {
      console.error("Checkout error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // ===== TABLE SESSION CUSTOMERS =====
  // Get all table session customers
  app.get("/api/table-session-customers", async (req, res) => {
    try {
      // This is used to get all customers including walk-in customers
      const { tableUsageId } = req.query;
      
      if (tableUsageId) {
        // If tableUsageId is provided, get customers for that specific usage
        const customers = await storage.getTableSessionCustomersByTableUsage(parseInt(tableUsageId as string));
        console.log(`Found ${customers.length} customers for table usage ${tableUsageId}`);
        res.json(customers);
      } else {
        // Get ALL table session customers from storage, not just those in active usages
        // In a real app with a large database, you would add pagination here
        
        // Method 1: Get all actual walk-in customer records
        const tableUsages = await storage.getAllTableUsages();
        const allCustomers = [];
        
        // For each usage, get the customers
        for (const usage of tableUsages) {
          const customers = await storage.getTableSessionCustomersByTableUsage(usage.id);
          if (customers && customers.length > 0) {
            console.log(`Found ${customers.length} customers for table usage ${usage.id}`);
            allCustomers.push(...customers);
          }
        }
        
        console.log(`Returning ${allCustomers.length} total walk-in customers`);
        res.json(allCustomers);
      }
    } catch (error: any) {
      console.error("Error fetching table session customers:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get customers for a specific table usage
  app.get("/api/table-session-customers/:tableUsageId", async (req, res) => {
    try {
      const tableUsageId = parseInt(req.params.tableUsageId);
      const customers = await storage.getTableSessionCustomersByTableUsage(tableUsageId);
      res.json(customers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Add a customer to table session
  app.post("/api/table-session-customers", async (req, res) => {
    try {
      const validatedData = insertTableSessionCustomerSchema.parse(req.body);
      
      // Check if table usage exists
      const tableUsage = await storage.getTableUsage(validatedData.tableUsageId);
      if (!tableUsage) {
        return res.status(404).json({ message: "Table usage not found" });
      }
      
      // Make sure isWalkIn is explicitly set
      if (validatedData.isWalkIn === undefined) {
        // If there's a customerName but no userId, it's a walk-in
        validatedData.isWalkIn = validatedData.customerName && !validatedData.userId;
      }

      // Make sure to set customerName for non-walk-ins if it's not provided
      if (!validatedData.isWalkIn && validatedData.userId && !validatedData.customerName) {
        // Get user to set proper name
        const user = await storage.getUser(validatedData.userId);
        if (user) {
          validatedData.customerName = user.fullName;
        }
      }
      
      const customer = await storage.addTableSessionCustomer(validatedData);
      
      // Update customer count on table usage if needed
      const existingCustomers = await storage.getTableSessionCustomersByTableUsage(validatedData.tableUsageId);
      await storage.updateTableUsage(validatedData.tableUsageId, {
        customerCount: existingCustomers.length
      });
      
      res.status(201).json(customer);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Remove a customer from table session
  app.delete("/api/table-session-customers/:id", async (req, res) => {
    try {
      const customerId = parseInt(req.params.id);
      
      // Get the customer to find its table usage
      const customer = await storage.getTableSessionCustomer(customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const tableUsageId = customer.tableUsageId;
      
      // Remove the customer
      await storage.removeTableSessionCustomer(customerId);
      
      // Update customer count on table usage
      const remainingCustomers = await storage.getTableSessionCustomersByTableUsage(tableUsageId);
      await storage.updateTableUsage(tableUsageId, {
        customerCount: remainingCustomers.length
      });
      
      res.status(200).json({ message: "Customer removed successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== RESERVATIONS =====
  // Get all reservations
  app.get("/api/reservations", async (req, res) => {
    try {
      const reservations = await storage.getAllReservations();
      res.json(reservations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get upcoming reservations
  app.get("/api/reservations/upcoming", async (req, res) => {
    try {
      const upcomingReservations = await storage.getUpcomingReservations();
      res.json(upcomingReservations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new reservation
  app.post("/api/reservations", async (req, res) => {
    try {
      const validatedData = insertReservationSchema.parse(req.body);
      
      // Check if table exists
      const table = await storage.getTable(validatedData.tableId);
      if (!table) {
        return res.status(404).json({ message: "Table not found" });
      }
      
      // Check if the table is already reserved for this time slot
      const conflictingReservations = await storage.checkReservationConflict(
        validatedData.tableId,
        validatedData.startTime,
        validatedData.endTime
      );
      
      if (conflictingReservations.length > 0) {
        return res.status(409).json({ 
          message: "Table already reserved for this time slot",
          conflicts: conflictingReservations
        });
      }
      
      const reservation = await storage.createReservation(validatedData);
      
      // If reservation is for now, update table status
      const now = new Date();
      const startTime = new Date(validatedData.startTime);
      const endTime = new Date(validatedData.endTime);
      
      if (now >= startTime && now <= endTime) {
        await storage.updateTableStatus(validatedData.tableId, "reserved");
      }
      
      res.status(201).json(reservation);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update reservation status
  app.patch("/api/reservations/:id/status", async (req, res) => {
    try {
      const reservationId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!["confirmed", "cancelled", "completed", "no-show"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const reservation = await storage.getReservation(reservationId);
      if (!reservation) {
        return res.status(404).json({ message: "Reservation not found" });
      }
      
      const updatedReservation = await storage.updateReservationStatus(reservationId, status);
      
      // If cancelling or completing, update table status if needed
      if ((status === "cancelled" || status === "completed" || status === "no-show") && 
          reservation.status === "confirmed") {
        const table = await storage.getTable(reservation.tableId);
        if (table && table.status === "reserved") {
          await storage.updateTableStatus(reservation.tableId, "available");
        }
      }
      
      res.json(updatedReservation);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== MEMBERS =====
  // Get all members and walk-in customers
  app.get("/api/members", async (req, res) => {
    try {
      // Get registered members
      const members = await storage.getAllMembers();
      
      // Get ALL walk-in customers to include them in the dropdown
      const walkInCustomers = [];
      
      // Get ALL table usages and their customers, not just active ones
      const tableUsages = await storage.getAllTableUsages();
      
      console.log("All table session customers:", JSON.stringify(await storage.getAllTableSessionCustomers()));
      
      // For each usage, get its customers
      for (const usage of tableUsages) {
        const tableCustomers = await storage.getTableSessionCustomersByTableUsage(usage.id);
        
        // Only include walk-in customers (set isWalkIn explicitly if missing)
        const walkIns = tableCustomers.filter(c => {
          // Ensure c.isWalkIn is set to true if it's undefined
          if (c.isWalkIn === undefined) {
            c.isWalkIn = true;
          }
          return c.customerName && c.isWalkIn;
        });
        
        // Convert walk-in customers to a member-like format for the dropdown
        const walkInAsMembers = walkIns.map(customer => ({
          id: `walkin-${customer.id}`, // Use a prefix to distinguish from real members
          fullName: `${customer.customerName} (Walk-in)`,
          username: customer.customerName,
          isWalkIn: true,
          tableSessionCustomerId: customer.id
        }));
        
        walkInCustomers.push(...walkInAsMembers);
      }
      
      console.log("All table session customers:", JSON.stringify(walkInCustomers));
      
      // Create a unique set of walk-in customers by name
      const uniqueWalkIns = [];
      const walkInNames = new Set();
      
      for (const customer of walkInCustomers) {
        if (!walkInNames.has(customer.username)) {
          walkInNames.add(customer.username);
          uniqueWalkIns.push(customer);
        }
      }
      
      // Combine members and walk-ins
      res.json([...members, ...uniqueWalkIns]);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new member (beyond /api/register)
  app.post("/api/members", async (req, res) => {
    try {
      // Password is handled via register route, but for direct member creation
      // with admin privileges we use this route
      const validatedData = req.body;
      
      // Only check for existing username if one is provided
      if (validatedData.username) {
        const existingUser = await storage.getUserByUsername(validatedData.username);
        if (existingUser) {
          return res.status(400).json({ message: "Username already exists" });
        }
      }
      
      const member = await storage.createUser(validatedData);
      res.status(201).json(member);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Get membership stats
  app.get("/api/members/stats", async (req, res) => {
    try {
      // For now we'll return mock stats until we implement real calculations
      res.json({
        totalMembers: 146,
        activeMembers: 128,
        monthlyRevenue: 3842,
        retentionRate: 92,
        newMembersThisMonth: 12,
        expiringMemberships: 3,
        monthlyRevenueChange: 8.2,
        retentionRateChange: 3
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get membership tiers
  app.get("/api/members/tiers", async (req, res) => {
    try {
      const tiers = await storage.getAllMembershipTiers();
      res.json(tiers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a membership tier
  app.post("/api/members/tiers", async (req, res) => {
    try {
      const validatedData = insertMembershipTierSchema.parse(req.body);
      const tier = await storage.createMembershipTier(validatedData);
      res.status(201).json(tier);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== TRANSACTIONS =====
  // Get all transactions
  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getAllTransactions();
      res.json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get recent transactions
  app.get("/api/transactions/recent", async (req, res) => {
    try {
      const recentTransactions = await storage.getRecentTransactions();
      res.json(recentTransactions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new transaction
  app.post("/api/transactions", async (req, res) => {
    try {
      const validatedData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(validatedData);
      res.status(201).json(transaction);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== SPECIAL RATES =====
  // Get all special rates
  app.get("/api/special-rates", async (req, res) => {
    try {
      const rates = await storage.getAllSpecialRates();
      res.json(rates);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get active special rates
  app.get("/api/special-rates/active", async (req, res) => {
    try {
      const activeRates = await storage.getActiveSpecialRates();
      res.json(activeRates);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new special rate
  app.post("/api/special-rates", async (req, res) => {
    try {
      const validatedData = insertSpecialRateSchema.parse(req.body);
      const rate = await storage.createSpecialRate(validatedData);
      res.status(201).json(rate);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update a special rate
  app.patch("/api/special-rates/:id", async (req, res) => {
    try {
      const rateId = parseInt(req.params.id);
      
      // Make sure the rate exists
      const rate = await storage.getSpecialRate(rateId);
      if (!rate) {
        return res.status(404).json({ message: "Special rate not found" });
      }
      
      // Update the rate
      const updatedRate = await storage.updateSpecialRate(rateId, req.body);
      res.json(updatedRate);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Get applicable special rate for a specific time
  app.get("/api/special-rates/applicable", async (req, res) => {
    try {
      // Special rates are currently disabled per user request
      // We will implement proper special rate configuration in the future
      
      // Return a 404 to indicate that no special rates are applicable
      return res.status(404).json({ 
        message: "Special rates are currently disabled" 
      });
      
      /* 
      // Original code kept for reference but commented out
      const { timestamp } = req.query;
      const time = timestamp ? new Date(timestamp as string) : new Date();
      
      const applicableRate = await storage.getApplicableSpecialRate(time);
      if (!applicableRate) {
        return res.status(404).json({ message: "No applicable rate found for the specified time" });
      }
      
      res.json(applicableRate);
      */
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== POS SYSTEM - INVENTORY CATEGORIES =====
  // Get all inventory categories
  app.get("/api/pos/inventory-categories", async (req, res) => {
    try {
      const categories = await storage.getAllInventoryCategories();
      res.json(categories);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new inventory category
  app.post("/api/pos/inventory-categories", async (req, res) => {
    try {
      const validatedData = insertInventoryCategorySchema.parse(req.body);
      const category = await storage.createInventoryCategory(validatedData);
      res.status(201).json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update an inventory category
  app.patch("/api/pos/inventory-categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      const category = await storage.getInventoryCategory(categoryId);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      const updatedCategory = await storage.updateInventoryCategory(categoryId, req.body);
      res.json(updatedCategory);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== POS SYSTEM - INVENTORY ITEMS =====
  // Get all inventory items
  app.get("/api/pos/inventory-items", async (req, res) => {
    try {
      const items = await storage.getAllInventoryItems();
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get inventory items by category
  app.get("/api/pos/inventory-items/category/:categoryId", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.categoryId);
      const items = await storage.getInventoryItemsByCategory(categoryId);
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Search inventory items
  app.get("/api/pos/inventory-items/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const items = await storage.searchInventoryItems(query);
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new inventory item
  app.post("/api/pos/inventory-items", async (req, res) => {
    try {
      const validatedData = insertInventoryItemSchema.parse(req.body);
      const item = await storage.createInventoryItem(validatedData);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update an inventory item
  app.patch("/api/pos/inventory-items/:id", async (req, res) => {
    try {
      const itemId = parseInt(req.params.id);
      const item = await storage.getInventoryItem(itemId);
      
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      const updatedItem = await storage.updateInventoryItem(itemId, req.body);
      res.json(updatedItem);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update inventory stock
  app.patch("/api/pos/inventory-items/:id/stock", async (req, res) => {
    try {
      const itemId = parseInt(req.params.id);
      const { quantityChange } = req.body;
      
      if (typeof quantityChange !== 'number') {
        return res.status(400).json({ message: "Quantity change must be a number" });
      }
      
      const updatedItem = await storage.updateInventoryStock(itemId, quantityChange);
      res.json(updatedItem);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== POS SYSTEM - ORDERS =====
  // Get a specific order
  app.get("/api/pos/orders/:id", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const order = await storage.getPosOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Get order items as well
      const items = await storage.getOrderItems(orderId);
      
      res.json({
        ...order,
        items
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get orders by user
  app.get("/api/pos/orders/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const orders = await storage.getOrdersByUser(userId);
      res.json(orders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get orders by table usage
  app.get("/api/pos/orders/table-usage/:tableUsageId", async (req, res) => {
    try {
      const tableUsageId = parseInt(req.params.tableUsageId);
      const orders = await storage.getOrdersByTableUsage(tableUsageId);
      res.json(orders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get orders by table (table usage) - alternative endpoint for the checkout page
  app.get("/api/pos/orders/table/:tableUsageId", async (req, res) => {
    try {
      const tableUsageId = parseInt(req.params.tableUsageId);
      console.log(`[DEBUG-GET-ORDERS] Fetching orders for table usage ID: ${tableUsageId}`);
      
      // First check if the table usage exists
      const tableUsage = await storage.getTableUsage(tableUsageId);
      if (!tableUsage) {
        console.log(`[DEBUG-GET-ORDERS] Table usage ID ${tableUsageId} not found!`);
        return res.status(404).json({ message: "Table usage not found" });
      }
      
      console.log(`[DEBUG-GET-ORDERS] Table usage exists:`, tableUsage);
      
      let orders = [];
      
      // First try to get orders by tableUsageId (direct relationship)
      const ordersByTableUsage = await storage.getOrdersByTableUsage(tableUsageId);
      console.log(`[DEBUG-GET-ORDERS] Found ${ordersByTableUsage.length} orders by tableUsageId: ${tableUsageId}`);
      orders = [...ordersByTableUsage];
      
      // If the table usage has a sessionId, also try to find orders with that sessionId
      if (tableUsage.sessionId) {
        console.log(`[DEBUG-GET-ORDERS] Looking for orders with sessionId: ${tableUsage.sessionId}`);
        try {
          const ordersBySessionId = await db.select()
            .from(schema.posOrders)
            .where(eq(schema.posOrders.sessionId, tableUsage.sessionId));
          
          console.log(`[DEBUG-GET-ORDERS] Found ${ordersBySessionId.length} orders by sessionId`);
          
          // Add any orders that weren't already found by tableUsageId
          for (const order of ordersBySessionId) {
            if (!orders.some(o => o.id === order.id)) {
              orders.push(order);
            }
          }
        } catch (error) {
          console.error(`[DEBUG-GET-ORDERS] Error finding orders by sessionId:`, error);
        }
      }
      
      console.log(`[DEBUG-GET-ORDERS] Total found ${orders.length} orders for table usage ${tableUsageId}`);
      
      if (orders.length === 0) {
        // Debug - let's check if any orders exist at all
        const allOrders = await db.select().from(schema.posOrders);
        console.log(`[DEBUG-GET-ORDERS] Total orders in database: ${allOrders.length}`);
        if (allOrders.length > 0) {
          console.log(`[DEBUG-GET-ORDERS] Sample order from database:`, allOrders[0]);
        }
        
        // Return empty array
        return res.json([]);
      }
      
      // For each order, get the order items with item details
      const ordersWithItems = await Promise.all(orders.map(async (order) => {
        console.log(`[DEBUG-GET-ORDERS] Processing order ${order.id} for table usage ${tableUsageId}`);
        const items = await storage.getOrderItems(order.id);
        console.log(`[DEBUG-GET-ORDERS] Order ${order.id} has ${items.length} items`);
        
        // Enhance order items with name and other details
        const enhancedItems = await Promise.all(items.map(async (item) => {
          try {
            // Get inventory item details
            const inventoryItem = await storage.getInventoryItem(item.inventoryItemId);
            console.log(`[DEBUG-GET-ORDERS] Item ${item.id} details:`, {
              inventoryItemId: item.inventoryItemId,
              inventoryName: inventoryItem?.name,
              unitPrice: item.unitPrice
            });
            
            return {
              ...item,
              name: inventoryItem?.name || 'Unknown Item',
              price: item.unitPrice // Ensure price is available for the UI
            };
          } catch (err) {
            console.error(`[DEBUG-GET-ORDERS] Error getting details for item ${item.id}:`, err);
            return {
              ...item,
              name: 'Unknown Item',
              price: item.unitPrice
            };
          }
        }));
        
        console.log(`[DEBUG-GET-ORDERS] Order ${order.id} enhanced with ${enhancedItems.length} items`);
        
        return {
          ...order,
          items: enhancedItems
        };
      }));
      
      console.log(`[DEBUG-GET-ORDERS] Returning ${ordersWithItems.length} orders with their items`);
      
      // Always return orders array (might be empty if no orders exist)
      return res.json(ordersWithItems);
    } catch (error: any) {
      console.error("Error getting orders by table usage ID:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get orders by table usage ID - supports query parameter (used by table side panel)
  app.get("/api/pos/orders/table", async (req, res) => {
    try {
      const tableUsageId = req.query.tableUsageId;
      console.log("[DEBUG] Request for orders with tableUsageId:", tableUsageId);
      
      if (!tableUsageId) {
        return res.status(400).json({ message: "tableUsageId is required" });
      }
      
      // Get orders for the table usage
      const numericTableUsageId = Number(tableUsageId);
      console.log("[DEBUG] Looking for orders with numeric tableUsageId:", numericTableUsageId);
      
      let orders = [];
      
      // First try to get orders by tableUsageId (direct relationship)
      const ordersByTableUsage = await storage.getOrdersByTableUsage(numericTableUsageId);
      console.log(`[DEBUG] Found ${ordersByTableUsage.length} orders by tableUsageId: ${numericTableUsageId}`);
      orders = [...ordersByTableUsage];
      
      // If the table usage has a sessionId, also try to find orders with that sessionId
      try {
        const tableUsage = await storage.getTableUsage(numericTableUsageId);
        if (tableUsage && tableUsage.sessionId) {
          console.log(`[DEBUG] Looking for orders with sessionId: ${tableUsage.sessionId}`);
          
          const ordersBySessionId = await db.select()
            .from(schema.posOrders)
            .where(eq(schema.posOrders.sessionId, tableUsage.sessionId));
          
          console.log(`[DEBUG] Found ${ordersBySessionId.length} orders by sessionId`);
          
          // Add any orders that weren't already found by tableUsageId
          for (const order of ordersBySessionId) {
            if (!orders.some(o => o.id === order.id)) {
              orders.push(order);
            }
          }
        }
      } catch (error) {
        console.error(`[DEBUG] Error finding orders by sessionId:`, error);
      }
      
      console.log(`[DEBUG] Total found ${orders.length} orders`);
      
      // Always return orders array (might be empty if no orders exist)
      return res.json(orders);
    } catch (error: any) {
      console.error("Error getting orders by table usage:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Get recent orders
  app.get("/api/pos/orders/recent", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const orders = await storage.getRecentOrders(limit);
      res.json(orders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new order
  app.post("/api/pos/orders", async (req, res) => {
    try {
      console.log("[DEBUG-API] Creating new POS order with data:", req.body);
      console.log("[DEBUG-API] Table usage ID:", req.body.tableUsageId);
      
      // Get session ID from table usage if available
      let sessionId = null;
      if (req.body.tableUsageId) {
        try {
          const tableUsage = await storage.getTableUsage(req.body.tableUsageId);
          if (tableUsage && tableUsage.sessionId) {
            sessionId = tableUsage.sessionId;
            console.log(`[DEBUG-API] Using session ID from table usage: ${sessionId}`);
          } else {
            console.log(`[DEBUG-API] Table usage found but no sessionId exists: ${JSON.stringify(tableUsage)}`);
          }
        } catch (error) {
          console.error(`[DEBUG-API] Error fetching table usage: ${error}`);
        }
      }
      
      // Include session ID in the order data
      const orderData = {
        ...req.body,
        sessionId
      };
      
      const validatedData = insertPosOrderSchema.parse(orderData);
      console.log("[DEBUG-API] Validated data:", validatedData);
      
      const order = await storage.createPosOrder(validatedData);
      console.log("[DEBUG-API] Order created:", order);
      
      // If order items were sent along with the order, add them
      if (req.body.items && Array.isArray(req.body.items)) {
        console.log("[DEBUG-API] Adding", req.body.items.length, "items to order", order.id);
        const orderItems = [];
        
        for (const item of req.body.items) {
          console.log("[DEBUG-API] Adding order item:", item);
          const orderItem = await storage.addOrderItem({
            ...item,
            orderId: order.id
          });
          console.log("[DEBUG-API] Order item added:", orderItem);
          orderItems.push(orderItem);
        }
        
        // Also fetch all orders for this table usage to verify
        const allOrders = await storage.getOrdersByTableUsage(req.body.tableUsageId);
        console.log(`[DEBUG-API] After adding: Table ${req.body.tableUsageId} has ${allOrders.length} orders`);
        
        return res.status(201).json({
          ...order,
          items: orderItems
        });
      }
      
      res.status(201).json(order);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update order status
  app.patch("/api/pos/orders/:id/status", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!["pending", "processing", "paid", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const updatedOrder = await storage.updatePosOrderStatus(orderId, status);
      res.json(updatedOrder);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== POS SYSTEM - ORDER ITEMS =====
  // Get order items
  app.get("/api/pos/order-items/:orderId", async (req, res) => {
    try {
      const orderId = parseInt(req.params.orderId);
      const items = await storage.getOrderItems(orderId);
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Add an item to an order
  app.post("/api/pos/order-items", async (req, res) => {
    try {
      const validatedData = insertPosOrderItemSchema.parse(req.body);
      const item = await storage.addOrderItem(validatedData);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Remove an item from an order
  app.delete("/api/pos/order-items/:id", async (req, res) => {
    try {
      const itemId = parseInt(req.params.id);
      await storage.removeOrderItem(itemId);
      res.status(204).end();
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update order item quantity
  app.patch("/api/pos/order-items/:id/quantity", async (req, res) => {
    try {
      const itemId = parseInt(req.params.id);
      const { quantity } = req.body;
      
      if (typeof quantity !== 'number' || quantity < 1) {
        return res.status(400).json({ message: "Quantity must be a positive number" });
      }
      
      const updatedItem = await storage.updateOrderItemQuantity(itemId, quantity);
      res.json(updatedItem);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== POS SYSTEM - SHIFT RECORDS =====
  // Get current staff shift
  app.get("/api/pos/shifts/current/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const shift = await storage.getCurrentShift(userId);
      
      if (!shift) {
        return res.status(404).json({ message: "No active shift found" });
      }
      
      res.json(shift);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get shift history
  app.get("/api/pos/shifts/history", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const shifts = await storage.getShiftHistory(userId);
      res.json(shifts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Start a new shift
  app.post("/api/pos/shifts/start", async (req, res) => {
    try {
      const validatedData = insertShiftRecordSchema.parse(req.body);
      const shift = await storage.startShift(validatedData);
      res.status(201).json(shift);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // End a shift
  app.patch("/api/pos/shifts/:id/end", async (req, res) => {
    try {
      const shiftId = parseInt(req.params.id);
      const { endAmount } = req.body;
      
      if (typeof endAmount !== 'number') {
        return res.status(400).json({ message: "End amount must be a number" });
      }
      
      const shift = await storage.endShift(shiftId, endAmount);
      res.json(shift);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== POS SYSTEM - PAYMENT METHODS =====
  // Get all payment methods
  app.get("/api/pos/payment-methods", async (req, res) => {
    try {
      const methods = await storage.getAllPaymentMethods();
      res.json(methods);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get active payment methods
  app.get("/api/pos/payment-methods/active", async (req, res) => {
    try {
      const methods = await storage.getActivePaymentMethods();
      res.json(methods);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new payment method
  app.post("/api/pos/payment-methods", async (req, res) => {
    try {
      const validatedData = insertPaymentMethodSchema.parse(req.body);
      const method = await storage.createPaymentMethod(validatedData);
      res.status(201).json(method);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Update a payment method
  app.patch("/api/pos/payment-methods/:id", async (req, res) => {
    try {
      const methodId = parseInt(req.params.id);
      const method = await storage.getActivePaymentMethods();
      
      if (!method) {
        return res.status(404).json({ message: "Payment method not found" });
      }
      
      const updatedMethod = await storage.updatePaymentMethod(methodId, req.body);
      res.json(updatedMethod);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // ===== STRIPE PAYMENT INTEGRATION =====
  // Create a payment intent 
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      // If STRIPE_SECRET_KEY is not defined, respond with an error
      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ message: "Stripe secret key is not configured" });
      }
      
      const { amount } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Valid amount is required" });
      }
      
      // Import Stripe and create a new instance
      const Stripe = require('stripe');
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
      
      // Create a payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd"
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // ===== STRIPE PAYMENT INTEGRATION =====
  // Create a payment intent
  app.post("/api/pos/create-payment-intent", async (req, res) => {
    try {
      const { amount, description, tableUsageId, orderIds } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Valid amount is required" });
      }
      
      // Check if we're in development/test mode or if Stripe keys are missing
      const isDevelopmentMode = !process.env.STRIPE_SECRET_KEY || 
                               process.env.STRIPE_SECRET_KEY.includes("1") ||
                               process.env.NODE_ENV === "development";
      
      if (isDevelopmentMode) {
        console.log("Using mock payment intent for development");
        // Create a mock payment intent without calling Stripe API
        // This allows frontend to be tested without real Stripe integration
        const mockId = `mock_pi_${Date.now()}`;
        const mockSecret = `mock_seti_${Date.now()}_secret_${Math.random().toString(36).substring(2, 15)}`;
        
        res.json({ 
          clientSecret: mockSecret,
          paymentIntentId: mockId,
          mockMode: true
        });
        return;
      }
      
      try {
        // Real Stripe integration
        const paymentIntent = await stripe.paymentIntents.create({
          amount: Math.round(amount * 100), // Convert to cents
          currency: "usd",
          description: description || "Pool hall payment",
          metadata: {
            tableUsageId: tableUsageId ? tableUsageId.toString() : "",
            orderIds: orderIds ? JSON.stringify(orderIds) : ""
          }
        });
        
        res.json({ 
          clientSecret: paymentIntent.client_secret,
          paymentIntentId: paymentIntent.id,
        });
      } catch (stripeError: any) {
        console.error("Stripe API Error:", stripeError);
        res.status(502).json({ 
          message: "Payment service error", 
          error: stripeError.message 
        });
      }
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ 
        message: "Failed to create payment intent", 
        error: error.message 
      });
    }
  });
  
  // Handle successful payments
  app.post("/api/pos/payment-success", async (req, res) => {
    try {
      const { paymentIntentId, tableUsageId, orderIds, mockMode, amount: mockAmount, description: mockDescription } = req.body;
      
      let amount;
      let description;
      
      // Check if this is a mock payment from development mode
      if (mockMode) {
        console.log("Processing mock payment success");
        amount = mockAmount;
        description = mockDescription || "Mock payment";
      } else {
        // Real Stripe payment intent
        try {
          const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
          amount = (paymentIntent.amount / 100).toString(); // Convert from cents to dollars
          description = `Stripe payment: ${paymentIntent.description || 'Pool hall payment'}`;
        } catch (stripeError) {
          console.error("Error retrieving payment intent from Stripe:", stripeError);
          
          // Fallback to using the mock values provided
          if (mockAmount) {
            console.log("Using provided amount for transaction record");
            amount = mockAmount.toString();
            description = mockDescription || "Fallback payment record";
          } else {
            throw new Error("Cannot retrieve payment details and no fallback provided");
          }
        }
      }
      
      // Create transaction record
      if (amount) {
        await storage.createTransaction({
          type: 'payment',
          amount,
          relatedTableUsageId: tableUsageId ? Number(tableUsageId) : null,
          description: description || 'Pool hall payment'
        });
      }
      
      // Update order status if applicable
      if (orderIds && Array.isArray(orderIds)) {
        for (const orderId of orderIds) {
          await storage.updatePosOrderStatus(orderId, 'completed');
        }
      }
      
      // End table usage if applicable
      if (tableUsageId) {
        const tableUsage = await storage.getTableUsage(Number(tableUsageId));
        if (tableUsage) {
          await storage.updateTableUsage(tableUsage.id, {
            endTime: new Date(),
            status: 'completed'
          });
          
          // Mark table as available
          if (tableUsage.tableId) {
            await storage.updateTableStatus(tableUsage.tableId, 'available');
          }
        }
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error processing payment success:", error);
      res.status(500).json({ 
        message: "Failed to process payment completion", 
        error: error.message 
      });
    }
  });

  // ===== INVENTORY MANAGEMENT =====
  app.get("/api/inventory/items", async (req, res) => {
    try {
      // Get all items first
      const items = await storage.getAllInventoryItems();
      console.log("[DEBUG-INVENTORY] Items from database:", items);
      
      // Get all categories to create a lookup map
      const categories = await storage.getAllInventoryCategories();
      console.log("[DEBUG-INVENTORY] Categories from database:", categories);
      
      // Create a categoryId to name lookup map
      const categoryMap: Record<number, string> = {};
      categories.forEach(category => {
        categoryMap[category.id] = category.name;
      });
      
      // Transform items to include category name
      const itemsWithCategories = items.map(item => {
        // Get category name from our lookup map if available
        let categoryName = 'Unknown';
        if (item.categoryId && categoryMap[item.categoryId]) {
          categoryName = categoryMap[item.categoryId];
        }
        
        return {
          ...item,
          categoryId: item.categoryId || null,
          categoryName // Add the category name directly to the item
        };
      });
      
      console.log("[DEBUG-INVENTORY] Items with categories:", itemsWithCategories);
      
      res.json(itemsWithCategories);
    } catch (error: any) {
      console.error("[DEBUG-INVENTORY] Error fetching items:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  app.get("/api/inventory/categories", async (req, res) => {
    try {
      const categories = await storage.getAllInventoryCategories();
      console.log("[DEBUG-INVENTORY] Categories from database:", categories);
      res.json(categories);
    } catch (error: any) {
      console.error("[DEBUG-INVENTORY] Error fetching categories:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  app.get("/api/inventory/items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getInventoryItem(id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      // Get category name if a categoryId exists
      let categoryName = 'Unknown';
      if (item.categoryId) {
        const category = await storage.getInventoryCategory(item.categoryId);
        if (category) {
          categoryName = category.name;
        }
      }
      
      // Include both categoryId and categoryName in the response
      res.json({
        ...item,
        categoryId: item.categoryId || null,
        categoryName
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.get("/api/inventory/categories/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getInventoryCategory(id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.post("/api/inventory/items", async (req, res) => {
    try {
      const parsedData = insertInventoryItemSchema.parse(req.body);
      const newItem = await storage.createInventoryItem(parsedData);
      // Ensure categoryId is included in the response
      res.status(201).json({
        ...newItem,
        categoryId: newItem.categoryId || null
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });
  
  app.post("/api/inventory/categories", async (req, res) => {
    try {
      const parsedData = insertInventoryCategorySchema.parse(req.body);
      const newCategory = await storage.createInventoryCategory(parsedData);
      res.status(201).json(newCategory);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });
  
  app.patch("/api/inventory/items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingItem = await storage.getInventoryItem(id);
      
      if (!existingItem) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      const parsedData = insertInventoryItemSchema.partial().parse(req.body);
      const updatedItem = await storage.updateInventoryItem(id, parsedData);
      
      // Get category name if a categoryId exists
      let categoryName = 'Unknown';
      if (updatedItem.categoryId) {
        const category = await storage.getInventoryCategory(updatedItem.categoryId);
        if (category) {
          categoryName = category.name;
        }
      }
      
      // Ensure both categoryId and categoryName are included in the response
      res.json({
        ...updatedItem,
        categoryId: updatedItem.categoryId || null,
        categoryName
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });
  
  app.patch("/api/inventory/categories/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingCategory = await storage.getInventoryCategory(id);
      
      if (!existingCategory) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      const parsedData = insertInventoryCategorySchema.partial().parse(req.body);
      const updatedCategory = await storage.updateInventoryCategory(id, parsedData);
      res.json(updatedCategory);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });
  
  app.delete("/api/inventory/items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingItem = await storage.getInventoryItem(id);
      
      if (!existingItem) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      await storage.deleteInventoryItem(id);
      res.status(200).json({ message: "Item deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.delete("/api/inventory/categories/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingCategory = await storage.getInventoryCategory(id);
      
      if (!existingCategory) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      try {
        await storage.deleteInventoryCategory(id);
        res.status(200).json({ message: "Category deleted successfully" });
      } catch (error: any) {
        if (error.message.includes("Cannot delete category")) {
          return res.status(400).json({ message: error.message });
        }
        throw error;
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Room Features API
  app.get("/api/room-features", async (req, res) => {
    try {
      const features = await storage.getAllRoomFeatures();
      res.json(features);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/room-features", async (req, res) => {
    try {
      const { name, type, posX, posY, width, height } = req.body;
      
      if (!name || !type) {
        return res.status(400).json({ error: "Name and type are required" });
      }
      
      const feature = await storage.createRoomFeature({
        name,
        type,
        posX: posX || 0,
        posY: posY || 0,
        width: width || 100,
        height: height || 100
      });
      
      res.status(201).json(feature);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/room-features/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const feature = await storage.getRoomFeature(id);
      
      if (!feature) {
        return res.status(404).json({ error: "Room feature not found" });
      }
      
      res.json(feature);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/room-features/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { name, type, posX, posY, width, height } = req.body;
      
      const feature = await storage.getRoomFeature(id);
      if (!feature) {
        return res.status(404).json({ error: "Room feature not found" });
      }
      
      const updatedFeature = await storage.updateRoomFeature(id, {
        name,
        type,
        posX,
        posY,
        width,
        height
      });
      
      res.json(updatedFeature);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // PATCH route for updating individual properties of a room feature
  app.patch("/api/room-features/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const feature = await storage.getRoomFeature(id);
      if (!feature) {
        return res.status(404).json({ error: "Room feature not found" });
      }
      
      const updatedFeature = await storage.updateRoomFeature(id, req.body);
      res.json(updatedFeature);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/room-features/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const feature = await storage.getRoomFeature(id);
      if (!feature) {
        return res.status(404).json({ error: "Room feature not found" });
      }
      
      await storage.deleteRoomFeature(id);
      res.status(204).end();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Layout Configuration API
  app.get("/api/layout-config", async (req, res) => {
    try {
      // If an ID is provided, get that specific config
      if (req.query.id) {
        const id = parseInt(req.query.id as string);
        const config = await storage.getLayoutConfig(id);
        
        if (!config) {
          return res.status(404).json({ error: "Layout configuration not found" });
        }
        
        return res.json(config);
      }
      
      // Handle special cases
      if (req.query.default === 'true') {
        const defaultConfig = await storage.getDefaultLayoutConfig();
        if (!defaultConfig) {
          return res.status(404).json({ error: "No default layout configuration exists" });
        }
        return res.json(defaultConfig);
      }
      
      // Return the first/only layout config if no specific request
      const config = await storage.getLayoutConfig();
      if (!config) {
        return res.status(404).json({ error: "No layout configuration exists" });
      }
      
      res.json(config);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.post("/api/layout-config", async (req, res) => {
    try {
      const { name, tableSize, canvasWidth, enableMultiPage, currentPage, isDefault } = req.body;
      
      if (tableSize !== undefined && (tableSize < 10 || tableSize > 200)) {
        return res.status(400).json({ error: "Table size must be between 10 and 200" });
      }
      
      if (canvasWidth !== undefined && (canvasWidth < 200 || canvasWidth > 5000)) {
        return res.status(400).json({ error: "Canvas width must be between 200 and 5000" });
      }
      
      const config = await storage.createLayoutConfig({
        name: name || "Default Layout",
        tableSize: tableSize !== undefined ? tableSize : 65,
        canvasWidth: canvasWidth !== undefined ? canvasWidth : 800,
        enableMultiPage: enableMultiPage !== undefined ? enableMultiPage : false,
        currentPage: currentPage !== undefined ? currentPage : 0,
        isDefault: isDefault !== undefined ? isDefault : false
      });
      
      res.status(201).json(config);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.put("/api/layout-config/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { name, tableSize, canvasWidth, enableMultiPage, currentPage, isDefault } = req.body;
      
      // Validate input
      if (tableSize !== undefined && (tableSize < 10 || tableSize > 200)) {
        return res.status(400).json({ error: "Table size must be between 10 and 200" });
      }
      
      if (canvasWidth !== undefined && (canvasWidth < 200 || canvasWidth > 5000)) {
        return res.status(400).json({ error: "Canvas width must be between 200 and 5000" });
      }
      
      const config = await storage.getLayoutConfig(id);
      if (!config) {
        return res.status(404).json({ error: "Layout configuration not found" });
      }
      
      const updatedConfig = await storage.updateLayoutConfig(id, {
        name,
        tableSize,
        canvasWidth,
        enableMultiPage,
        currentPage,
        isDefault
      });
      
      res.json(updatedConfig);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.patch("/api/layout-config/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const config = await storage.getLayoutConfig(id);
      if (!config) {
        return res.status(404).json({ error: "Layout configuration not found" });
      }
      
      // Validate specific fields if they're being updated
      if (req.body.tableSize !== undefined && (req.body.tableSize < 10 || req.body.tableSize > 200)) {
        return res.status(400).json({ error: "Table size must be between 10 and 200" });
      }
      
      if (req.body.canvasWidth !== undefined && (req.body.canvasWidth < 200 || req.body.canvasWidth > 5000)) {
        return res.status(400).json({ error: "Canvas width must be between 200 and 5000" });
      }
      
      const updatedConfig = await storage.updateLayoutConfig(id, req.body);
      res.json(updatedConfig);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.delete("/api/layout-config/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const config = await storage.getLayoutConfig(id);
      if (!config) {
        return res.status(404).json({ error: "Layout configuration not found" });
      }
      
      await storage.deleteLayoutConfig(id);
      res.status(204).end();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
