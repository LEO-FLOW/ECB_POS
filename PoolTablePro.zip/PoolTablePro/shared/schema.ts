import { pgTable, text, serial, integer, boolean, timestamp, decimal, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique(), // No longer required, will be generated if not provided
  password: text("password"), // No longer required for walk-in members, only for full accounts
  fullName: text("full_name").notNull(),
  email: text("email"),
  phoneNumber: text("phone_number"), // Added phone number field
  membershipTier: text("membership_tier").default("none"),
  membershipStartDate: timestamp("membership_start_date"),
  membershipEndDate: timestamp("membership_end_date"),
  discountRate: decimal("discount_rate").default("0"),
  isStaff: boolean("is_staff").default(false),
  isWalkIn: boolean("is_walk_in").default(false), // Flag to identify converted walk-ins
  createdAt: timestamp("created_at").defaultNow(),
});

export const tables = pgTable("tables", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 7ft Bar, 8ft Standard, 9ft Tournament, Snooker
  status: text("status").notNull().default("available"), // available, in-use, reserved, maintenance
  hourlyRate: decimal("hourly_rate").notNull(),
  posX: integer("pos_x").default(0), // Position X coordinate for layout view
  posY: integer("pos_y").default(0), // Position Y coordinate for layout view
});

export const tableUsage = pgTable("table_usage", {
  id: serial("id").primaryKey(),
  tableId: integer("table_id").notNull(),
  primaryUserId: integer("primary_user_id"), // Primary customer (can be null for walk-ins)
  sessionId: text("session_id"), // Unique identifier for linking orders across server restarts
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  duration: decimal("duration"), // in hours
  amount: decimal("amount"),
  status: text("status").notNull().default("active"), // active, completed, cancelled
  notes: text("notes"),
  customerCount: integer("customer_count").default(1), // Number of customers at the table
  paymentMethod: text("payment_method"), // For tracking how the table was paid for
});

// For storing multiple customers assigned to a table session
export const tableSessionCustomers = pgTable("table_session_customers", {
  id: serial("id").primaryKey(),
  tableUsageId: integer("table_usage_id").notNull(),
  userId: integer("user_id"), // Can be null for walk-in customers
  customerName: text("customer_name"), // For walk-in customers not in the system
  isWalkIn: boolean("is_walk_in").default(false),
  addedAt: timestamp("added_at").defaultNow(),
});

export const reservations = pgTable("reservations", {
  id: serial("id").primaryKey(),
  tableId: integer("table_id").notNull(),
  userId: integer("user_id"),
  customerName: text("customer_name"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  notes: text("notes"),
  date: timestamp("date").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  status: text("status").notNull().default("confirmed"), // confirmed, cancelled, completed, no-show
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  amount: decimal("amount").notNull(),
  type: text("type").notNull(), // table-session, membership, food-drinks, other
  description: text("description"),
  relatedTableUsageId: integer("related_table_usage_id"),
  timestamp: timestamp("timestamp").defaultNow(),
  paymentMethod: text("payment_method"), // cash, credit_card, debit_card, stripe
});

export const membershipTiers = pgTable("membership_tiers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  monthlyPrice: decimal("monthly_price").notNull(),
  tableRateDiscount: decimal("table_rate_discount").notNull(),
  foodDrinkDiscount: decimal("food_drink_discount"),
  guestPasses: integer("guest_passes"),
  advanceReservationDays: integer("advance_reservation_days"),
  description: text("description"),
});

// POS System related tables
export const inventoryCategories = pgTable("inventory_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
});

export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  categoryId: integer("category_id").notNull().references(() => inventoryCategories.id),
  price: decimal("price").notNull(),
  cost: decimal("cost").notNull(),
  sku: text("sku"),
  barcode: text("barcode"),
  currentStock: integer("current_stock").default(0),
  minStockLevel: integer("min_stock_level").default(0),
  imageUrl: text("image_url"),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const posOrders = pgTable("pos_orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull(),
  userId: integer("user_id"),
  tableUsageId: integer("table_usage_id"),
  sessionId: text("session_id"), // To link with table usage session ID across server restarts
  subtotal: decimal("subtotal").notNull(),
  discountAmount: decimal("discount_amount").default("0"),
  taxAmount: decimal("tax_amount").default("0"),
  totalAmount: decimal("total_amount").notNull(),
  paymentStatus: text("payment_status").notNull().default("pending"), // pending, paid, refunded, cancelled
  paymentMethod: text("payment_method"), // cash, credit_card, debit_card, stripe
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  notes: text("notes"),
});

export const posOrderItems = pgTable("pos_order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  inventoryItemId: integer("inventory_item_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  unitPrice: decimal("unit_price").notNull(),
  totalPrice: decimal("total_price").notNull(),
  notes: text("notes"),
});

export const shiftRecords = pgTable("shift_records", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  startAmount: decimal("start_amount").notNull().default("0"),
  endAmount: decimal("end_amount"),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  notes: text("notes"),
  status: text("status").notNull().default("active"), // active, closed
});

// Define table for special rates - time-based pricing
export const specialRates = pgTable("special_rates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // e.g., "Afternoon Special", "Evening Rate", etc.
  description: text("description"),
  startTime: text("start_time").notNull(), // Format HH:MM - e.g., "12:00"
  endTime: text("end_time").notNull(), // Format HH:MM - e.g., "18:00"
  dayOfWeek: text("day_of_week"), // Optional, specific day or null for any day
  discountPercent: decimal("discount_percent").default("0"), // 10 = 10% off regular rate
  flatRate: decimal("flat_rate"), // Flat hourly rate (null if using discount)
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const paymentMethods = pgTable("payment_methods", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(), // Cash, Credit Card, Debit Card, Stripe, etc.
  isActive: boolean("is_active").default(true),
  requiresProcessing: boolean("requires_processing").default(false),
  processingFeePercent: decimal("processing_fee_percent").default("0"),
});

// For storing room features like entrance, bar area, etc.
export const roomFeatures = pgTable("room_features", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // e.g., "Entrance", "Bar Area", "Bathroom"
  posX: integer("pos_x").notNull(),
  posY: integer("pos_y").notNull(),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  type: text("type").notNull(), // Types: entrance, bar, wall, restroom, etc.
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// For storing room layout configuration
export const layoutConfig = pgTable("layout_config", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("default"), // For potential multiple layouts
  tableSize: integer("table_size").notNull().default(65), // Size as percentage or absolute value
  canvasWidth: integer("canvas_width").notNull().default(800), // Width in pixels
  enableMultiPage: boolean("enable_multi_page").notNull().default(false),
  currentPage: integer("current_page").notNull().default(0),
  isDefault: boolean("is_default").notNull().default(false), // Whether this is the default layout
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  phoneNumber: true,
  membershipTier: true,
  membershipStartDate: true,
  membershipEndDate: true,
  discountRate: true,
  isStaff: true,
  isWalkIn: true,
});

export const insertTableSchema = createInsertSchema(tables).pick({
  name: true,
  type: true,
  status: true,
  hourlyRate: true,
  posX: true,
  posY: true,
});

export const insertTableUsageSchema = createInsertSchema(tableUsage).pick({
  tableId: true,
  primaryUserId: true,
  sessionId: true,
  startTime: true,
  endTime: true,
  duration: true,
  amount: true,
  status: true,
  notes: true,
  customerCount: true,
  paymentMethod: true,
});

export const insertTableSessionCustomerSchema = createInsertSchema(tableSessionCustomers).pick({
  tableUsageId: true,
  userId: true,
  customerName: true,
  isWalkIn: true,
});

export const insertReservationSchema = createInsertSchema(reservations).pick({
  tableId: true,
  userId: true,
  customerName: true,
  contactEmail: true,
  contactPhone: true,
  notes: true,
  date: true,
  startTime: true,
  endTime: true,
  status: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  userId: true,
  amount: true,
  type: true,
  description: true,
  relatedTableUsageId: true,
  paymentMethod: true,
});

export const insertMembershipTierSchema = createInsertSchema(membershipTiers).pick({
  name: true,
  monthlyPrice: true,
  tableRateDiscount: true,
  foodDrinkDiscount: true,
  guestPasses: true,
  advanceReservationDays: true,
  description: true,
});

// POS System insert schemas
export const insertInventoryCategorySchema = createInsertSchema(inventoryCategories).pick({
  name: true,
  description: true,
});

export const insertInventoryItemSchema = createInsertSchema(inventoryItems).pick({
  name: true,
  categoryId: true,
  price: true,
  cost: true,
  sku: true,
  barcode: true,
  currentStock: true,
  minStockLevel: true,
  imageUrl: true,
  description: true,
  isActive: true,
});

export const insertPosOrderSchema = createInsertSchema(posOrders).pick({
  orderNumber: true,
  userId: true,
  tableUsageId: true,
  sessionId: true,
  subtotal: true,
  discountAmount: true,
  taxAmount: true,
  totalAmount: true,
  paymentStatus: true,
  paymentMethod: true,
  completedAt: true,
  notes: true,
});

export const insertPosOrderItemSchema = createInsertSchema(posOrderItems).pick({
  orderId: true,
  inventoryItemId: true,
  quantity: true,
  unitPrice: true,
  totalPrice: true,
  notes: true,
});

export const insertShiftRecordSchema = createInsertSchema(shiftRecords).pick({
  userId: true,
  startAmount: true,
  endAmount: true,
  startTime: true,
  endTime: true,
  notes: true,
  status: true,
});

export const insertSpecialRateSchema = createInsertSchema(specialRates).pick({
  name: true,
  description: true,
  startTime: true,
  endTime: true,
  dayOfWeek: true,
  discountPercent: true,
  flatRate: true,
  isActive: true,
});

export const insertPaymentMethodSchema = createInsertSchema(paymentMethods).pick({
  name: true,
  isActive: true,
  requiresProcessing: true,
  processingFeePercent: true,
});

export const insertRoomFeatureSchema = createInsertSchema(roomFeatures).pick({
  name: true,
  posX: true,
  posY: true,
  width: true,
  height: true,
  type: true,
});

export const insertLayoutConfigSchema = createInsertSchema(layoutConfig).pick({
  name: true,
  tableSize: true,
  canvasWidth: true,
  enableMultiPage: true,
  currentPage: true,
  isDefault: true,
});

// Define relations between items and categories
export const inventoryItemsRelations = relations(inventoryItems, ({ one }) => ({
  category: one(inventoryCategories, {
    fields: [inventoryItems.categoryId],
    references: [inventoryCategories.id]
  })
}));

export const inventoryCategoriesRelations = relations(inventoryCategories, ({ many }) => ({
  items: many(inventoryItems)
}));

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Table = typeof tables.$inferSelect;
export type InsertTable = z.infer<typeof insertTableSchema>;

export type TableUsage = typeof tableUsage.$inferSelect;
export type InsertTableUsage = z.infer<typeof insertTableUsageSchema>;

export type TableSessionCustomer = typeof tableSessionCustomers.$inferSelect;
export type InsertTableSessionCustomer = z.infer<typeof insertTableSessionCustomerSchema>;

export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = z.infer<typeof insertReservationSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type MembershipTier = typeof membershipTiers.$inferSelect;
export type InsertMembershipTier = z.infer<typeof insertMembershipTierSchema>;

// POS System types
export type InventoryCategory = typeof inventoryCategories.$inferSelect;
export type InsertInventoryCategory = z.infer<typeof insertInventoryCategorySchema>;

export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;

export type PosOrder = typeof posOrders.$inferSelect;
export type InsertPosOrder = z.infer<typeof insertPosOrderSchema>;

export type PosOrderItem = typeof posOrderItems.$inferSelect;
export type InsertPosOrderItem = z.infer<typeof insertPosOrderItemSchema>;

export type ShiftRecord = typeof shiftRecords.$inferSelect;
export type InsertShiftRecord = z.infer<typeof insertShiftRecordSchema>;

export type PaymentMethod = typeof paymentMethods.$inferSelect;
export type InsertPaymentMethod = z.infer<typeof insertPaymentMethodSchema>;

export type SpecialRate = typeof specialRates.$inferSelect;
export type InsertSpecialRate = z.infer<typeof insertSpecialRateSchema>;

export type RoomFeature = typeof roomFeatures.$inferSelect;
export type InsertRoomFeature = z.infer<typeof insertRoomFeatureSchema>;

export type LayoutConfig = typeof layoutConfig.$inferSelect;
export type InsertLayoutConfig = z.infer<typeof insertLayoutConfigSchema>;

// Login type for authentication
export type LoginCredentials = Pick<InsertUser, "username" | "password">;
